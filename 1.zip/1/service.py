"""第 14 步：把 Agent 从 CLI 变成 HTTP 服务。

设计要点：
- 内核（run_agent）不再直接 print / input。本模块只做两件事：
  1) emit 事件 → SSE（token 流 / 工具调用 / 审批请求 / 结束）；
  2) HTTP 审批请求 → 线程安全的 Future，唤醒内核里的 HITL。
- 同步内核丢进线程池执行（asyncio.to_thread），事件用 loop.call_soon_threadsafe 送回事件循环。
- 会话锁是「进程内 + 跨进程文件锁」（session_lock.py），多实例下同一会话也串行。
- 审批写进 run_store（共享存储）再轮询等待，任意实例都能批准（第 28 步）。

运行：
    uvicorn service:app --host 127.0.0.1 --port 8000

交互：
    POST /sessions/{sid}/messages        {"text": "帮我算 123*456 并写进 1.txt"}
        -> {"run_id": "..."}
    GET  /runs/{run_id}/events           (SSE：text_delta / tool_start / ...)
    POST /plans/stream                   {"goal": "查天气并写进 1/plan_result.txt"}
        -> SSE：plan / layer_start / subtask_text / subtask_done / review / finished
    POST /approvals/{approval_id}        {"approved": true}

鉴权与多租户（第 23 步）：
    配 AGENT_USERS="alice:key1,bob:key2" 即开启鉴权；请求带
    `Authorization: Bearer <key>` 或 `X-API-Key: <key>`。
    留空 = 关闭鉴权（本地开发），所有请求归属用户 local。
    会话按用户隔离（<user>__<sid>.json），run 的列表 / 查询 / 取消 / 事件只允许本人。
"""
from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
import os
import sys
import threading
import time
import uuid

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

import auth
import audit
import costs
import lifecycle
import reliability
import retention
import session_lock
from llm import limiter
from agent_loop import run_agent
from config import Config
from conversation.conversation import Conversation
from data.dataclass import CancelToken, RunContext
from orchestrator import run_plan
from run_store import (APPROVED, CANCELLED, COMPLETED, DENIED, FAILED, PENDING,
                       RUNNING, TIMEOUT, ApprovalRecord, RunRecord, get_store)
from tools.permissions import describe, reset_approver, set_approver
from trace_utils import Trace

cfg = Config()
app = FastAPI(title="Agent Service", version="0.1.0")

LIVE: dict[str, "RunState"] = {}                      # run_id -> 本进程事件通道（队列不可外置）
CANCELS: dict[str, CancelToken] = {}                  # run_id -> 本进程取消令牌
_STORE = get_store()                                  # run 元数据：内存 / SQLite（RUN_STORE）
_LOCKS = session_lock.SessionLocks()                  # 会话锁：进程内 + 跨进程文件锁
_RUN_SLOTS = (threading.BoundedSemaphore(cfg.max_concurrent_runs)
              if cfg.max_concurrent_runs > 0 else None)   # 运行级准入（第 25 步 · L2）


class MessageIn(BaseModel):
    text: str


class ApprovalIn(BaseModel):
    approved: bool


class PlanIn(BaseModel):
    goal: str


class RunState:
    """一次运行的输出通道：worker 线程 emit → 事件循环的 asyncio.Queue。

    队列天然属于某个进程，所以这里是**进程内**结构；跨实例的实时推送需要消息中间件，
    run 的元数据（状态 / 可取消）则由 run_store 承载。
    """

    def __init__(self, run_id: str, loop: asyncio.AbstractEventLoop):
        self.run_id = run_id
        self.loop = loop
        self.queue: asyncio.Queue[dict] = asyncio.Queue()

    def emit(self, event: dict) -> None:
        # 从 worker 线程安全地把事件投递回事件循环
        self.loop.call_soon_threadsafe(self.queue.put_nowait, event)


def current_user(request: Request) -> "auth.Principal":
    """鉴权依赖：解析 API Key → 身份（用户 + 权限）。未配置鉴权时返回匿名身份 local。"""
    try:
        principal = auth.from_headers(request.headers.get("authorization"),
                                      request.headers.get("x-api-key"))
    except auth.AuthError as e:                    # 配置写错：明确报 500，别静默放行
        raise HTTPException(status_code=500, detail=f"鉴权配置有误：{e}")
    if principal is None:
        raise HTTPException(status_code=401, detail="未通过鉴权：缺少或无效的 API Key")
    return principal


def require(scope: str):
    """端点级权限：要求身份具备某个 scope（admin 自动拥有全部）。"""
    def dep(principal: "auth.Principal" = Depends(current_user)) -> "auth.Principal":
        if not principal.has(scope):
            raise HTTPException(status_code=403, detail=f"缺少权限：{scope}")
        return principal
    return dep


def _scoped_sid(user: str, sid: str) -> str:
    """把 (用户, 会话名) 映射成磁盘会话 ID；名字非法（含路径穿越）按 400 处理。"""
    try:
        return auth.session_key(user, sid)
    except auth.AuthError as e:
        raise HTTPException(status_code=400, detail=str(e))


def _owned_run(run_id: str, user: str):
    """取 run 并校验归属；不存在或非本人一律 404（不泄露「存在性」）。"""
    rec = _STORE.get(run_id)
    if rec is None or rec.user != user:
        raise HTTPException(status_code=404, detail="run 不存在")
    return rec


def _quota_guard(user: str) -> None:
    """配额闸门：已花超过上限就拒绝「启动新 run」（USER_QUOTA_USD=0 表示不限）。"""
    ok, used, quota = costs.check_quota(user)
    if not ok:
        raise HTTPException(
            status_code=429,
            detail=f"已超出配额：已花 ${used:.4f} / 上限 ${quota:.4f}",
        )


def _acquire_run_slot() -> bool:
    """运行级准入：拿不到就快速失败，别让线程堆在闸门前面。"""
    return True if _RUN_SLOTS is None else _RUN_SLOTS.acquire(blocking=False)


def _release_run_slot() -> None:
    if _RUN_SLOTS is not None:
        try:
            _RUN_SLOTS.release()
        except ValueError:                 # 多释放不该把服务搞崩
            pass


def _run_slot_stats() -> dict:
    if _RUN_SLOTS is None:
        return {"limit": 0, "in_use": 0, "available": None}
    limit = cfg.max_concurrent_runs
    available = getattr(_RUN_SLOTS, "_value", None)   # 仅供观测
    return {"limit": limit,
            "in_use": (limit - available) if available is not None else None,
            "available": available}


def _make_approver(st: RunState, user: str, run_id: str):
    """返回同步审批器：写共享存储 → 发审批事件 → 轮询等决议（跨实例可用）。

    决议写进 run_store（不是进程内 Future），所以 A 实例上挂起的运行，
    可以被 B 实例上的 `POST /approvals/{id}` 唤醒。
    """

    def approver(name: str, args) -> tuple[bool, str]:
        approval_id = uuid.uuid4().hex
        detail = describe(name, args)
        _STORE.create_approval(ApprovalRecord(
            approval_id=approval_id, run_id=run_id, user=user,
            tool=name, detail=detail, created_at=time.time(),
        ))
        st.emit({
            "type": "approval_required",
            "id": approval_id,
            "tool": name,
            "detail": detail,
        })
        deadline = time.time() + cfg.approval_timeout_s
        while time.time() < deadline:
            rec = _STORE.get_approval(approval_id)
            if rec is not None and rec.status != PENDING:
                if rec.status == APPROVED:
                    return True, "用户同意"
                if rec.status == TIMEOUT:
                    return False, "审批超时，按拒绝处理"
                return False, "用户拒绝"
            time.sleep(cfg.approval_poll_s)
        _STORE.resolve_approval(approval_id, TIMEOUT)      # 超时按拒绝处理
        return False, "审批超时，按拒绝处理"

    return approver


def _finish(run_id: str, status: str, error: str | None = None,
            summary: dict | None = None) -> None:
    """把 run 的终态写回存储，并回收本进程的取消令牌。"""
    _STORE.update(run_id, status=status, error=error, summary=summary)
    CANCELS.pop(run_id, None)
    try:                                       # 幂等记录一起收尾
        reliability.get_store().finish_idempotency(
            run_id, reliability.DONE,
            {"status": status, "error": error, "summary": summary})
    except Exception:
        pass


def _heartbeat_interval() -> float:
    try:
        return max(1.0, float(os.getenv("RUN_HEARTBEAT_S") or 10))
    except ValueError:
        return 10.0


@contextlib.contextmanager
def _heartbeat(run_id: str):
    """心跳：周期性刷新 run 的 updated_at，避免被误判成"崩溃残留"。"""
    stop = threading.Event()

    def beat() -> None:
        while not stop.wait(_heartbeat_interval()):
            try:
                _STORE.update(run_id)
            except Exception:
                pass

    th = threading.Thread(target=beat, daemon=True, name=f"hb-{run_id[:8]}")
    th.start()
    try:
        yield
    finally:
        stop.set()


def _request_hash(payload: dict) -> str:
    blob = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha1(blob.encode("utf-8")).hexdigest()[:16]


def _claim_idempotency(user: str, idem_key: str | None,
                       payload: dict) -> tuple[str | None, dict | None]:
    """幂等入口。返回 (复用的 run_id, 直接返回的响应)。

    - 没带 Idempotency-Key → (None, None)，照常新建；
    - 首次 → 抢到一个新 run_id；
    - 重复 → (已有 run_id, {"run_id":..., "idempotent": True})，**不重复开跑**；
    - 同 key 不同 body → 409。
    """
    if not idem_key:
        return None, None
    store = reliability.get_store()
    digest = _request_hash(payload)
    new_id = uuid.uuid4().hex
    rec = reliability.IdempotencyRecord(user=user, key=idem_key,
                                        request_hash=digest, run_id=new_id,
                                        status=reliability.RUNNING)
    if store.try_create_idempotency(rec):
        return new_id, None
    existing = store.get_idempotency(idem_key, user)
    if existing is None:                       # 极端竞态：刚好被清理掉了
        return None, None
    if existing.request_hash != digest:
        raise HTTPException(
            status_code=409,
            detail="同一个 Idempotency-Key 被用于了不同的请求体")
    return existing.run_id, {"run_id": existing.run_id, "idempotent": True,
                             "status": existing.status}


def _run_sync(run_id: str, sid: str, text: str, st: RunState,
              cancel: CancelToken, user: str) -> None:
    """线程入口：跑完（无论成败）都要归还运行级槽位。"""
    try:
        with _heartbeat(run_id):
            _run_sync_inner(run_id, sid, text, st, cancel, user)
    finally:
        _release_run_slot()


def _run_sync_inner(run_id: str, sid: str, text: str, st: RunState,
                    cancel: CancelToken, user: str) -> None:
    """在 worker 线程里执行一次同步内核，并把结果/异常变成事件。"""
    with _LOCKS.hold(sid):
        conv = Conversation.load(sid) or Conversation(
            instructions=cfg.instructions, session_id=sid, user=user
        )
        conv.user = user                      # 存量会话也补上归属（第 27 步）
        conv.add_user(text)
        t = Trace(user=user)
        token = set_approver(_make_approver(st, user, run_id))   # ★ HITL 接 HTTP（认人）
        try:
            result = run_agent(conv, t, cfg, emit=st.emit, cancel=cancel,
                               ctx=RunContext(user=user))
            st.emit({
                "type": "finished",
                "status": result.status.value,
                "final_text": result.final_text,
                "steps": result.steps,
                "usage": result.usage,
                "error": result.error,
            })
            costs.record(user, run_id, "chat", cfg.model, result.usage,
                         result.usage.get("cost", 0.0))
            _finish(run_id, result.status.value, result.error,
                    {"steps": result.steps, "usage": result.usage})
        except Exception as e:                         # 兜底：绝不让事件流悬空
            st.emit({"type": "error", "error": str(e)})
            _finish(run_id, FAILED, str(e))
        finally:
            reset_approver(token)


def _run_plan_sync(run_id: str, goal: str, st: RunState,
                   cancel: CancelToken, user: str, resume: bool = False) -> None:
    """线程入口：跑完（无论成败）都要归还运行级槽位。"""
    try:
        with _heartbeat(run_id):
            _run_plan_sync_inner(run_id, goal, st, cancel, user, resume)
    finally:
        _release_run_slot()


def _run_plan_sync_inner(run_id: str, goal: str, st: RunState,
                         cancel: CancelToken, user: str,
                         resume: bool = False) -> None:
    """在 worker 线程里执行一次"规划 → 执行 → 评审"编排。

    编排事件（plan / layer_start / subtask_text / subtask_done / review / finished）
    全部由 run_plan 经 st.emit 发出；HITL 通过 approver 参数接入 HTTP。
    """
    try:
        result = run_plan(goal, cfg, emit=st.emit,
                          approver=_make_approver(st, user, run_id), cancel=cancel,
                          user=user, run_id=run_id, resume=resume)
        costs.record(user, run_id, "plan", cfg.model,
                     {"total_tokens": result.total_tokens}, result.total_cost)
        _finish(run_id, CANCELLED if cancel.is_set() else COMPLETED, None,
                {"rounds": result.rounds, "total_tokens": result.total_tokens,
                 "total_cost": result.total_cost,
                 "plan_trace_id": result.plan_trace_id})
    except Exception as e:                             # 兜底：绝不让事件流悬空
        st.emit({"type": "error", "error": str(e)})
        _finish(run_id, FAILED, str(e))


def _sse(event: dict) -> str:
    return f"data: {json.dumps(event, ensure_ascii=False, default=str)}\n\n"


def _new_run(kind: str, target: str, user: str,
             run_id: str | None = None) -> tuple[str, RunState, CancelToken]:
    """建一次运行：进程内事件通道 + 取消令牌，并把元数据写进 store。"""
    loop = asyncio.get_running_loop()
    run_id = run_id or uuid.uuid4().hex      # 复用幂等键抢到的 id
    st = RunState(run_id, loop)
    # 取消令牌同时看本进程 flag 与 store 里的"取消请求"，因而支持跨实例取消
    cancel = CancelToken(is_cancelled=lambda: _STORE.is_cancel_requested(run_id))
    LIVE[run_id] = st
    CANCELS[run_id] = cancel
    _STORE.create(RunRecord(run_id=run_id, kind=kind, status=RUNNING,
                            target=target, user=user, created_at=time.time()))
    return run_id, st, cancel


def _start_run(user: str, key: str, text: str,
               idem_key: str | None = None) -> dict:
    run_id, cached = _claim_idempotency(
        user, idem_key, {"kind": "chat", "sid": key, "text": text})
    if cached is not None:                   # ★ 幂等命中：不重复开跑
        return cached
    _quota_guard(user)
    if not _acquire_run_slot():
        raise HTTPException(status_code=503, detail="服务繁忙：并发运行数已达上限")
    try:
        run_id, st, cancel = _new_run("chat", key, user, run_id)
    except BaseException:
        _release_run_slot()
        raise
    asyncio.create_task(asyncio.to_thread(_run_sync, run_id, key, text, st, cancel, user))
    return {"run_id": run_id, "idempotent": False}


def _start_plan(user: str, goal: str,
                idem_key: str | None = None) -> dict:
    run_id, cached = _claim_idempotency(
        user, idem_key, {"kind": "plan", "goal": goal})
    if cached is not None:
        return cached
    _quota_guard(user)
    if not _acquire_run_slot():
        raise HTTPException(status_code=503, detail="服务繁忙：并发运行数已达上限")
    try:
        run_id, st, cancel = _new_run("plan", goal, user, run_id)
    except BaseException:
        _release_run_slot()
        raise
    asyncio.create_task(asyncio.to_thread(_run_plan_sync, run_id, goal, st, cancel, user))
    return {"run_id": run_id, "idempotent": False}


def _event_response(run_id: str) -> StreamingResponse:
    st = LIVE[run_id]

    async def gen():
        try:
            while True:
                try:
                    event = await asyncio.wait_for(st.queue.get(), timeout=15)
                except asyncio.TimeoutError:
                    yield ": ping\n\n"             # SSE 保活，防网关断连
                    continue
                yield _sse(event)
                if event.get("type") in ("finished", "error"):
                    break
        finally:
            LIVE.pop(run_id, None)

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/health")
async def health() -> dict:
    return {"ok": True}


@app.get("/usage")
async def usage(principal: auth.Principal = Depends(require("chat"))) -> dict:
    """本人的花费与配额（读账本）。"""
    used = costs.spent(principal.user)
    quota = costs.quota_usd()
    return {
        "user": principal.user,
        "spent_usd": round(used, 6),
        "quota_usd": quota,
        "remaining_usd": round(max(0.0, quota - used), 6) if quota > 0 else None,
    }


@app.get("/metrics")
async def metrics(principal: auth.Principal = Depends(require("admin"))) -> dict:
    """全局用量汇总（按用户）——需要 admin 权限。"""
    return {
        "by_user": costs.summary(50),
        "run_slots": _run_slot_stats(),
        "llm_gate": limiter.get_gate().stats(),
    }


@app.post("/sessions/{sid}/messages")
async def post_message(sid: str, body: MessageIn,
                       idem_key: str | None = Header(None, alias="Idempotency-Key"),
                       principal: auth.Principal = Depends(require("chat"))) -> dict:
    """提交一条用户消息，返回 run_id；随后连 SSE 拉取本次运行的事件。

    带 `Idempotency-Key` 头时，同一个 key 重复提交只会开跑一次（第 28 步）。
    """
    user = principal.user
    return _start_run(user, _scoped_sid(user, sid), body.text, idem_key)


@app.get("/runs/{run_id}/events")
async def run_events(run_id: str,
                     principal: auth.Principal = Depends(require("chat"))) -> StreamingResponse:
    rec = _owned_run(run_id, principal.user)       # 非本人 → 404
    if run_id not in LIVE:
        raise HTTPException(
            status_code=409,
            detail=f"该 run 的事件通道不在本实例（状态={rec.status}）。"
                   f"实时事件流是进程内的，跨实例消费需消息中间件。",
        )
    return _event_response(run_id)


@app.post("/sessions/{sid}/messages/stream")
async def post_message_stream(sid: str, body: MessageIn,
                              principal: auth.Principal = Depends(require("chat"))
                              ) -> StreamingResponse:
    """一步到位：提交消息并以 SSE 直接返回本次运行的所有事件。"""
    user = principal.user
    return _event_response(_start_run(user, _scoped_sid(user, sid), body.text))


@app.get("/runs")
async def list_runs(limit: int = 50,
                    principal: auth.Principal = Depends(require("chat"))) -> list[dict]:
    """列出「本人」最近的 run（读 store：进程重启后仍在）。"""
    return [r.to_dict() for r in _STORE.list(limit, user=principal.user)]


@app.get("/runs/{run_id}")
async def get_run(run_id: str,
                  principal: auth.Principal = Depends(require("chat"))) -> dict:
    """查询某个 run 的状态（只能是本人的）。"""
    return _owned_run(run_id, principal.user).to_dict()


@app.post("/runs/{run_id}/cancel")
async def cancel_run(run_id: str,
                     principal: auth.Principal = Depends(require("chat"))) -> dict:
    """请求取消某个 run。

    先写 store 的取消标记（多实例可见），再置本进程令牌：若该 run 就在本实例，
    会在下一个"步/层"边界立刻生效。正在进行的单次模型或工具调用不会被立刻打断。
    """
    rec = _owned_run(run_id, principal.user)       # 非本人 → 404
    _STORE.request_cancel(run_id)
    local = CANCELS.get(run_id)
    if local is not None:
        local.cancel()
    return {"ok": True, "local": local is not None,
            "status": (_STORE.get(run_id) or rec).status}


@app.post("/plans")
async def post_plan(body: PlanIn,
                    idem_key: str | None = Header(None, alias="Idempotency-Key"),
                    principal: auth.Principal = Depends(require("plan"))) -> dict:
    """提交一个总目标，返回 run_id；随后连 SSE 拉取全过程事件。

    带 `Idempotency-Key` 时同一 key 只开跑一次。
    """
    return _start_plan(principal.user, body.goal, idem_key)

@app.post("/plans/stream")
async def post_plan_stream(body: PlanIn,
                           principal: auth.Principal = Depends(require("plan"))
                           ) -> StreamingResponse:
    """一步到位：提交总目标并以 SSE 直接返回"规划→执行→评审"全过程事件。"""
    return _event_response(_start_plan(principal.user, body.goal))


@app.post("/approvals/{approval_id}")
async def approve(approval_id: str, body: ApprovalIn,
                  principal: auth.Principal = Depends(require("chat"))) -> dict:
    """外部审批：把决议写进共享存储，任意实例上的运行都能被唤醒。"""
    rec = _STORE.get_approval(approval_id)
    if rec is None or rec.user != principal.user:
        raise HTTPException(status_code=404, detail="审批请求不存在或已过期")
    if rec.status != PENDING:                      # 幂等：已经决议过就直接返回
        return {"ok": True, "status": rec.status}
    status = APPROVED if body.approved else DENIED
    if not _STORE.resolve_approval(approval_id, status, principal.user):
        latest = _STORE.get_approval(approval_id) or rec
        return {"ok": True, "status": latest.status}
    return {"ok": True, "status": status}


@app.get("/approvals/{approval_id}")
async def get_approval(approval_id: str,
                       principal: auth.Principal = Depends(require("chat"))) -> dict:
    """查询某个审批的状态（只能是本人的）。"""
    rec = _STORE.get_approval(approval_id)
    if rec is None or rec.user != principal.user:
        raise HTTPException(status_code=404, detail="审批请求不存在或已过期")
    return rec.to_dict()


# ===================== 数据生命周期与隐私（第 27 步） =====================

@app.get("/me/data")
async def my_data(principal: auth.Principal = Depends(require("chat"))) -> dict:
    """清点「我」的数据：各存储里有多少条。"""
    return {"user": principal.user, "counts": lifecycle.inventory(principal.user)}


@app.get("/me/export")
async def my_export(to_file: bool = False, include_traces: bool = False,
                    principal: auth.Principal = Depends(require("chat"))) -> dict:
    """导出「我」的全部数据。

    默认**直接返回 JSON**（不落盘，避免明文文件留在磁盘上）；
    `to_file=true` 才写文件（权限 0600，且会被过期清理）。
    """
    if to_file:
        path = lifecycle.export_user(principal.user, cfg.export_dir,
                                     include_traces=include_traces)
        return {"ok": True, "path": str(path)}
    return lifecycle.build_bundle(principal.user, include_traces=include_traces)


@app.delete("/me")
async def delete_me(confirm: bool = False,
                    principal: auth.Principal = Depends(require("chat"))) -> dict:
    """删除「我」的全部数据。默认只预演（dry-run），confirm=true 才真删。"""
    return lifecycle.purge_user(principal.user, dry_run=not confirm,
                                actor=principal.user)


@app.post("/admin/users/{user}/purge")
async def admin_purge(user: str, confirm: bool = False,
                      principal: auth.Principal = Depends(require("admin"))) -> dict:
    """管理员删除指定用户的数据（同样默认 dry-run）。"""
    return lifecycle.purge_user(user, dry_run=not confirm, actor=principal.user)


@app.post("/admin/retention")
async def admin_retention(dry_run: bool = False,
                          principal: auth.Principal = Depends(require("admin"))) -> dict:
    """手动跑一次保留策略清理。"""
    return {"report": retention.sweep(dry_run=dry_run)}


@app.get("/admin/audit")
async def admin_audit(limit: int = 50,
                      principal: auth.Principal = Depends(require("admin"))) -> dict:
    """最近的审计记录（只记动作与计数，不含内容）。"""
    return {"entries": audit.tail(limit)}


@app.post("/admin/migrate/orphans")
async def admin_adopt_orphans(user: str = "local",
                              principal: auth.Principal = Depends(require("admin"))) -> dict:
    """把升级前 `user==""` 的存量数据认领给某个用户（一次性迁移）。"""
    return lifecycle.adopt_orphans(user, actor=principal.user)


async def _retention_loop(interval: float) -> None:
    while True:
        try:
            await asyncio.to_thread(retention.sweep)
        except Exception as e:                     # 清理失败不该拖垮服务
            print(f"[warn] 保留策略清理失败：{e}", file=sys.stderr)
        await asyncio.sleep(interval)


@app.on_event("startup")
async def _on_startup() -> None:
    """设了 RETENTION_SWEEP_INTERVAL_S>0 才启动定时清理（默认关闭）。"""
    interval = cfg.retention_sweep_interval_s
    if interval and interval > 0:
        asyncio.create_task(_retention_loop(interval))


def _stale_seconds() -> float:
    try:
        return max(0.0, float(os.getenv("RUN_STALE_S") or 300))
    except ValueError:
        return 300.0


@app.on_event("startup")
async def _detect_stale_runs() -> None:
    """启动时找"上次没跑完"的 run（status=running 且心跳已停）。

    只告警、不自动续跑 —— 续跑会真花钱，必须由人显式触发。
    """
    cutoff = time.time() - _stale_seconds()
    stale = [r for r in _STORE.list(limit=500)
             if r.status == RUNNING and r.updated_at < cutoff]
    if not stale:
        return
    for r in stale:
        print(f"[warn] 发现未完成的 run：{r.run_id}（{r.kind}）—— "
              f"可用 POST /admin/runs/{r.run_id}/resume 续跑", file=sys.stderr)
    audit.log("stale_runs_detected", counts={"runs": len(stale)})


@app.post("/admin/runs/{run_id}/resume")
async def admin_resume(run_id: str,
                       principal: auth.Principal = Depends(require("admin"))) -> dict:
    """从检查点续跑一个未完成的 plan run（正在跑 / 无检查点的会被拒）。"""
    rec = _STORE.get(run_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="run 不存在")
    if rec.kind != "plan":
        raise HTTPException(status_code=400, detail="只有 plan 类型支持续跑")
    if rec.status == RUNNING:
        raise HTTPException(status_code=409, detail="该 run 仍在运行，不能重复续跑")
    if reliability.get_store().get_plan(run_id) is None:
        raise HTTPException(status_code=409, detail="没有可续跑的检查点（计划未落盘）")
    if not _acquire_run_slot():
        raise HTTPException(status_code=503, detail="服务繁忙：并发运行数已达上限")
    try:
        st = RunState(run_id, asyncio.get_running_loop())
        cancel = CancelToken(is_cancelled=lambda: _STORE.is_cancel_requested(run_id))
        LIVE[run_id] = st
        CANCELS[run_id] = cancel
        _STORE.update(run_id, status=RUNNING, error=None)
        asyncio.create_task(asyncio.to_thread(
            _run_plan_sync, run_id, rec.target, st, cancel, rec.user or "", True))
    except BaseException:
        _release_run_slot()
        raise
    audit.log("resume", actor=principal.user, subject=run_id)
    return {"ok": True, "run_id": run_id, "resumed": True}
