"""可靠性地基：幂等键 / 检查点 / 计划持久化（第 28 步）。

解决两个不同的问题：
- **幂等**：同一个请求被重发（超时重试、用户手抖）时，不重复开跑、不重复扣费；
  靠 `idempotency` 表 + 客户端给的 `Idempotency-Key`。
- **续跑**：进程崩了之后能接着跑。靠 `run_plans`（计划与轮次进度）+
  `checkpoints`（每个子任务结束即落盘），恢复时**跳过已完成的子任务**。

为什么单独一个模块：`run_store` 管的是"run 的元数据"，这里管的是"进度"，
两者读写频率与生命周期都不同；但共用同一个后端选择（RUN_STORE / RUN_STORE_PATH）
和同一个 SQLite 文件，保持一致。
"""
from __future__ import annotations

import copy
import json
import os
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

RUNNING = "running"
DONE = "done"


@dataclass
class IdempotencyRecord:
    user: str
    key: str
    request_hash: str = ""
    run_id: str = ""
    status: str = RUNNING
    response: dict | None = None
    created_at: float = 0.0
    updated_at: float = 0.0

    def to_dict(self) -> dict:
        return {"user": self.user, "key": self.key,
                "request_hash": self.request_hash, "run_id": self.run_id,
                "status": self.status, "response": self.response,
                "created_at": self.created_at, "updated_at": self.updated_at}


@dataclass
class PlanRecord:
    run_id: str
    user: str = ""
    goal: str = ""
    plan: dict = field(default_factory=dict)
    round_no: int = -1          # 最后一个「完整跑完」的轮次；-1 = 一轮都没跑完
    created_at: float = 0.0
    updated_at: float = 0.0


@dataclass
class CheckpointRecord:
    run_id: str
    round: int
    subtask_id: str
    user: str = ""
    status: str = ""
    final_text: str = ""
    tokens: int = 0
    cost: float = 0.0
    trace_id: str = ""
    error: str | None = None
    updated_at: float = 0.0


_IDEM_COLS = ("user", "key", "request_hash", "run_id", "status",
              "response", "created_at", "updated_at")
_PLAN_COLS = ("run_id", "user", "goal", "plan", "round_no",
              "created_at", "updated_at")
_CKPT_COLS = ("run_id", "user", "round", "subtask_id", "status", "final_text",
              "tokens", "cost", "trace_id", "error", "updated_at")


class InMemoryReliabilityStore:
    """单进程实现（开发 / CLI 默认）。"""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._idem: dict[tuple, IdempotencyRecord] = {}
        self._plans: dict[str, PlanRecord] = {}
        self._ckpts: dict[tuple, CheckpointRecord] = {}
        self._effects: dict[str, dict] = {}

    # ---- 幂等 ----
    def try_create_idempotency(self, rec: IdempotencyRecord) -> bool:
        now = time.time()
        rec.created_at = rec.created_at or now
        rec.updated_at = now
        with self._lock:
            if (rec.user, rec.key) in self._idem:
                return False
            self._idem[(rec.user, rec.key)] = copy.deepcopy(rec)
            return True

    def get_idempotency(self, key: str, user: str) -> IdempotencyRecord | None:
        with self._lock:
            rec = self._idem.get((user, key))
            return copy.deepcopy(rec) if rec else None

    def finish_idempotency(self, run_id: str, status: str,
                           response: dict | None = None) -> None:
        with self._lock:
            for rec in self._idem.values():
                if rec.run_id == run_id:
                    rec.status = status
                    rec.response = response
                    rec.updated_at = time.time()

    # ---- 计划 / 进度 ----
    def save_plan(self, rec: PlanRecord) -> None:
        now = time.time()
        rec.created_at = rec.created_at or now
        rec.updated_at = now
        with self._lock:
            self._plans[rec.run_id] = copy.deepcopy(rec)

    def get_plan(self, run_id: str) -> PlanRecord | None:
        with self._lock:
            rec = self._plans.get(run_id)
            return copy.deepcopy(rec) if rec else None

    def set_round(self, run_id: str, round_no: int) -> None:
        with self._lock:
            rec = self._plans.get(run_id)
            if rec is not None:
                rec.round_no = int(round_no)
                rec.updated_at = time.time()

    # ---- 检查点 ----
    def save_checkpoint(self, rec: CheckpointRecord) -> None:
        rec.updated_at = rec.updated_at or time.time()
        with self._lock:
            self._ckpts[(rec.run_id, rec.round, rec.subtask_id)] = copy.deepcopy(rec)

    def get_checkpoint(self, run_id: str, round_no: int,
                       subtask_id: str) -> CheckpointRecord | None:
        with self._lock:
            rec = self._ckpts.get((run_id, round_no, subtask_id))
            return copy.deepcopy(rec) if rec else None

    def list_checkpoints(self, run_id: str,
                         round_no: int | None = None) -> list[CheckpointRecord]:
        with self._lock:
            rows = [c for c in self._ckpts.values()
                    if c.run_id == run_id
                    and (round_no is None or c.round == round_no)]
            rows.sort(key=lambda c: (c.round, c.subtask_id))
            return copy.deepcopy(rows)

    # ---- 生命周期 ----
    def purge_user(self, user: str) -> dict:
        with self._lock:
            n1 = len([k for k, v in self._idem.items() if v.user == user])
            for k in [k for k, v in self._idem.items() if v.user == user]:
                del self._idem[k]
            n2 = len([k for k, v in self._plans.items() if v.user == user])
            for k in [k for k, v in self._plans.items() if v.user == user]:
                del self._plans[k]
            n3 = len([k for k, v in self._ckpts.items() if v.user == user])
            for k in [k for k, v in self._ckpts.items() if v.user == user]:
                del self._ckpts[k]
            n4 = len([k for k, v in self._effects.items() if v.get("user") == user])
            for k in [k for k, v in self._effects.items() if v.get("user") == user]:
                del self._effects[k]
        return {"idempotency": n1, "plans": n2, "checkpoints": n3, "effects": n4}

    def purge_older_than(self, cutoff: float) -> dict:
        with self._lock:
            n1 = 0
            for k in [k for k, v in self._idem.items() if v.created_at < cutoff]:
                del self._idem[k]
                n1 += 1
            n2 = 0
            for k in [k for k, v in self._plans.items() if v.updated_at < cutoff]:
                del self._plans[k]
                n2 += 1
            n3 = 0
            for k in [k for k, v in self._ckpts.items() if v.updated_at < cutoff]:
                del self._ckpts[k]
                n3 += 1
            n4 = 0
            for k in [k for k, v in self._effects.items()
                      if v.get("created_at", 0) < cutoff]:
                del self._effects[k]
                n4 += 1
        return {"idempotency": n1, "plans": n2, "checkpoints": n3, "effects": n4}

    # ---- 副作用去重（第 28 步）----
    def get_effect(self, key: str) -> dict | None:
        with self._lock:
            v = self._effects.get(key)
            return dict(v) if v else None

    def purge_user_older_than(self, user: str, cutoff: float,
                              dry_run: bool = False) -> dict:
        with self._lock:
            sel = {
                "idempotency": [k for k, v in self._idem.items()
                                if v.user == user and v.created_at < cutoff],
                "plans": [k for k, v in self._plans.items()
                          if v.user == user and v.updated_at < cutoff],
                "checkpoints": [k for k, v in self._ckpts.items()
                                if v.user == user and v.updated_at < cutoff],
                "effects": [k for k, v in self._effects.items()
                            if v.get("user") == user
                            and v.get("created_at", 0) < cutoff],
            }
            if not dry_run:
                for k in sel["idempotency"]:
                    del self._idem[k]
                for k in sel["plans"]:
                    del self._plans[k]
                for k in sel["checkpoints"]:
                    del self._ckpts[k]
                for k in sel["effects"]:
                    del self._effects[k]
            return {k: len(v) for k, v in sel.items()}

    def save_effect(self, key: str, run_id: str, user: str, tool: str,
                    result: str, error: bool) -> None:
        with self._lock:
            if key not in self._effects:            # 只记第一次
                self._effects[key] = {"key": key, "run_id": run_id, "user": user,
                                      "tool": tool, "result": result,
                                      "error": bool(error),
                                      "created_at": time.time()}


class SqliteReliabilityStore:
    """落盘实现：重启不丢、多实例共享（同一个 db 文件）。"""

    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._exec(
            """CREATE TABLE IF NOT EXISTS idempotency (
                user         TEXT,
                key          TEXT,
                request_hash TEXT,
                run_id       TEXT,
                status       TEXT,
                response     TEXT,
                created_at   REAL,
                updated_at   REAL,
                PRIMARY KEY (user, key)
            )"""
        )
        self._exec(
            """CREATE TABLE IF NOT EXISTS run_plans (
                run_id     TEXT PRIMARY KEY,
                user       TEXT,
                goal       TEXT,
                plan       TEXT,
                round_no   INTEGER,
                created_at REAL,
                updated_at REAL
            )"""
        )
        self._exec(
            """CREATE TABLE IF NOT EXISTS checkpoints (
                run_id     TEXT,
                user       TEXT,
                round      INTEGER,
                subtask_id TEXT,
                status     TEXT,
                final_text TEXT,
                tokens     INTEGER,
                cost       REAL,
                trace_id   TEXT,
                error      TEXT,
                updated_at REAL,
                PRIMARY KEY (run_id, round, subtask_id)
            )"""
        )
        self._exec(
            """CREATE TABLE IF NOT EXISTS effects (
                key        TEXT PRIMARY KEY,
                run_id     TEXT,
                user       TEXT,
                tool       TEXT,
                result     TEXT,
                error      INTEGER,
                created_at REAL
            )"""
        )

    def _exec(self, sql: str, params: tuple = ()) -> list[tuple]:
        with self._lock:
            conn = sqlite3.connect(self.path, timeout=5)
            try:
                cur = conn.execute(sql, params)
                rows = cur.fetchall()
                conn.commit()
                return rows
            finally:
                conn.close()

    @staticmethod
    def _json(v):
        return json.dumps(v, ensure_ascii=False) if v is not None else None

    # ---- 幂等 ----
    def try_create_idempotency(self, rec: IdempotencyRecord) -> bool:
        now = time.time()
        rec.created_at = rec.created_at or now
        rec.updated_at = now
        try:
            self._exec(
                "INSERT INTO idempotency VALUES (?,?,?,?,?,?,?,?)",
                (rec.user, rec.key, rec.request_hash, rec.run_id, rec.status,
                 self._json(rec.response), rec.created_at, rec.updated_at),
            )
            return True
        except sqlite3.IntegrityError:      # 主键冲突 = 已有人抢先建过
            return False

    def get_idempotency(self, key: str, user: str) -> IdempotencyRecord | None:
        rows = self._exec(
            "SELECT user,key,request_hash,run_id,status,response,created_at,updated_at"
            " FROM idempotency WHERE user=? AND key=?", (user, key))
        if not rows:
            return None
        u, k, h, rid, st, resp, c, up = rows[0]
        return IdempotencyRecord(user=u, key=k, request_hash=h or "", run_id=rid or "",
                                 status=st, response=json.loads(resp) if resp else None,
                                 created_at=c or 0.0, updated_at=up or 0.0)

    def finish_idempotency(self, run_id: str, status: str,
                           response: dict | None = None) -> None:
        self._exec(
            "UPDATE idempotency SET status=?, response=?, updated_at=? WHERE run_id=?",
            (status, self._json(response), time.time(), run_id),
        )

    # ---- 计划 / 进度 ----
    def save_plan(self, rec: PlanRecord) -> None:
        now = time.time()
        rec.created_at = rec.created_at or now
        rec.updated_at = now
        self._exec(
            "INSERT OR REPLACE INTO run_plans VALUES (?,?,?,?,?,?,?)",
            (rec.run_id, rec.user, rec.goal, self._json(rec.plan),
             int(rec.round_no), rec.created_at, rec.updated_at),
        )

    def get_plan(self, run_id: str) -> PlanRecord | None:
        rows = self._exec(
            "SELECT run_id,user,goal,plan,round_no,created_at,updated_at"
            " FROM run_plans WHERE run_id=?", (run_id,))
        if not rows:
            return None
        rid, u, goal, plan, rn, c, up = rows[0]
        return PlanRecord(run_id=rid, user=u or "", goal=goal or "",
                          plan=json.loads(plan) if plan else {},
                          round_no=int(rn if rn is not None else -1),
                          created_at=c or 0.0, updated_at=up or 0.0)

    def set_round(self, run_id: str, round_no: int) -> None:
        self._exec("UPDATE run_plans SET round_no=?, updated_at=? WHERE run_id=?",
                   (int(round_no), time.time(), run_id))

    # ---- 检查点 ----
    def save_checkpoint(self, rec: CheckpointRecord) -> None:
        rec.updated_at = rec.updated_at or time.time()
        self._exec(
            "INSERT OR REPLACE INTO checkpoints VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (rec.run_id, rec.user, int(rec.round), rec.subtask_id, rec.status,
             rec.final_text, int(rec.tokens), float(rec.cost), rec.trace_id,
             rec.error, rec.updated_at),
        )

    @staticmethod
    def _to_ckpt(row: tuple) -> CheckpointRecord:
        rid, u, rn, sid, st, txt, tok, cost, tid, err, up = row
        return CheckpointRecord(run_id=rid, user=u or "", round=int(rn or 0),
                                subtask_id=sid, status=st or "", final_text=txt or "",
                                tokens=int(tok or 0), cost=float(cost or 0.0),
                                trace_id=tid or "", error=err, updated_at=up or 0.0)

    def get_checkpoint(self, run_id: str, round_no: int,
                       subtask_id: str) -> CheckpointRecord | None:
        rows = self._exec(
            f"SELECT {','.join(_CKPT_COLS)} FROM checkpoints"
            " WHERE run_id=? AND round=? AND subtask_id=?",
            (run_id, int(round_no), subtask_id))
        return self._to_ckpt(rows[0]) if rows else None

    def list_checkpoints(self, run_id: str,
                         round_no: int | None = None) -> list[CheckpointRecord]:
        cols = ",".join(_CKPT_COLS)
        if round_no is None:
            rows = self._exec(
                f"SELECT {cols} FROM checkpoints WHERE run_id=?"
                " ORDER BY round, subtask_id", (run_id,))
        else:
            rows = self._exec(
                f"SELECT {cols} FROM checkpoints WHERE run_id=? AND round=?"
                " ORDER BY subtask_id", (run_id, int(round_no)))
        return [self._to_ckpt(r) for r in rows]

    # ---- 生命周期 ----
    def purge_user(self, user: str) -> dict:
        out = {}
        for table in ("idempotency", "run_plans", "checkpoints", "effects"):
            rows = self._exec(f"SELECT COUNT(*) FROM {table} WHERE user=?", (user,))
            n = int(rows[0][0]) if rows else 0
            if n:
                self._exec(f"DELETE FROM {table} WHERE user=?", (user,))
            out[table] = n
        return out

    def purge_older_than(self, cutoff: float) -> dict:
        rules = {"idempotency": ("created_at", cutoff),
                 "run_plans": ("updated_at", cutoff),
                 "checkpoints": ("updated_at", cutoff),
                 "effects": ("created_at", cutoff)}
        out = {}
        for table, (col, cut) in rules.items():
            rows = self._exec(f"SELECT COUNT(*) FROM {table} WHERE {col}<?", (cut,))
            n = int(rows[0][0]) if rows else 0
            if n:
                self._exec(f"DELETE FROM {table} WHERE {col}<?", (cut,))
            out[table] = n
        return out

    # ---- 副作用去重（第 28 步）----
    def get_effect(self, key: str) -> dict | None:
        rows = self._exec(
            "SELECT key,run_id,user,tool,result,error,created_at"
            " FROM effects WHERE key=?", (key,))
        if not rows:
            return None
        k, rid, u, tool, res, err, created = rows[0]
        return {"key": k, "run_id": rid, "user": u, "tool": tool,
                "result": res, "error": bool(err), "created_at": created or 0.0}

    def save_effect(self, key: str, run_id: str, user: str, tool: str,
                    result: str, error: bool) -> None:
        self._exec(
            "INSERT OR IGNORE INTO effects VALUES (?,?,?,?,?,?,?)",
            (key, run_id, user, tool, result, 1 if error else 0, time.time()),
        )

    def purge_user_older_than(self, user: str, cutoff: float,
                              dry_run: bool = False) -> dict:
        rules = {"idempotency": "created_at", "run_plans": "updated_at",
                 "checkpoints": "updated_at", "effects": "created_at"}
        out = {}
        for table, col in rules.items():
            rows = self._exec(
                f"SELECT COUNT(*) FROM {table} WHERE user=? AND {col}<?",
                (user, cutoff))
            n = int(rows[0][0]) if rows else 0
            if n and not dry_run:
                self._exec(f"DELETE FROM {table} WHERE user=? AND {col}<?",
                           (user, cutoff))
            out[table] = n
        return out


_store = None
_store_lock = threading.Lock()


def get_store():
    """按 RUN_STORE / RUN_STORE_PATH 返回单例（与 run_store 同一后端与文件）。"""
    global _store
    if _store is not None:
        return _store
    with _store_lock:
        if _store is None:
            backend = (os.getenv("RUN_STORE") or "memory").strip().lower()
            if backend == "sqlite":
                path = Path(os.getenv("RUN_STORE_PATH") or "runs.db")
                if not path.is_absolute():
                    path = Path(__file__).resolve().parent / path
                _store = SqliteReliabilityStore(path)
            else:
                _store = InMemoryReliabilityStore()
    return _store
