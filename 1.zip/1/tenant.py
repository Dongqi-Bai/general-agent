"""当前请求的用户（第 27 步）。

为什么用 ContextVar 而不是加参数：工具是经 `run_tool(name, arguments)` 统一调用的，
签名里没有"用户"；而记忆这类工具又必须知道"现在是谁"。用 ContextVar 传递，
工具层一行都不用改 —— 与 `tools/permissions.py` 里的审批器是同一套做法。

约定：`""` 表示单租户模式（CLI / 评测，没有用户概念）。
"""
from __future__ import annotations

import contextvars

_current: contextvars.ContextVar[str] = contextvars.ContextVar("current_user", default="")
_run_id: contextvars.ContextVar[str] = contextvars.ContextVar("current_run", default="")
_step_key: contextvars.ContextVar[str] = contextvars.ContextVar("current_step", default="")


def set_user(user: str | None):
    """设置当前用户，返回 token（用完用 reset_user 还原）。"""
    return _current.set(user or "")


def reset_user(token) -> None:
    _current.reset(token)


def current_user() -> str:
    return _current.get()


def set_run(run_id: str | None, step_key: str | None = ""):
    """设置当前 run / 步骤（副作用幂等键的一部分）。"""
    return (_run_id.set(run_id or ""), _step_key.set(step_key or ""))


def reset_run(token) -> None:
    t1, t2 = token
    _run_id.reset(t1)
    _step_key.reset(t2)


def current_run() -> tuple[str, str]:
    """返回 (run_id, step_key)；不在 run 里时是 ("", "")。"""
    return _run_id.get(), _step_key.get()
