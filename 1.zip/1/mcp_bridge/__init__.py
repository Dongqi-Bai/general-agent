"""第 21 步 · 外部工具协议（MCP）。

把"一个外部 MCP server"当成"一个技能"装载进来：

    mcp_servers.yaml            清单：声明要连哪些 server、怎么起、风险策略
    mcp_bridge/manager.py       异步桥：后台 event loop + 每 server 一个常驻会话
    mcp_bridge/loader.py        装载器：tools/list → 注册成工具 → 登记成技能

装载进来的工具和其它工具完全一样，共用 TOOL_REGISTRY / JSON Schema 校验 /
权限裁决（HITL）/ trace，所以上层（agent_loop、service、orchestrator、evals）
一行都不用改。
"""
