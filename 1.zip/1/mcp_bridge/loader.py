"""把外部 MCP server 装载成技能与工具。

清单：mcp_servers.yaml（默认在项目根）。每个 server 变成一个技能
（skill 名 = "mcp:<name>"），它暴露的工具注册进 TOOL_REGISTRY，于是自动
获得现成的 schema / 权限裁决 / HITL / trace 这一整套。

安全默认（重要）：
- 只有 enabled: true 的 server 才会被启动，且整体还受 MCP_ENABLED 约束
  （默认关——绝不悄悄起子进程）；
- 外部工具默认按 risk_default 处理（默认 write → 走人工确认）；
  想自动放行，必须在 risk_overrides 里显式写 read；
- env 只传清单里显式列出的变量，不会把整个 .env 塞给子进程。
"""
from __future__ import annotations

import os
import threading
from pathlib import Path

import yaml

from mcp_bridge.manager import McpError, flatten_result, get_manager
from skills.loader import Skill, register_skill
from tools.registry import Risk, register_external

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG = PROJECT_ROOT / "mcp_servers.yaml"

_RISKS = {"read": Risk.READ, "write": Risk.WRITE, "danger": Risk.DANGER}

_loaded = False
_lock = threading.RLock()


def enabled() -> bool:
    raw = (os.getenv("MCP_ENABLED") or "").strip().lower()
    return raw in ("1", "true", "yes", "on")


def config_path() -> Path:
    raw = os.getenv("MCP_CONFIG")
    path = Path(raw) if raw else DEFAULT_CONFIG
    return path if path.is_absolute() else (PROJECT_ROOT / path)


def _risk_for(spec: dict, tool_name: str) -> Risk:
    raw = str((spec.get("risk_overrides") or {}).get(
        tool_name, spec.get("risk_default", "write"))).lower()
    return _RISKS.get(raw, Risk.WRITE)


def _prepare(spec: dict) -> dict:
    """把清单里相对项目根的 cwd 解析成绝对路径（子进程工作目录要明确）。"""
    spec = dict(spec)
    cwd = spec.get("cwd")
    if cwd:
        p = Path(str(cwd))
        spec["cwd"] = str(p if p.is_absolute() else (PROJECT_ROOT / p))
    return spec


class McpToolProxy:
    """注册进 TOOL_REGISTRY 的"函数"：把调用转发给远端 MCP server。"""

    def __init__(self, server: str, tool: str) -> None:
        self.server = server
        self.tool = tool

    def __call__(self, **kwargs) -> str:
        result = get_manager().call(self.server, self.tool, kwargs)
        text, is_error = flatten_result(result)
        if is_error:
            raise McpError(text)             # 交由 run_tool 统一转成"工具执行出错"
        return text

    def __repr__(self) -> str:
        return f"<McpToolProxy {self.server}.{self.tool}>"


def ensure_loaded() -> None:
    """装载清单里启用的 MCP server（幂等）。未启用则直接返回。"""
    global _loaded
    if _loaded:
        return
    with _lock:
        if _loaded:
            return
        _loaded = True                       # 先置位：并发/重入只会装载一次
        if not enabled():
            return
        path = config_path()
        if not path.exists():
            print(f"[warn] 未找到 MCP 清单：{path}")
            return
        try:
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except Exception as e:
            print(f"[warn] MCP 清单解析失败：{path}（{e}）")
            return
        for spec in (data.get("servers") or []):
            if not isinstance(spec, dict) or not spec.get("enabled"):
                continue
            try:
                _load_one(spec)
            except Exception as e:           # 单个 server 出问题不影响其它
                print(f"[warn] 装载 MCP server 失败：{spec.get('name')}（{e}）")


def _load_one(spec: dict) -> None:
    name = str(spec.get("name") or "").strip()
    if not name:
        print("[warn] MCP server 缺少 name，跳过")
        return

    conn = get_manager().connect(name, _prepare(spec))
    if conn.error or not conn.tools:
        print(f"[warn] MCP server {name} 不可用：{conn.error or '没有暴露任何工具'}")
        return

    registered: list[str] = []
    for tool in conn.tools:
        full = f"mcp_{name}__{tool.name}"
        register_external(
            full,
            tool.description or f"（来自 MCP server {name}）",
            tool.input_schema,
            McpToolProxy(name, tool.name),
            risk=_risk_for(spec, tool.name),
            skill=f"mcp:{name}",
            server=name,
        )
        registered.append(full)

    register_skill(Skill(
        name=f"mcp:{name}",
        description=spec.get("description") or f"外部 MCP server：{name}",
        instructions=spec.get("instructions") or "",
        version=str(spec.get("version", "1.0.0")),
        tools=registered,
    ))
    print(f"[mcp] 已装载 {name}：{len(registered)} 个工具 → {', '.join(registered)}")


def reset() -> None:
    """清空装载状态（仅测试用）。"""
    global _loaded
    with _lock:
        _loaded = False
