"""MCP 客户端桥：把 async 的 MCP SDK 包成同步可调用的接口。

为什么要"桥"：MCP 的 Python SDK 是 async 的，而本项目内核是同步的
（run_agent 跑在线程池里）；而且 stdio 会话是"上下文管理器"，必须常驻——
不能每次调用起一个子进程（每次握手要几百毫秒，还会留一堆僵尸进程）。

做法：
  1) 起一个后台线程，跑一个专属 event loop；
  2) 每个 MCP server 在上面挂一个常驻协程：打开会话 → initialize →
     tools/list → 然后循环处理 tools/call 请求；
  3) 同步侧通过线程安全的 concurrent.futures.Future 拿结果。

这就是标准的 "sync facade over async library"，代价只有一个后台线程。
"""
from __future__ import annotations

import asyncio
import atexit
import concurrent.futures
import json
import os
import threading
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from typing import Any


def call_timeout() -> float:
    try:
        return float(os.getenv("MCP_CALL_TIMEOUT", "60"))
    except ValueError:
        return 60.0


def connect_timeout() -> float:
    try:
        return float(os.getenv("MCP_CONNECT_TIMEOUT", "30"))
    except ValueError:
        return 30.0


class McpError(RuntimeError):
    """MCP 相关失败：连不上 / 调用超时 / 远端返回错误。"""


@dataclass
class McpTool:
    name: str
    description: str
    input_schema: dict


@dataclass
class ServerConn:
    name: str
    spec: dict
    ready: threading.Event = field(default_factory=threading.Event)
    queue: Any = None                    # asyncio.Queue，在 loop 线程里创建
    tools: list[McpTool] = field(default_factory=list)
    error: str | None = None
    closed: bool = False


def _env(spec: dict):
    """只把清单里显式声明的变量传给子进程（绝不整个 .env 塞过去）。"""
    raw = spec.get("env") or {}
    if not raw:
        return None
    return {str(k): str(v) for k, v in raw.items()}


@asynccontextmanager
async def _transport(spec: dict, transport: str):
    """按传输方式打开 MCP 会话的读写流，统一产出 (read, write)。"""
    if transport == "stdio":
        from mcp import StdioServerParameters
        from mcp.client.stdio import stdio_client
        params = StdioServerParameters(
            command=str(spec["command"]),
            args=[str(a) for a in (spec.get("args") or [])],
            env=_env(spec),
            cwd=spec.get("cwd") or None,
        )
        async with stdio_client(params) as streams:
            yield streams[0], streams[1]
    elif transport in ("http", "streamable-http", "streamable_http"):
        from mcp.client.streamable_http import streamablehttp_client
        async with streamablehttp_client(str(spec["url"])) as streams:
            yield streams[0], streams[1]
    else:
        raise ValueError(f"不支持的 transport：{transport}")


def flatten_result(result) -> tuple[str, bool]:
    """把 MCP 的 CallToolResult 拍平成 (文本, 是否错误)。"""
    parts: list[str] = []
    for block in (getattr(result, "content", None) or []):
        kind = getattr(block, "type", None)
        if kind == "text":
            parts.append(getattr(block, "text", "") or "")
        elif kind == "image":
            parts.append(f"[图片内容 mime={getattr(block, 'mime_type', '?')}（已省略）]")
        elif kind == "audio":
            parts.append("[音频内容（已省略）]")
        elif kind in ("resource_link", "resource"):
            parts.append(f"[资源 {getattr(block, 'uri', '')}]")
        else:
            parts.append(str(block))
    text = "\n".join(p for p in parts if p).strip()

    structured = getattr(result, "structured_content", None)
    if not text and structured:
        text = json.dumps(structured, ensure_ascii=False, default=str)
    return (text or "（工具返回空）"), bool(getattr(result, "is_error", False))


class McpManager:
    """一个进程一个实例；内部独占一个 event loop 线程。"""

    def __init__(self) -> None:
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._run_loop, name="mcp-loop",
                                        daemon=True)
        self._thread.start()
        self._conns: dict[str, ServerConn] = {}
        self._lock = threading.RLock()

    def _run_loop(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    # ---------------- 同步侧 API ----------------
    def connect(self, name: str, spec: dict) -> ServerConn:
        """启动并握手；返回的连接上带有 tools（失败则 error 非空）。"""
        with self._lock:
            conn = self._conns.get(name)
            if conn is not None:
                return conn
            conn = ServerConn(name=name, spec=dict(spec))
            self._conns[name] = conn
        asyncio.run_coroutine_threadsafe(self._serve(conn), self._loop)
        if not conn.ready.wait(connect_timeout()):
            conn.error = conn.error or "连接/握手超时"
            conn.ready.set()
        return conn

    def call(self, name: str, tool: str, arguments: dict, timeout: float | None = None):
        conn = self._conns.get(name)
        if conn is None or conn.queue is None:
            raise McpError(f"MCP server 不可用：{name}"
                           f"（{conn.error if conn else '未连接'}）")
        fut: concurrent.futures.Future = concurrent.futures.Future()
        self._loop.call_soon_threadsafe(conn.queue.put_nowait, (tool, arguments, fut))
        try:
            result, err = fut.result(timeout=timeout or call_timeout())
        except concurrent.futures.TimeoutError:
            raise McpError(f"调用 {name}.{tool} 超时")
        if err:
            raise McpError(err)
        return result

    def close_all(self) -> None:
        for conn in list(self._conns.values()):
            try:
                if conn.queue is not None:
                    self._loop.call_soon_threadsafe(conn.queue.put_nowait, None)
            except Exception:
                pass

    # ---------------- loop 侧实现 ----------------
    async def _serve(self, conn: ServerConn) -> None:
        try:
            from mcp import ClientSession
            conn.queue = asyncio.Queue()
            transport = str(conn.spec.get("transport") or "stdio").lower()
            async with _transport(conn.spec, transport) as (read, write):
                async with ClientSession(read, write) as session:
                    await self._pump(conn, session)
        except Exception as e:
            conn.error = f"{type(e).__name__}: {e}"
        finally:
            conn.closed = True
            conn.ready.set()

    async def _pump(self, conn: ServerConn, session) -> None:
        await session.initialize()
        listing = await session.list_tools()
        conn.tools = [
            McpTool(name=t.name,
                    description=(getattr(t, "description", "") or ""),
                    input_schema=dict(getattr(t, "input_schema", None) or {}))
            for t in listing.tools
        ]
        conn.error = None
        conn.ready.set()                     # ★ 握手完成，放开同步侧
        while True:
            item = await conn.queue.get()
            if item is None:                 # 关闭信号
                break
            tool, args, fut = item
            try:
                res = await session.call_tool(tool, args or {})
                fut.set_result((res, None))
            except Exception as e:           # 单个调用失败不终止会话
                fut.set_result((None, f"{type(e).__name__}: {e}"))


_manager: McpManager | None = None
_manager_lock = threading.Lock()


def get_manager() -> McpManager:
    """进程级单例；退出时自动关闭所有会话（连带杀掉子进程）。"""
    global _manager
    if _manager is None:
        with _manager_lock:
            if _manager is None:
                _manager = McpManager()
                atexit.register(_manager.close_all)
    return _manager
