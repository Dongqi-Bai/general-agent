"""技能装配器：按需把若干技能合成一次运行要用的 (工具 schema, 指令)。

这是「可装配」的落点：同一个 Agent 换个 skill_names，就能换一套工具与提示词。
"""
from __future__ import annotations

from skills.loader import Skill, load_all


def _selected(skill_names: list[str] | None) -> list[Skill]:
    skills = load_all()
    names = list(skills.keys()) if skill_names is None else list(skill_names)
    missing = [n for n in names if n not in skills]
    if missing:
        raise KeyError(f"未找到技能：{missing}；可用技能：{sorted(skills)}")
    return [skills[n] for n in names]


def assemble(skill_names: list[str] | None = None) -> tuple[list[dict], str]:
    """skill_names=None → 全部技能；[] → 空；列表 → 只装配指定技能。"""
    tools, seen, prompts = [], set(), []
    for sk in _selected(skill_names):
        for s in sk.schemas():
            if s["name"] in seen:
                continue
            seen.add(s["name"])
            tools.append(s)
        if sk.instructions.strip():
            prompts.append(f"【技能：{sk.name}】\n{sk.instructions.strip()}")
    return tools, "\n\n".join(prompts)


def skill_instructions(skill_names: list[str] | None = None) -> str:
    return assemble(skill_names)[1]


def skill_tool_names(skill_names: list[str] | None = None) -> list[str]:
    return [t for sk in _selected(skill_names) for t in sk.tools]


def skill_catalog(skill_names: list[str] | None = None) -> str:
    """给 Planner 看的技能目录：按技能分组，避免把全部工具平铺进提示词。"""
    rows = [f"- {sk.name}（{sk.description}） 工具：{', '.join(sk.tools) or '无'}"
            for sk in _selected(skill_names)]
    return "\n".join(rows) or "（无）"


def available_skills() -> list[str]:
    return sorted(load_all().keys())
