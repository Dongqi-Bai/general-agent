"""技能系统。

技能（Skill）= 一组工具 + 一段专属指令 + 元数据，用一个目录声明：
    skills/builtin/<name>/skill.yaml   清单：name / description / instructions / tools
    skills/builtin/<name>/tools.py     实现：用 @tool 装饰器注册工具

loader 负责「发现 + 装载」，assembler 负责「按需装配出 (tools, instructions)」。
加一组能力 = 放一个目录 + 写一个清单，不需要改主体代码。
"""
