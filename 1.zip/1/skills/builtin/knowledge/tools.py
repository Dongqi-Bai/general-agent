"""knowledge 技能：项目检索 + 长期记忆。

- search_knowledge：只读，检索项目代码/文档（第 20b 步）
- remember：       写入，把事实沉淀进长期记忆（第 20c 步，Risk.WRITE → 走 HITL 审批）
- recall：         只读，在长期记忆里检索

索引是懒加载的：第一次调用 search_knowledge 时才建（几十毫秒），之后进程内复用。
"""
from __future__ import annotations

import threading

from pydantic import BaseModel, Field

from config import Config
from memory.store import get_store
from retrieval.chunker import build_chunks
from retrieval.index import Index
from retrieval.vector import build_search_index
import tenant
from tools.registry import Risk, tool

cfg = Config()

MAX_RESULT_CHARS = 1800      # 单次检索结果上限，别把上下文撑爆
MAX_CHUNK_CHARS = 450        # 单个片段最多展示多少字

_INDEX: Index | None = None
_INDEX_LOCK = threading.Lock()


def knowledge_index() -> Index:
    """懒加载项目索引；进程内只建一次。"""
    global _INDEX
    if _INDEX is None:
        with _INDEX_LOCK:
            if _INDEX is None:
                _files, chunks = build_chunks(
                    cfg.knowledge_root, cfg.chunk_chars, cfg.chunk_overlap
                )
                _INDEX = build_search_index(chunks)   # 语义可用→混合检索；否则纯 BM25
    return _INDEX


def rebuild_index() -> Index:
    """强制重建（文件改动后想立即生效时可调用）。"""
    global _INDEX
    with _INDEX_LOCK:
        _INDEX = None
    return knowledge_index()


class SearchKnowledgeArgs(BaseModel):
    query: str = Field(description="要查的关键词或问题；用项目里出现过的标识符/术语更容易命中")
    top_k: int = Field(default=3, ge=1, le=10, description="返回多少条片段")


@tool("search_knowledge", "在项目代码与文档里检索相关片段，返回来源文件与行号",
      SearchKnowledgeArgs, untrusted=True)             # 检索片段是不可控数据
def search_knowledge(query: str, top_k: int = 3) -> str:
    hits = knowledge_index().search(query, top_k)
    if not hits:
        return "没有检索到相关片段。换个说法，或用更具体的标识符（如函数名/常量名）再试。"

    parts, used = [], 0
    for i, h in enumerate(hits, 1):
        body = h.chunk.text.strip()
        if len(body) > MAX_CHUNK_CHARS:
            body = body[:MAX_CHUNK_CHARS] + "…（片段已截断）"
        block = f"[{i}] {h.chunk.cite}（score={h.score:.2f}）\n{body}"
        if used + len(block) > MAX_RESULT_CHARS:
            break
        used += len(block)
        parts.append(block)
    if len(parts) < len(hits):
        parts.append(f"（共命中 {len(hits)} 条，为控制长度只展示了前 {len(parts)} 条）")
    return "\n\n".join(parts)


class RememberArgs(BaseModel):
    text: str = Field(description="要长期记住的事实，一句话写清；不要写过程")
    tags: list[str] = Field(default_factory=list,
                            description="可选标签，如 ['偏好']、['项目约定']")


@tool("remember", "把一条值得长期记住的事实写入长期记忆（需人工确认）",
      RememberArgs, risk=Risk.WRITE)
def remember(text: str, tags: list[str] | None = None) -> str:
    m = get_store(cfg.memory_path).add(text, tags=tags, user=tenant.current_user())
    return f"已写入长期记忆（id={m.id}）：{m.text}"


class RecallArgs(BaseModel):
    query: str = Field(description="想回忆的事情，如 '用户偏好'、'项目约定'")
    top_k: int = Field(default=3, ge=1, le=10)


@tool("recall", "在长期记忆里检索与问题相关的事实", RecallArgs,
      untrusted=True)                                  # 记忆条目是不可控数据
def recall(query: str, top_k: int = 3) -> str:
    hits = get_store(cfg.memory_path).search(query, top_k, user=tenant.current_user())
    if not hits:
        return "长期记忆里没有相关条目。"
    lines = []
    for m, _score in hits:
        tag = f"（标签：{', '.join(m.tags)}）" if m.tags else ""
        lines.append(f"- {m.text}{tag}")
    return "\n".join(lines)
