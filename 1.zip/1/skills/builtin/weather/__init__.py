"""weather 技能包。"""
