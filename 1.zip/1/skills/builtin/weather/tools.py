"""weather 技能：查询城市天气。"""
from pydantic import BaseModel, Field

from tools.registry import tool


class WeatherArgs(BaseModel):
    city: str = Field(description="一个城市名称，如北京，上海")


@tool("get_weather", "查询某个城市天气", WeatherArgs)
def get_weather(city: str) -> str:
    return f"{city}，今天晴，温度26度"
