"""files 技能：沙箱内文本文件的读写。"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, field_validator

from tools.registry import Risk, tool
from tools.sandbox import resolve_in_sandbox

MAX_READ_BYTES = 256 * 1024        # 单次最多读 256KB，防大文件塞爆上下文
MAX_WRITE_BYTES = 1024 * 1024      # 单次最多写 1MB


class ReadFileArgs(BaseModel):
    path: str = Field(description="要读取的文件路径，相对沙箱根目录，如 1/README.md")
    start_line: int | None = Field(default=None, ge=1, description="从第几行开始读（1 起，可选）")
    max_lines: int | None = Field(default=None, ge=1, le=500, description="最多读多少行（可选）")

    @field_validator("path")
    @classmethod
    def _check(cls, v: str) -> str:
        return resolve_in_sandbox(v)     # 堵住「读越权」


class WriteFileArgs(BaseModel):
    path: str = Field(description="要写入的文件路径，相对沙箱根目录，如 1/notes.txt")
    content: str = Field(description="要写入的文本内容")
    mode: Literal["create", "overwrite", "append"] = Field(
        default="create",
        description="create=仅新建(已存在则报错)；overwrite=整文件覆盖；append=追加到末尾",
    )
    create_dirs: bool = Field(default=False, description="父目录不存在时是否自动创建")

    @field_validator("path")
    @classmethod
    def _check(cls, v: str) -> str:
        return resolve_in_sandbox(v)     # 复用同一套越界检查


@tool("write_file", "把文本写入沙箱内的文件（create/overwrite/append）",
      WriteFileArgs, risk=Risk.WRITE)
def write_file(path: str, content: str, mode: str = "create",
               create_dirs: bool = False) -> str:
    p = Path(path)                                  # 已是校验过的沙箱内绝对路径

    data = content.encode("utf-8")
    if len(data) > MAX_WRITE_BYTES:
        raise ValueError(f"内容过大（{len(data)} 字节），上限 {MAX_WRITE_BYTES}")

    if p.exists() and p.is_dir():
        raise IsADirectoryError(f"目标是目录，不能写入：{p}")

    parent = p.parent
    if not parent.exists():
        if create_dirs:
            parent.mkdir(parents=True, exist_ok=True)
        else:
            raise FileNotFoundError(f"父目录不存在：{parent}（可设 create_dirs=true）")

    if mode == "create" and p.exists():
        raise FileExistsError(f"文件已存在：{p}（如需覆盖请用 mode=overwrite）")

    existed = p.exists()
    if mode == "append":
        with p.open("a", encoding="utf-8", newline="\n") as f:
            f.write(content)
    else:
        # 原子写：先写同目录临时文件，再原子替换，避免留下半截文件
        fd, tmp = tempfile.mkstemp(dir=str(parent), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                f.write(content)
            os.replace(tmp, p)
        except BaseException:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise

    n_lines = content.count("\n") + (0 if content.endswith("\n") or not content else 1)
    state = "覆盖" if existed else "新建"
    return f"写入成功：{p}（{mode}｜{state}｜{len(data)} 字节｜{n_lines} 行）"


@tool("read_file", "读取沙箱内某个文本文件的内容，可指定行范围", ReadFileArgs,
      untrusted=True)                                  # 文件内容是不可控数据
def read_file(path: str, start_line: int | None = None,
              max_lines: int | None = None) -> str:
    p = Path(path)                 # 已是校验过的绝对路径

    if not p.exists():
        raise FileNotFoundError(f"文件不存在：{p}")
    if not p.is_file():
        raise IsADirectoryError(f"不是文件（可能是目录）：{p}")

    size = p.stat().st_size
    with p.open("rb") as f:
        raw = f.read(MAX_READ_BYTES)               # 最多读这么多字节
    truncated_by_size = size > MAX_READ_BYTES

    if b"\x00" in raw[:1024]:
        raise ValueError(f"疑似二进制文件，无法作为文本读取：{p}")

    text = raw.decode("utf-8", errors="replace")   # 坏字节替换，不崩
    lines = text.splitlines()

    start = (start_line or 1) - 1
    end = len(lines) if max_lines is None else start + max_lines
    window = lines[start:end]

    if not window:
        return f"（文件共 {len(lines)} 行，指定范围内没有内容）"

    body = "\n".join(f"{i + 1:>4}| {ln}" for i, ln in enumerate(window, start=start))
    if end < len(lines) or truncated_by_size:
        body += f"\n…（已截断，文件共约 {len(lines)} 行，未显示后续内容）"
    return body
