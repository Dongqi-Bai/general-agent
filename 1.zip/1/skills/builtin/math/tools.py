"""math 技能：数值计算。"""
from pydantic import BaseModel, Field

from tools.registry import tool


class CalculatorArgs(BaseModel):
    a: float = Field(description="第一个乘数")
    b: float = Field(description="第二个乘数")


@tool("calculator", "计算两个数的乘积", CalculatorArgs)
def calculator(a, b) -> str:
    return str(a * b)
