"""内置技能目录。每个子目录是一个技能（skill.yaml + tools.py）。"""
