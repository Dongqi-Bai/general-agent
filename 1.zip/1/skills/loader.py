"""技能装载器：发现技能目录 → 读清单 → 导入 tools 模块 → 校验并回填技能归属。

设计要点：
- 清单（skill.yaml）是技能归属的唯一事实来源，工具里不用手写 skill 名；
- 装载是幂等的（load_all 只真正执行一次），线程安全；
- 不在 import 期做任何装载，避免 tools 与 skills 循环导入。
"""
from __future__ import annotations

import importlib
import threading
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from tools.registry import TOOL_REGISTRY

BUILTIN_DIR = Path(__file__).resolve().parent / "builtin"
MANIFEST_NAME = "skill.yaml"
REQUIRED_FIELDS = ("name", "description", "tools")


@dataclass
class Skill:
    name: str
    description: str
    instructions: str = ""
    version: str = "0.1.0"
    tools: list[str] = field(default_factory=list)
    path: Path | None = None

    def schemas(self) -> list[dict]:
        return [TOOL_REGISTRY[t]["schema"] for t in self.tools if t in TOOL_REGISTRY]


_RLOCK = threading.RLock()
_loaded = False
_skills: dict[str, Skill] = {}


def discover() -> list[str]:
    """返回内置技能目录名（按字母序）；没有清单的目录会被忽略。"""
    if not BUILTIN_DIR.exists():
        return []
    return [d.name for d in sorted(BUILTIN_DIR.iterdir())
            if d.is_dir() and (d / MANIFEST_NAME).exists()]


def _read_manifest(name: str) -> dict:
    path = BUILTIN_DIR / name / MANIFEST_NAME
    data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    if not isinstance(data, dict):
        raise RuntimeError(f"技能 {name} 的清单格式不对：{path}")
    for f in REQUIRED_FIELDS:
        if f not in data:
            raise RuntimeError(f"技能 {name} 的清单缺少字段 {f}：{path}")
    return data


def load_skill(name: str) -> Skill:
    """装载单个技能（带缓存，线程安全）。"""
    if name in _skills:
        return _skills[name]
    with _RLOCK:
        if name in _skills:                      # 双重检查
            return _skills[name]
        manifest = _read_manifest(name)

        importlib.import_module(f"skills.builtin.{name}.tools")   # 触发 @tool 注册

        tools = [str(t) for t in manifest["tools"]]
        missing = [t for t in tools if t not in TOOL_REGISTRY]
        if missing:
            raise RuntimeError(f"技能 {name} 声明的工具没有注册：{missing}")

        conflict = {t: TOOL_REGISTRY[t]["skill"] for t in tools
                    if TOOL_REGISTRY[t].get("skill") not in (None, name)}
        if conflict:
            raise RuntimeError(f"工具被多个技能认领：{conflict}")

        for t in tools:                          # 回填技能归属
            TOOL_REGISTRY[t]["skill"] = name

        skill = Skill(
            name=manifest["name"],
            description=manifest.get("description", ""),
            instructions=manifest.get("instructions", "") or "",
            version=str(manifest.get("version", "0.1.0")),
            tools=tools,
            path=BUILTIN_DIR / name,
        )
        _skills[name] = skill
        return skill


def register_skill(skill: Skill) -> None:
    """登记一个非目录来源的技能（例如 MCP server 动态暴露的工具集）。"""
    with _RLOCK:
        _skills[skill.name] = skill


def _load_external_skills() -> None:
    """装载外部技能（MCP）。延迟 import，避免 tools / skills / mcp_bridge 循环导入。"""
    try:
        from mcp_bridge.loader import ensure_loaded
    except Exception:
        return
    try:
        ensure_loaded()
    except Exception as e:                    # 外部服务绝不能拖垮本地技能
        print(f"[warn] 装载外部 MCP 技能失败：{e}")


def load_all() -> dict[str, Skill]:
    """装载全部技能（幂等）。内置技能来自目录，外部技能来自 MCP server（第 21 步）。"""
    global _loaded
    if _loaded:
        return _skills
    with _RLOCK:
        if not _loaded:
            for name in discover():
                load_skill(name)
            _loaded = True
    _load_external_skills()
    return _skills


def get_skill(name: str) -> Skill | None:
    return _skills.get(name)


def reset() -> None:
    """清空装载缓存（仅测试用）。"""
    global _loaded
    with _RLOCK:
        _skills.clear()
        _loaded = False
