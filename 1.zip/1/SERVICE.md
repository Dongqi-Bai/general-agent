# 第 14 步 · 服务化（CLI → HTTP 服务）

## 这一步解决了什么问题

内核（`run_agent`）以前只会做两件"程序"才会做的事：把流式文本 `print` 到终端、
用 `input()` 阻塞地问用户是否放行写操作。这两种假设让 Agent 只能活在一个终端里：
没法多用户、没法并发、没法被前端调用。

服务化 = 把这两个假设从内核里拿掉：

- **输出**：`print` → `emit(event)` 回调（内核只产出事件，谁来消费由外壳决定）；
- **审批**：`input()` → 可注入的审批器（`set_approver`），由外壳决定怎么问人；
- **阻塞**：同步内核丢进线程池跑，事件用 `loop.call_soon_threadsafe` 送回事件循环，
  审批用 `concurrent.futures.Future` 跨线程唤醒。

## 改了哪些文件

| 文件 | 改动 |
| --- | --- |
| `agent_loop.py` | `run_agent(..., emit=None)`：新增可选事件出口；`print` 改为 `emit`；工具调用前后发 `tool_start` / `tool_result` 事件。默认 `emit` 仍是终端打印，所以 CLI 行为不变。 |
| `tools/permissions.py` | 新增 `set_approver` / `reset_approver` / `describe`；`_ask_user` 优先走注入的审批器，没有才回退到终端 `input()`。 |
| `config/__init__.py` | 新增 `approval_timeout_s`（env `APPROVAL_TIMEOUT_S`，默认 300 秒）。 |
| `service.py` | **新增**：FastAPI 应用，SSE 事件流 + 审批端点 + 会话锁。 |

**向后兼容**：`run_agent(conv, t, cfg)` 老调法（CLI、`evals/`、`orchestrator.py`）全部照旧，
`run_tool` 的签名也没动。

## 事件协议

SSE 每条形如 `data: {json}\n\n`，`type` 取值：

| type | 关键字段 | 说明 |
| --- | --- | --- |
| `text_delta` | `text` | 模型流式文本增量 |
| `tool_start` | `name` / `arguments` | 即将执行某个工具 |
| `tool_result` | `name` / `ok` / `result` | 工具执行结果（含被拒绝的情况） |
| `approval_required` | `id` / `tool` / `detail` | 需要人工确认，客户端应弹窗并回调审批端点 |
| `finished` | `status` / `final_text` / `steps` / `usage` / `error` | 本次运行结束 |
| `error` | `error` | 内核抛异常时的兜底事件 |

## 怎么跑

```bash
cd "1"
uvicorn service:app --host 127.0.0.1 --port 8000
```

依赖：`fastapi`、`uvicorn`（本机已安装）。

### 调用流程

```bash
# 1) 提交消息，拿到 run_id
curl -X POST http://127.0.0.1:8000/sessions/demo/messages \
     -H "Content-Type: application/json" \
     -d '{"text":"帮我算 123*456，并写进 1/notes.txt"}'
# -> {"run_id":"..."}

# 2) 订阅这次运行的事件（text_delta / tool_start / approval_required / finished）
curl -N http://127.0.0.1:8000/runs/<run_id>/events

# 3) 如果收到 approval_required，就批准或拒绝
curl -X POST http://127.0.0.1:8000/approvals/<approval_id> \
     -H "Content-Type: application/json" -d '{"approved":true}'
```

也可以一步到位（提交消息后直接返回本次运行的 SSE）：

```bash
curl -N -X POST http://127.0.0.1:8000/sessions/demo/messages/stream \
     -H "Content-Type: application/json" \
     -d '{"text":"今天天津天气如何"}'
```

健康检查：`GET /health`。

## 设计说明与已知边界

- **同一 `session_id` 串行**：`_run_sync` 用 `SESSION_LOCKS[sid]` 加锁，避免并发请求
  互相覆盖会话文件；不同会话可并行。
- **审批超时**：默认 300 秒（`APPROVAL_TIMEOUT_S`），超时按"拒绝"处理，避免运行永久挂起。
- **心跳**：SSE 15 秒没事件会发 `: ping`，防止网关断开长连接。
- **未做（下一步）**：`RUNS` 目前是进程内字典，进程重启即丢；多实例部署要换成
  Redis/DB 承载 run 状态与待审批项。鉴权、按用户限流也还没加。
- **线程池**：`asyncio.to_thread` 走默认线程池，会话很多时可换成专用 `ThreadPoolExecutor`
  或把内核改成 `AsyncOpenAI` 全异步。

---

# 第 16 步 · 服务闭环：多 Agent 路径也能被消费

## 这一步解决了什么问题

第 12 步做了 planner / orchestrator（规划 → 分层并行执行 → Critic 评审 → 失败重规划），
但它只能在终端 `python orchestrator.py` 跑，全过程 `print` 到 stdout ——
服务 / 前端完全看不到"计划、分层、子任务进度、评审、重规划"。

这一步把编排器也事件化并接进服务：

- **orchestrator**：`run_plan(goal, cfg, emit=..., approver=...)`。默认 `emit` 仍是终端，
  CLI 观感不变；换成 SSE 出口即可被消费。
- **HITL**：子任务审批器不再写死终端 `input()`，改由 `approver` 参数注入（服务传 HTTP 审批器）。
- **service**：新增 `/plans` 与 `/plans/stream`，复用既有 SSE / 审批 / `RUNS` 机制。

## 改了哪些文件

| 文件 | 改动 |
| --- | --- |
| `orchestrator.py` | 新增 `_console_emit`（默认终端渲染）；`run_plan(*, emit=None, approver=None)`；`_execute_layers(..., emit, approver)`；`_run_one(..., approver)`。原 `print` 全部改为结构化事件。 |
| `service.py` | 新增 `PlanIn`、`_run_plan_sync`、`_start_plan`，以及 `POST /plans`、`POST /plans/stream`。 |

**向后兼容**：`emit` / `approver` 默认 `None`，`python orchestrator.py` 行为与观感不变。

## 编排事件协议

| type | 关键字段 | 说明 |
| --- | --- | --- |
| `plan` | `round` / `layers` / `subtasks[{id,role,goal,depends_on}]` | 本轮计划全景 |
| `layer_start` | `round` / `layer` / `concurrency` / `subtasks` | 某一层开始并行执行 |
| `subtask_text` | `id` / `role` / `text` | 该子任务的流式文本（按层顺序整体回放） |
| `subtask_done` | `id` / `role` / `status` / `tokens` / `error` | 子任务结束（含跳过 / 超预算 / 超时） |
| `review_start` | `round` | 开始评审 |
| `review` | `round` / `passed` / `issues` / `missing` | 评审结论 |
| `replan` | `round` | 进入下一轮重规划 |
| `notice` | `message` | 提示（如预算 / 时间耗尽） |
| `finished` | `status` / `final_text` / `total_tokens` / `rounds` / `plan_trace_id` / `review` | 编排结束 |
| `approval_required` | `id` / `tool` / `detail` | 与单循环同一套 HITL 事件 |

## 怎么调用

```bash
# 一步到位：提交目标，SSE 收全过程
curl -N -X POST http://127.0.0.1:8000/plans/stream \
     -H "Content-Type: application/json" \
     -d '{"goal":"查一下天津今天的天气，再算 123*456，把结果写进 1/plan_result.txt"}'
```

或分两步（与 `/sessions/{sid}/messages` 同构）：

```bash
curl -X POST http://127.0.0.1:8000/plans -H "Content-Type: application/json" \
     -d '{"goal":"..."}'          # -> {"run_id":"..."}
curl -N http://127.0.0.1:8000/runs/<run_id>/events
```

收到 `approval_required` 时回调审批端点（与单循环完全一致）：

```bash
curl -X POST http://127.0.0.1:8000/approvals/<approval_id> \
     -H "Content-Type: application/json" -d '{"approved":true}'
```

## 已知边界

- **子任务文本是"整段回放"，不是逐 token 流式**：并发子任务的输出仍在各自缓冲，
  等该子任务结束后由主线程按层序发出，以免互相穿插。要真正的逐 token 流式，
  需把子任务内的 `text_delta` 打上 `id` 后直接转发。
- **计划运行暂不绑定用户会话**：`/plans` 不接收 `sid`，子任务各自用 `trace_id-r?-t?`
  命名的独立会话，也没有把最终答复写回某个用户会话。
- run 元数据与取消：见第 17 步（`RUN_STORE` 可切 sqlite 落盘）。

---

# 第 17 步 · 可运维的 run 生命周期：状态外置 + 取消 + 多实例

## 这一步解决了什么问题

第 14 / 16 步把单循环与编排都接进了服务，但 run 的账本还是 `RUNS: dict` —— 纯进程内存：

- **重启即失忆**：进程一挂，所有 run 记录没了；
- **无法取消**：长跑的任务只能等它自己结束；
- **多实例互相看不见**：A 实例起的 run，B 实例既查不到也停不掉。

这一步做三件事：

1. **状态外置**：新增 `run_store.py`，run 元数据（状态 / 目标 / 时间 / 错误 / 摘要 /
   取消标记）交给 store。默认 `InMemoryRunStore`（行为同以前），设 `RUN_STORE=sqlite`
   则落盘，重启后仍可查、多实例共享。
2. **取消**：内核新增 `CancelToken`，在"步 / 层"边界协作式检查；
   `POST /runs/{id}/cancel` 先写 store 标记，再置本进程令牌。
3. **多实例**：run 元数据与取消请求经 store 共享；实例 B 可查实例 A 的 run 并发起取消。

## 改了哪些文件

| 文件 | 改动 |
| --- | --- |
| `data/dataclass.py` | `Status` 新增 `CANCELLED`；新增 `CancelToken`（可绑定外部判定函数）。 |
| `agent_loop.py` | `run_agent(..., cancel=None)`：每步开始前检查，取消则返回 `CANCELLED`。 |
| `orchestrator.py` | `run_plan(..., cancel=None)`；逐层检查并下传；取消时跳过评审、`finished.status="cancelled"`。 |
| `run_store.py` | **新增**：`RunRecord` + `InMemoryRunStore` + `SqliteRunStore` + `get_store()`。 |
| `service.py` | `RUNS` → `LIVE`（进程内事件通道）+ `_STORE`（元数据）+ `CANCELS`（令牌）；新增 `GET /runs`、`GET /runs/{id}`、`POST /runs/{id}/cancel`。 |

## 配置

| 环境变量 | 默认 | 说明 |
| --- | --- | --- |
| `RUN_STORE` | `memory` | `memory` 或 `sqlite` |
| `RUN_STORE_PATH` | `1/runs.db` | sqlite 文件路径（相对 `1/`） |

## 新增端点

| 方法 | 路径 | 说明 |
| --- | --- | --- |
| `GET` | `/runs?limit=50` | 列出最近的 run（读 store） |
| `GET` | `/runs/{run_id}` | 查询单个 run 的状态（读 store） |
| `POST` | `/runs/{run_id}/cancel` | 请求取消；返回 `{ok, local, status}` |

## 取消的语义（重要）

- 取消是**协作式**的：内核在每一步、编排在每一层开始前检查。**正在进行的单次模型 / 工具调用
  不会被立刻打断**，会在该步结束后生效。
- 取消会体现在结果里：单循环返回 `Status.CANCELLED`，编排的 `finished.status="cancelled"`。
- `cancel` 返回里的 `local` 表示该 run 是否就在本实例：`true` 则立即置位；`false` 说明请求
  已写进 store，运行该 run 的实例会在下一个边界读到。

## 已知边界（如实说明）

- **实时事件流仍是进程内的**：`LIVE` 里的 `asyncio.Queue` 无法外置。跨实例目前只共享
  **元数据与取消请求**；要在 B 实例实时消费 A 实例的事件，需要消息中间件（Redis pub/sub）。
  对不在本实例的 run 调 `/runs/{id}/events` 会返回 409 并说明原因。
- **SQLite 适合单机多进程 / 小规模**；高并发多实例建议换 Redis / Postgres。
- `PENDING`（待审批）与 `SESSION_LOCKS` 仍是进程内的。

---

# 第 23 步 · 鉴权与多租户（谁是用户）

## 这一步解决了什么问题

服务前几步已经能多会话、多实例、可取消，但**没有「用户」这个概念**：

- `sid` 由客户端随便给，谁都能读别人的会话；
- `GET /runs` 把**所有** run（连同 `target`：会话名或任务目标）列给任何调用者；
- 谁都能取消别人的 run、批准别人的写操作；
- 而且 `session_id` 直接参与拼文件名，`../` 可以越界读写 —— 一个真实的路径穿越洞。

这一步回答两个问题：**你是谁？数据归谁？**

## 改了哪些文件

| 文件 | 改动 |
| --- | --- |
| `auth.py` | **新增**：`AGENT_USERS` 解析、API Key → 用户、`session_key()` 租户命名空间、名字校验（堵路径穿越）。 |
| `service.py` | 所有业务端点加 `Depends(current_user)`；会话按用户隔离；run 列表/查询/取消/事件做归属校验；审批记录归属人。 |
| `run_store.py` | `RunRecord` 新增 `user` 字段；`list(limit, user=...)` 按用户过滤；SQLite 建表加 `user` 列并**自动迁移老库**（显式列名，不依赖物理顺序）。 |
| `config/__init__.py` | 新增 `agent_users`（env `AGENT_USERS`）类型化视图。 |

## 怎么用

```bash
# 开启鉴权：user:key 逗号分隔
export AGENT_USERS="alice:key-a,bob:key-b"      # Windows: set / $env:

# 带 key 调（两种方式都行）
curl -H "Authorization: Bearer key-a"  http://127.0.0.1:8000/runs
curl -H "X-API-Key: key-a"             http://127.0.0.1:8000/runs
```

**向后兼容**：`AGENT_USERS` 留空 = 关闭鉴权（本地开发），所有请求归属用户 `local`，
会话文件名不变（仍是 `sessions/demo.json`），既有 CLI / 评测 / 调用方式都不受影响。

## 隔离规则

| 资源 | 隔离方式 |
| --- | --- |
| 会话 | 磁盘上 `<user>__<sid>.json`（鉴权开启时）；同名 `sid` 在不同用户下互不覆盖 |
| run 列表 | `GET /runs` 只返回本人的 |
| run 查询 / 取消 / 事件 | 非本人一律 **404**（不泄露「存在性」） |
| 待审批项 | 记录归属人，只能批准自己那次运行里的审批 |

## 顺带修掉的洞

`session_id` 此前没有校验，直接被拼进 `sessions/<sid>.json`，`sid=../../x` 可越界。
现在 `user` / `session_id` 统一限制为 `[A-Za-z0-9_-]{1,64}`，非法直接 400。

## 已知边界（如实说明）

- **静态 Key，无过期、无轮换、无撤销**：改 `AGENT_USERS` 并重启才生效。
- **明文比对**：Key 直接字符串比较，没做哈希；适合内部/小规模，不适合对公网暴露。
- **无 RBAC / 组织**：只有「用户」一层，没有角色、权限、配额（配额是第 24 步）。
- **批处理路径未隔离**：`/plans` 的子任务会话用的是内部命名，未按用户前缀；
  但 run 归属与事件订阅已按用户隔离。
- **`/health` 不需要鉴权**（给探活用），其余业务端点全部需要。
