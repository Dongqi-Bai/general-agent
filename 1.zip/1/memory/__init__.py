"""第 20c 步 · 长期记忆存储。

和 Conversation.summary 的区别：
    summary 是**会话内**的压缩，换个 session 就没了；
    这里是**跨会话**的事实，落在硬盘上，进程重启还在。
"""
