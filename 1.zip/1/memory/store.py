"""长期记忆：一行一条 JSON（JSONL）落盘 + 复用 BM25 做检索。

为什么用 JSONL：追加即写、无需事务、出问题能直接打开看、无第三方依赖。
为什么不直接上向量库：记忆条数通常很少（几百条），BM25 足够；
将来要换 embedding，只需替换索引构造那几行。

第 27 步的三处改动：
- **按用户隔离（user 维度）**：检索只召回本人的记忆 —— 之前是全局检索，
  bob 的 recall 会召回 alice 的记忆（跨租户泄漏）；
- **去重**：同一事实重复写入只刷新时间，不新增行（归一化 + 二元组相似度）；
- **容量上限**：每个用户最多 N 条，超出淘汰最旧。

边界：本进程内缓存了记忆列表，别的进程追加的条目要重启才可见
（单机单进程够用；多实例共享记忆需要换成数据库）。
"""
from __future__ import annotations

import json
import os
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path

from retrieval.chunker import Chunk
from retrieval.index import Index
from retrieval.vector import build_search_index


def _int_env(name: str, default: int) -> int:
    try:
        return int(os.getenv(name) or default)
    except ValueError:
        return default


def _float_env(name: str, default: float) -> float:
    try:
        return float(os.getenv(name) or default)
    except ValueError:
        return default


def max_per_user() -> int:
    return _int_env("MEMORY_MAX_PER_USER", 500)


def dedup_similarity() -> float:
    return _float_env("MEMORY_DEDUP_SIMILARITY", 0.85)


@dataclass
class Memory:
    id: str
    text: str
    tags: list[str] = field(default_factory=list)
    session_id: str = ""
    user: str = ""                 # 第 27 步：归属用户（"" = 单租户模式）
    created_at: float = 0.0
    updated_at: float = 0.0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Memory":
        return cls(
            id=str(d.get("id") or uuid.uuid4().hex[:12]),
            text=str(d.get("text", "")),
            tags=list(d.get("tags") or []),
            session_id=str(d.get("session_id") or ""),
            user=str(d.get("user") or ""),
            created_at=float(d.get("created_at") or 0.0),
            updated_at=float(d.get("updated_at") or d.get("created_at") or 0.0),
        )


def _norm(text: str) -> str:
    """归一化：去空白、统一大小写、统一标点，用于判重。"""
    t = " ".join((text or "").split()).casefold()
    for a, b in (("，", ","), ("。", "."), ("；", ";"), ("：", ":"), ("！", "!"),
                 ("？", "?"), ("（", "("), ("）", ")"), ("、", ",")):
        t = t.replace(a, b)
    return t


def _grams(text: str) -> set[str]:
    """字符二元组，用于粗粒度相似度（中英混排都吃得下）。"""
    t = _norm(text)
    if not t:
        return set()
    if len(t) == 1:
        return {t}
    return {t[i:i + 2] for i in range(len(t) - 1)}


def _similar(a: str, b: str) -> float:
    ga, gb = _grams(a), _grams(b)
    if not ga or not gb:
        return 0.0
    return len(ga & gb) / len(ga | gb)


class MemoryStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._lock = threading.RLock()
        self._memories: list[Memory] = []
        self._indexes: dict[str, Index] = {}      # 按用户分片的检索索引
        self._sig: tuple | None = None            # 文件指纹，用于跨进程感知变更
        self._load()
        self._sig = self._signature()

    # ---------- 读写 ----------
    def _load(self) -> None:
        if not self.path.exists():
            return
        try:
            raw = self.path.read_text(encoding="utf-8")
        except OSError:
            return
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:                       # 坏行跳过，不让一条脏数据毁掉整个记忆
                self._memories.append(Memory.from_dict(json.loads(line)))
            except (ValueError, TypeError):
                continue

    def _signature(self):
        """文件指纹（mtime + size）：别的进程改动过就能看出来。"""
        try:
            st = self.path.stat()
        except OSError:
            return None
        return (st.st_mtime_ns, st.st_size)

    def _reload_if_changed(self) -> None:
        """多进程场景：别的进程写了记忆，本进程读之前先感知一次。"""
        sig = self._signature()
        if sig == self._sig:
            return
        self._memories = []
        self._indexes.clear()
        self._load()
        self._sig = sig

    def _write_all(self) -> None:
        """整文件原子重写（去重合并 / 淘汰 / 删除后保存）。"""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(
            "".join(json.dumps(m.to_dict(), ensure_ascii=False) + "\n"
                    for m in self._memories),
            encoding="utf-8", newline="\n",
        )
        os.replace(tmp, self.path)
        self._sig = self._signature()

    @staticmethod
    def _find_duplicate(items: list[Memory], text: str) -> Memory | None:
        """同一用户内判重：归一化后完全相同，或相似度超过阈值。"""
        target = _norm(text)
        threshold = dedup_similarity()
        for m in items:
            if _norm(m.text) == target:
                return m
            if threshold > 0 and _similar(m.text, text) >= threshold:
                return m
        return None

    def add(self, text: str, tags: list[str] | None = None,
            session_id: str = "", user: str = "") -> Memory:
        text = (text or "").strip()
        if not text:
            raise ValueError("记忆内容不能为空")
        user = user or ""
        now = time.time()
        with self._lock:
            self._reload_if_changed()
            mine = [m for m in self._memories if m.user == user]
            dup = self._find_duplicate(mine, text)
            if dup is not None:                       # ★ 去重：只刷新，不新增
                dup.tags = list(dict.fromkeys([*dup.tags, *(tags or [])]))
                dup.updated_at = now
                if session_id:
                    dup.session_id = session_id
                self._write_all()
                self._indexes.pop(self._key(user), None)
                return dup

            m = Memory(id=uuid.uuid4().hex[:12], text=text, tags=list(tags or []),
                       session_id=session_id, user=user,
                       created_at=now, updated_at=now)
            self._memories.append(m)
            self._indexes.pop(self._key(user), None)

            cap = max_per_user()                      # ★ 容量上限：淘汰最旧
            mine = [x for x in self._memories if x.user == user]
            if cap > 0 and len(mine) > cap:
                mine.sort(key=lambda x: (x.updated_at or x.created_at))
                drop = {x.id for x in mine[:len(mine) - cap]}
                self._memories = [x for x in self._memories if x.id not in drop]
                self._write_all()
            else:
                self.path.parent.mkdir(parents=True, exist_ok=True)
                with self.path.open("a", encoding="utf-8", newline="\n") as f:
                    f.write(json.dumps(m.to_dict(), ensure_ascii=False) + "\n")
                self._sig = self._signature()
        return m

    def all(self, user: str | None = None) -> list[Memory]:
        with self._lock:
            self._reload_if_changed()
            if user is None:
                return list(self._memories)
            return [m for m in self._memories if m.user == user]

    def __len__(self) -> int:
        with self._lock:
            return len(self._memories)

    def stats(self) -> dict:
        """按用户统计条数（供数据清点 / 导出 / 删除预演）。"""
        with self._lock:
            self._reload_if_changed()
            out: dict[str, int] = {}
            for m in self._memories:
                out[m.user] = out.get(m.user, 0) + 1
            return out

    def purge_user(self, user: str) -> int:
        """删除某个用户的全部记忆，返回删除条数（原子重写）。"""
        with self._lock:
            keep = [m for m in self._memories if m.user != user]
            removed = len(self._memories) - len(keep)
            if removed:
                self._memories = keep
                self._write_all()
                self._indexes.pop(self._key(user), None)
            return removed

    def count_older_than(self, cutoff: float) -> int:
        with self._lock:
            return sum(1 for m in self._memories
                       if (m.updated_at or m.created_at) < cutoff)

    def purge_older_than(self, cutoff: float) -> int:
        """按「最后更新」清理老化记忆（第 27 步的 TTL 选项，默认不启用）。"""
        with self._lock:
            keep = [m for m in self._memories
                    if (m.updated_at or m.created_at) >= cutoff]
            removed = len(self._memories) - len(keep)
            if removed:
                self._memories = keep
                self._write_all()
                self._indexes.clear()
            return removed

    def reassign_user(self, old_user: str, new_user: str) -> int:
        """把 old_user 的记忆改归 new_user（存量迁移用）。"""
        with self._lock:
            n = 0
            for m in self._memories:
                if m.user == old_user:
                    m.user = new_user
                    n += 1
            if n:
                self._write_all()
                self._indexes.clear()
            return n

    # ---------- 检索 ----------
    @staticmethod
    def _key(user: str | None) -> str:
        return "*" if user is None else user

    def _ensure_index(self, user: str | None) -> Index:
        key = self._key(user)
        ix = self._indexes.get(key)
        if ix is not None:
            return ix
        items = (self._memories if user is None
                 else [m for m in self._memories if m.user == user])
        chunks = [
            # 借 Chunk 承载"可检索文本"，path 位置放记忆 id，便于命中后回查
            Chunk(path=m.id, start_line=1, end_line=1,
                  text=f"{m.text} {' '.join(m.tags)}")
            for m in items
        ]
        ix = build_search_index(chunks)
        self._indexes[key] = ix
        return ix

    def search(self, query: str, top_k: int = 3,
               user: str | None = None) -> list[tuple[Memory, float]]:
        """按用户检索。user=None 表示跨用户（仅单租户/CLI 用；服务路径必须传 user）。"""
        with self._lock:
            self._reload_if_changed()
            items = (self._memories if user is None
                     else [m for m in self._memories if m.user == user])
            if not items:
                return []
            ix = self._ensure_index(user)
            hits = ix.search(query, top_k)
            by_id = {m.id: m for m in items}
            return [(by_id[h.chunk.path], h.score)
                    for h in hits if h.chunk.path in by_id]


_STORES: dict[str, MemoryStore] = {}
_STORES_LOCK = threading.Lock()


def get_store(path: str | Path) -> MemoryStore:
    """按路径缓存 store（同进程同路径复用，避免反复读盘）。"""
    key = str(Path(path).resolve())
    with _STORES_LOCK:
        store = _STORES.get(key)
        if store is None:
            store = MemoryStore(key)
            _STORES[key] = store
        return store


def reset_cache() -> None:
    """清空 store 缓存（测试用）。"""
    with _STORES_LOCK:
        _STORES.clear()
