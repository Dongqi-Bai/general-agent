"""跨进程会话锁（第 28 步）。

问题：`SESSION_LOCKS` 是进程内的 `threading.Lock`。多实例部署时，A、B 两个实例
可能同时处理同一个 session 的两个请求，各自「读 → 改 → 写」会话文件，
后写的覆盖先写的 —— 表现为「聊着聊着丢了一段」。

做法：进程内先用 `threading.Lock` 串行（快、无系统调用），再抢一把**文件锁**
（`O_CREAT|O_EXCL` 原子创建）。拿不到就轮询等待，超时抛错。
持锁进程崩溃会留下锁文件，用 mtime 判定「陈旧」后回收（默认 600 秒）。

边界：文件锁依赖共享文件系统，只适合单机多进程 / 共享盘；跨主机要用 Redis 等。
设 `SESSION_LOCK=off` 可退回纯进程内锁。
"""
from __future__ import annotations

import hashlib
import os
import threading
import time
from contextlib import contextmanager
from pathlib import Path

_DEFAULT_DIR = Path(__file__).resolve().parent / ".locks"


def _disabled() -> bool:
    return (os.getenv("SESSION_LOCK") or "").strip().lower() in ("0", "off", "false", "no")


def _lock_dir() -> Path:
    raw = os.getenv("SESSION_LOCK_DIR")
    p = Path(raw) if raw else _DEFAULT_DIR
    return p if p.is_absolute() else (Path(__file__).resolve().parent / p)


def _timeout() -> float:
    try:
        return float(os.getenv("SESSION_LOCK_TIMEOUT", "30"))
    except ValueError:
        return 30.0


def _stale() -> float:
    try:
        return float(os.getenv("SESSION_LOCK_STALE", "600"))
    except ValueError:
        return 600.0


def _lock_path(key: str) -> Path:
    digest = hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]
    return _lock_dir() / f"{digest}.lock"


@contextmanager
def cross_process_lock(key: str, timeout: float | None = None):
    """对 key 抢一把跨进程排他锁；拿不到（超时）抛 TimeoutError。"""
    if _disabled():
        yield
        return
    path = _lock_path(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + (timeout if timeout is not None else _timeout())
    while True:
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, f"{os.getpid()} {time.time()}".encode("ascii"))
            os.close(fd)
            break
        except FileExistsError:
            try:                                   # 陈旧锁（持锁者崩了）→ 回收
                if _stale() > 0 and (time.time() - path.stat().st_mtime) > _stale():
                    path.unlink(missing_ok=True)
                    continue
            except OSError:
                pass
            if time.monotonic() > deadline:
                raise TimeoutError(f"等待会话锁超时：{key}")
            time.sleep(0.05)
    try:
        yield
    finally:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


class SessionLocks:
    """先按 key 拿进程内锁，再拿跨进程文件锁。"""

    def __init__(self) -> None:
        self._locks: dict[str, threading.Lock] = {}
        self._guard = threading.Lock()

    def _local(self, key: str) -> threading.Lock:
        with self._guard:
            return self._locks.setdefault(key, threading.Lock())

    @contextmanager
    def hold(self, key: str):
        with self._local(key):
            with cross_process_lock(key):
                yield
