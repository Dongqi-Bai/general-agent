"""本地 embedding：sentence-transformers + 中文模型（第 20f 步）。

把检索从"词/字重叠"(BM25) 升级到"语义"：换个说法问同一件事，也能召回。
例：查询"文件写到哪儿去了" 命中 write_file —— BM25 因为没有共同词，一条都搜不到。

设计约束：
- 懒加载：第一次真正用到时才加载模型，进程内只加载一次；
- 绝不抛异常：未装依赖 / 模型没下载 / 加载失败 → 返回 None，由上层退回 BM25；
- 归一化向量：于是"余弦相似度"就等于"点积"，检索侧只需一次矩阵乘。

注意：本模块刻意**不 import config**，这样 retrieval 包仍然可以脱离 Agent
（不需要 API key）独立使用；配置一律从环境变量读。
"""
from __future__ import annotations

import os
import threading

# BGE 中文模型的检索建议做法：passage 原样编码，query 加一句"指令前缀"。
_QUERY_INSTRUCTION = "为这个句子生成表示以用于检索相关文章："

DEFAULT_MODEL = "BAAI/bge-small-zh-v1.5"


def _enabled() -> bool:
    raw = (os.getenv("EMBEDDING_ENABLED") or "").strip().lower()
    if not raw:
        return True                       # 默认开；模型不可用时会自动退回 BM25
    return raw in ("1", "true", "yes", "on")


def model_name() -> str:
    return os.getenv("EMBEDDING_MODEL", DEFAULT_MODEL)


def batch_size() -> int:
    try:
        return int(os.getenv("EMBEDDING_BATCH_SIZE", "32"))
    except ValueError:
        return 32


def allow_download() -> bool:
    """是否允许联网下载模型。默认不允许 —— 避免每次冷启动卡在一次注定失败的
    HuggingFace 请求上（实测约 10 秒才回退 BM25）。设 EMBEDDING_ALLOW_DOWNLOAD=1 打开。"""
    raw = (os.getenv("EMBEDDING_ALLOW_DOWNLOAD") or "").strip().lower()
    return raw in ("1", "true", "yes", "on")


_model = None
_failed = False
_lock = threading.RLock()


def get_model():
    """懒加载 SentenceTransformer。不可用返回 None（只尝试加载一次）。"""
    global _model, _failed
    if _model is not None or _failed:
        return _model
    with _lock:
        if _model is not None or _failed:
            return _model
        try:
            if not allow_download():            # 默认离线：本地有就用，没有就快速回退
                os.environ.setdefault("HF_HUB_OFFLINE", "1")
                os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")
            from sentence_transformers import SentenceTransformer
            _model = SentenceTransformer(model_name())
        except Exception as e:            # 依赖缺失 / 模型没下载 / 显存不足……
            _failed = True
            print(f"[warn] 本地 embedding 不可用，退回 BM25：{e}")
    return _model


def is_available() -> bool:
    return _enabled() and get_model() is not None


def _encode(texts: list[str], is_query: bool):
    if not _enabled() or not texts:
        return None
    model = get_model()
    if model is None:
        return None
    kwargs = dict(normalize_embeddings=True,
                  batch_size=batch_size(),
                  show_progress_bar=False)
    try:
        if is_query:
            try:                          # 模型自带 query 提示词就直接用
                return [v.tolist() for v in
                        model.encode(texts, prompt_name="query", **kwargs)]
            except Exception:
                texts = [_QUERY_INSTRUCTION + t for t in texts]
        return [v.tolist() for v in model.encode(texts, **kwargs)]
    except Exception:
        return None


def embed_docs(texts: list[str]):
    """把待检索的文档块编码成向量列表；不可用返回 None。"""
    return _encode(texts, is_query=False)


def embed_query(text: str):
    """把查询编码成单个向量；不可用返回 None。"""
    vecs = _encode([text], is_query=True)
    return vecs[0] if vecs else None
