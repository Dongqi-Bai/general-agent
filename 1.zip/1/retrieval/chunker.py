"""切块：把项目里的文本文件切成带「来源 + 行号」的小块。

为什么要带行号：召回之后要能说清"这是从哪来的"，否则无法追溯、也无法引用。
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

DEFAULT_EXTS = {".py", ".md", ".yaml", ".yml", ".txt"}

# 数据/产物目录不索引（免得把会话、trace、评测报告也搜出来）
EXCLUDE_DIRS = {
    ".git", "__pycache__", ".venv", "venv", ".idea", ".vscode",
    ".agents", ".codex", "node_modules",
    "traces", "sessions", "results",
}
# 绝不索引密钥文件
EXCLUDE_FILE_PREFIXES = (".env",)

# 评测用例文件不索引：它们是"测试数据"而不是"知识"，而且里面写着查询串本身，
# 会把查询"喂回"给自己，制造假命中。
# （第 20e 步实测踩到的坑：negative 用例因为"查询串就在用例文件里"而命中了 1 条。）
EXCLUDE_FILE_GLOBS = ("*cases*.yaml", "*cases*.yml")

MAX_FILE_BYTES = 512 * 1024          # 单个文件超过 512KB 跳过（大文件多半是数据）


@dataclass
class Chunk:
    path: str          # 相对 root 的路径，统一用 / 分隔
    start_line: int    # 1 起
    end_line: int
    text: str

    @property
    def cite(self) -> str:
        """人类可读的出处，如 tools/sandbox.py:20-28"""
        return f"{self.path}:{self.start_line}-{self.end_line}"


def is_indexable(p: Path, exts=DEFAULT_EXTS) -> bool:
    if any(part in EXCLUDE_DIRS for part in p.parts):
        return False
    if p.name.startswith(EXCLUDE_FILE_PREFIXES):
        return False
    if any(p.match(g) for g in EXCLUDE_FILE_GLOBS):
        return False
    return p.suffix.lower() in exts


def iter_files(root: Path, exts=DEFAULT_EXTS):
    """按路径排序遍历可索引文件（排序是为了让结果稳定、可复现）。"""
    for p in sorted(root.rglob("*")):
        if not p.is_file() or not is_indexable(p, exts):
            continue
        try:
            if p.stat().st_size > MAX_FILE_BYTES:
                continue
        except OSError:
            continue
        yield p


def chunk_text(text: str, path: str, target_chars: int = 800,
               overlap_lines: int = 3) -> list[Chunk]:
    """按行累积到 target_chars 为一块，块间保留 overlap_lines 行重叠。

    重叠的作用：避免"答案正好被切在块的边界上"，两边都只拿到半句。
    """
    lines = text.splitlines()
    chunks: list[Chunk] = []
    buf: list[str] = []
    start = 1
    size = 0

    for i, line in enumerate(lines, start=1):
        if not buf:
            start = i
        buf.append(line)
        size += len(line) + 1
        if size >= target_chars:
            chunks.append(Chunk(path, start, i, "\n".join(buf)))
            keep = buf[-overlap_lines:] if overlap_lines > 0 else []
            buf = list(keep)
            size = sum(len(l) + 1 for l in buf)
            start = i - len(keep) + 1

    if buf and any(l.strip() for l in buf):
        chunks.append(Chunk(path, start, start + len(buf) - 1, "\n".join(buf)))
    return chunks


def chunk_file(path: Path, root: Path, target_chars: int = 800,
               overlap_lines: int = 3) -> list[Chunk]:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    rel = path.relative_to(root).as_posix()
    return chunk_text(text, rel, target_chars, overlap_lines)


def build_chunks(root: Path, target_chars: int = 800,
                 overlap_lines: int = 3) -> tuple[int, list[Chunk]]:
    """返回 (文件数, 所有块)。"""
    total_files = 0
    all_chunks: list[Chunk] = []
    for f in iter_files(root):
        cs = chunk_file(f, root, target_chars, overlap_lines)
        if cs:
            total_files += 1
            all_chunks.extend(cs)
    return total_files, all_chunks
