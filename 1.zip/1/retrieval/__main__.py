"""第 20a 步 · 离线检索原语：建索引 + 提问（零依赖）。

用法（在 1/ 目录下）：
    python -m retrieval                          # 建索引后进入交互提问
    python -m retrieval --query "沙箱根目录在哪定义"
    python -m retrieval --query "怎么加一个新工具" --top 3 --show-chunk

这一步**还没接进 Agent**：先确认"它到底能不能找对地方"。
第 20b 步会把 Index.search 包成一个 search 工具接进技能系统。
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

# 允许 `python retrieval/__main__.py` 与 `python -m retrieval` 两种跑法
if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from retrieval.chunker import build_chunks       # noqa: E402
from retrieval.vector import build_search_index  # noqa: E402


def _render(hit, show_chunk: bool) -> str:
    c = hit.chunk
    head = f"{hit.score:7.3f}  {c.cite}"
    if show_chunk:
        body = "\n".join("        " + ln for ln in c.text.splitlines())
        return head + "\n" + body
    snippet = " ".join(c.text.split())[:140]
    return head + "\n        " + (snippet or "（空白块）")


def _answer(ix, query: str, top_k: int, show_chunk: bool) -> None:
    hits = ix.search(query, top_k)
    print(f"\n提问：{query}")
    if not hits:
        print("  （没有命中：换个说法，或把 --chars 调小再试）\n")
        return
    for i, h in enumerate(hits, 1):
        print(f"  [{i}] {_render(h, show_chunk)}")
    print()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="要索引的根目录（默认当前目录）")
    ap.add_argument("--query", default=None, help="直接问一句；不给则进入交互模式")
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--chars", type=int, default=800, help="每块目标字符数")
    ap.add_argument("--overlap", type=int, default=3, help="块间重叠行数")
    ap.add_argument("--show-chunk", action="store_true", help="打印命中块的完整内容")
    ap.add_argument("--lexical", action="store_true", help="只用 BM25（词/字重叠）")
    ap.add_argument("--semantic", action="store_true",
                    help="启用语义检索（BM25 + 本地向量，换个说法也能搜到）")
    args = ap.parse_args()

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    root = Path(args.root).resolve()
    semantic = None
    if args.lexical:
        semantic = False
    elif args.semantic:
        semantic = True

    t0 = time.perf_counter()
    files, chunks = build_chunks(root, args.chars, args.overlap)
    ix = build_search_index(chunks, semantic)
    dt = time.perf_counter() - t0

    print(f"根目录：{root}")
    print(f"检索模式：{getattr(ix, 'mode', 'bm25')}")
    print(f"已索引 {files} 个文件 / {len(chunks)} 个块 / 词表 {ix.vocab} 项"
          f"  （{dt * 1000:.0f} ms）")

    if args.query:
        _answer(ix, args.query, args.top, args.show_chunk)
        return 0

    print("\n输入问题回车即可检索；输入 :q 退出。")
    while True:
        try:
            q = input("? ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if q in (":q", ":quit", "exit"):
            break
        if q:
            _answer(ix, q, args.top, args.show_chunk)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
