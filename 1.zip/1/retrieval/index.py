"""检索核心：中文二元组 + 英文标识符 → 倒排索引 → BM25 打分。

这是第 20a 步的重点。刻意只用标准库，让你能看清"检索到底在算什么"。

注意它**不是语义检索**：它靠"词/字重叠"来打分。所以：
  能搜到   "沙箱根目录"     ↔  代码里的 SANDBOX_ROOT（因为拆成了 sandbox / root）
  搜不到   "文件写到哪儿去了" ↔  write_file（说法完全不同，没有共同词）
第 20b/20c 步把这一层换成 embedding，上层接口（search）完全不用动。

BM25 是搜索引擎经典的打分公式，直觉是：
  - 一个词在本块里出现越多，越相关（但有上限，出现 100 次不等于相关 100 倍）；
  - 一个词在整个语料里越罕见，区分度越高（"沙箱"比"的"值钱）；
  - 块越长越吃亏（否则长块靠"词多"占便宜）。
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict
from dataclasses import dataclass

from retrieval.chunker import Chunk

_HAN = re.compile(r"[\u4e00-\u9fff]+")
_WORD = re.compile(r"[A-Za-z_][A-Za-z0-9_]*|\d+")

K1 = 1.5      # 词频饱和系数
B = 0.75      # 长度归一化强度


def tokenize(text: str) -> list[str]:
    """中文按「字二元组」，英文/标识符按词，并额外把下划线拆开。

    为什么要拆下划线：SANDBOX_ROOT 若整体当成一个词，
    那么查询里的 "sandbox root"（两个词）就永远匹配不上。
    """
    toks: list[str] = []
    for m in _WORD.finditer(text):
        w = m.group(0).lower()
        toks.append(w)
        if "_" in w:
            toks.extend(p for p in w.split("_") if p and p != w)
    for run in _HAN.findall(text):
        if len(run) == 1:
            toks.append(run)
        else:
            toks.extend(run[i:i + 2] for i in range(len(run) - 1))
    return toks


@dataclass
class Hit:
    chunk: Chunk
    score: float


class Index:
    """倒排索引：词 → {块号: 出现次数}。"""

    def __init__(self) -> None:
        self.chunks: list[Chunk] = []
        self.postings: dict[str, dict[int, int]] = defaultdict(dict)
        self.lengths: list[int] = []
        self.avgdl: float = 0.0

    def add(self, chunk: Chunk) -> None:
        toks = tokenize(chunk.text)
        idx = len(self.chunks)
        self.chunks.append(chunk)
        self.lengths.append(len(toks) or 1)
        for token, tf in Counter(toks).items():
            self.postings[token][idx] = tf

    def finalize(self) -> None:
        self.avgdl = sum(self.lengths) / len(self.lengths) if self.lengths else 0.0

    @property
    def vocab(self) -> int:
        return len(self.postings)

    def search(self, query: str, top_k: int = 5) -> list[Hit]:
        qtoks = set(tokenize(query))
        if not qtoks or not self.chunks:
            return []
        n = len(self.chunks)
        scores: dict[int, float] = defaultdict(float)

        for token in qtoks:
            post = self.postings.get(token)
            if not post:
                continue
            df = len(post)
            idf = math.log(1 + (n - df + 0.5) / (df + 0.5))
            for idx, tf in post.items():
                dl = self.lengths[idx]
                denom = tf + K1 * (1 - B + B * dl / (self.avgdl or 1))
                scores[idx] += idf * tf * (K1 + 1) / denom

        ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)[:top_k]
        return [Hit(self.chunks[i], s) for i, s in ranked]


def build_index(chunks) -> Index:
    ix = Index()
    for c in chunks:
        ix.add(c)
    ix.finalize()
    return ix
