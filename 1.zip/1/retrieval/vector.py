"""向量索引 + 与 BM25 的混合检索（第 20f 步）。

接口刻意做得和 retrieval.index.Index 一致（`search(query, top_k) -> list[Hit]`、
`.vocab`），这样 knowledge 工具 / memory store 只换一个构造函数，底下是词法还是
语义都不用关心。

为什么要"混合"而不是直接纯向量：
- BM25 擅长精确命中：标识符、常量名、报错原文、路径；纯向量反而可能把这些"糊掉"；
- 向量擅长语义相近：换个说法问同一件事；
- 两者分数各自按本次查询归一化到 [0,1] 后加权相加，alpha 控制向量权重。

降级策略：embedding 不可用（没装依赖 / 模型没下载）时，build_search_index 直接
返回纯 BM25 的 Index，行为与升级前完全一致。
"""
from __future__ import annotations

import os

try:
    import numpy as np
except Exception:                         # numpy 缺失时向量检索整体不可用，退回 BM25
    np = None

from retrieval import embedding as emb
from retrieval.chunker import Chunk
from retrieval.index import Hit, Index, build_index


def _alpha() -> float:
    try:
        return max(0.0, min(1.0, float(os.getenv("HYBRID_ALPHA", "0.5"))))
    except ValueError:
        return 0.5


def _pool() -> int:
    try:
        return max(1, int(os.getenv("HYBRID_POOL", "20")))
    except ValueError:
        return 20


def _min_score() -> float:
    """向量命中的相似度下限（低于它直接丢弃）。

    BGE 的余弦被压缩在很窄的区间：本项目实测"无关内容"也能到 0.42~0.53，
    "相关内容"约 0.55~0.77。不加下限的话，任何查询都会硬凑出 top_k 条，
    "没有相关结果就返回空"的语义会被破坏。默认 0.5，按语料实测调。
    """
    try:
        return float(os.getenv("EMBEDDING_MIN_SCORE", "0.5"))
    except ValueError:
        return 0.5


def _key(chunk: Chunk) -> tuple:
    return (chunk.path, chunk.start_line, chunk.end_line)


class VectorIndex:
    """把每个块的 embedding 压成一个矩阵；检索 = 一次矩阵乘。"""

    def __init__(self) -> None:
        self.chunks: list[Chunk] = []
        self._texts: list[str] = []
        self._mat = None                  # [n, d]，已归一化

    def add(self, chunk: Chunk) -> None:
        self.chunks.append(chunk)
        self._texts.append(chunk.text)

    def finalize(self) -> None:
        """批量编码（比逐个编码快得多）。失败则标记为不可用。"""
        if np is None or not self._texts:
            self._mat = None
            return
        vecs = emb.embed_docs(self._texts)
        if vecs is None:
            self._mat = None
            return
        m = np.asarray(vecs, dtype=np.float32)
        norms = np.linalg.norm(m, axis=1, keepdims=True)
        self._mat = m / np.clip(norms, 1e-8, None)

    @property
    def available(self) -> bool:
        return self._mat is not None and len(self.chunks) > 0

    def search(self, query: str, top_k: int = 5) -> list[Hit]:
        if not self.available:
            return []
        q = emb.embed_query(query)
        if q is None:
            return []
        qv = np.asarray(q, dtype=np.float32)
        qv = qv / max(float(np.linalg.norm(qv)), 1e-8)
        sims = self._mat @ qv

        hits: list[Hit] = []
        for i in np.argsort(-sims):
            score = float(sims[i])
            if score < _min_score():
                break
            hits.append(Hit(self.chunks[i], score))
            if len(hits) >= top_k:
                break
        return hits


def _normalize(hits: list[Hit]) -> dict[tuple, float]:
    """把一组命中按本次查询的最高分归一化到 [0,1]。"""
    if not hits:
        return {}
    top = max(h.score for h in hits)
    if top <= 0:
        return {}
    return {_key(h.chunk): h.score / top for h in hits}


class HybridIndex:
    """BM25 + 向量 的加权融合；向量侧不可用时自动退化为纯 BM25。"""

    def __init__(self, bm25: Index, vec: VectorIndex,
                 alpha: float = 0.5, pool: int = 20) -> None:
        self.bm25 = bm25
        self.vec = vec
        self.alpha = max(0.0, min(1.0, alpha))
        self.pool = pool

    @property
    def vocab(self) -> int:
        return self.bm25.vocab

    @property
    def mode(self) -> str:
        return f"hybrid(BM25+vector, alpha={self.alpha})"

    def search(self, query: str, top_k: int = 5) -> list[Hit]:
        lexical = _normalize(self.bm25.search(query, self.pool))
        semantic = (_normalize(self.vec.search(query, self.pool))
                    if self.vec.available else {})
        if not lexical and not semantic:
            return []

        # 命中的块可能来自任一侧，建一张 key -> Chunk 的表统一取回
        by_key: dict[tuple, Chunk] = {}
        for c in self.bm25.chunks:
            by_key[_key(c)] = c
        for c in self.vec.chunks:
            by_key[_key(c)] = c

        scored = [(self.alpha * semantic.get(k, 0.0)
                   + (1.0 - self.alpha) * lexical.get(k, 0.0), k)
                  for k in set(lexical) | set(semantic)]
        scored.sort(key=lambda kv: kv[0], reverse=True)
        return [Hit(by_key[k], s) for s, k in scored[:top_k] if k in by_key]


def build_search_index(chunks, semantic: bool | None = None):
    """按配置构建检索器。

    semantic=True 且本地 embedding 可用 → HybridIndex；否则纯 BM25 的 Index。
    返回对象都支持 `.search(query, top_k)` 与 `.vocab`，上层无需区分。
    """
    bm25 = build_index(chunks)
    if semantic is None:
        semantic = emb.is_available()
    if not semantic:
        return bm25

    vec = VectorIndex()
    for c in chunks:
        vec.add(c)
    vec.finalize()
    if not vec.available:
        return bm25                      # 模型不可用：静默退化为词法检索
    return HybridIndex(bm25, vec, _alpha(), _pool())
