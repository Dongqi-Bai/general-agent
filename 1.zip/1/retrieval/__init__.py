"""第 20a 步 · 离线检索原语（零依赖）。

RAG 流水线里"切块 → 建索引 → 召回"三步的最小实现，先不接 Agent。
跑通之后，第 20b 步会把它包成一个 search 工具接进技能系统。

    retrieval/chunker.py   把文件切成带「来源 + 行号」的小块
    retrieval/index.py     中文二元组 + 英文标识符 → 倒排索引 → BM25 打分
    retrieval/embedding.py 本地 embedding（sentence-transformers + BGE，懒加载）
    retrieval/vector.py    向量索引 + 与 BM25 的混合检索（第 20f 步）
    retrieval/__main__.py  命令行：建索引 + 提问
"""
