
from dataclasses import dataclass, field
import json
import os
from pathlib import Path
import time
import uuid
from config import Config

cfg = Config()

@dataclass
class Conversation:
    
    instructions: str
    summary: str = ""
    items: list[dict] = field(default_factory=list)
    session_id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    skills: list[str] | None = None       # None=全部技能；[]=不装；列表=指定技能
    user: str = ""                        # 第 27 步：归属用户（"" = 单租户）
        
    def add_user(self, message: str):
        self.items.append({"role":"user","content":message})
    
    def add_response_output(self, response_output):
        self.items.extend(self._clean(out.model_dump()) for out in response_output)
        
    def add_tool_output(self, call_id: str, output):
        self.items.append(
            {
                "type":"function_call_output",
                "call_id":call_id,
                "output":output
            }
        )
        
    @staticmethod
    def _clean(d: dict):
        if d.get("type") == "function_call":
            return {
                "type":"function_call",
                "call_id":d["call_id"],
                "name":d["name"],
                "arguments":d.get("arguments", "{}")
            }
        if d.get("type") == "message":
            return {
                "role":"assistant",
                "content":d.get("content", [])
            }
        return d
        
    
    def build_input(self) -> list[dict]:
        """摘要永远排在最前，items 保持干净（两者生命周期不同）。"""
        if not self.summary:
            return list(self.items)
        return [{"role": "developer", "content": f"[历史摘要]\n{self.summary}"}, *self.items] 
    
    def needs_compact(self) -> bool:
        return len(self.items) >= cfg.summarize_threshold

    def compact(self, summarize_fn) -> bool:
        """
        按“轮”整体搬运：切点只落在 user 消息处。
        因为一次 function_call 与它的 output 必定同属一个 user 轮次，
        所以这样切永远不会拆散配对。
        """
        if len(self.items) < cfg.summarize_threshold:
            return False

        starts = [i for i, it in enumerate(self.items) if it.get("role") == "user"]
        if len(starts) <= cfg.keep_recent_turns:
            return False                                   # 轮数不够，留无可留

        cut = starts[-cfg.keep_recent_turns]               # 保留最近 N 轮原文
        old, self.items = self.items[:cut], self.items[cut:]
        self.summary = summarize_fn(self.summary, old)     # 一次模型调用
        return True
            
            
        # ---------------- 原子写盘 / 加载 ----------------
    def save(self, path: Path | None = None) -> Path:
        path = Path(path) if path else cfg.session_dir / f"{self.session_id}.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.to_dict(), ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, path)                              # 原子替换，避免半截文件
        return path
    
    @classmethod
    def load(cls, session_id: str) -> "Conversation | None":
        path = cfg.session_dir / f"{session_id}.json"
        if not path.exists():
            return None
        conv = cls.from_dict(json.loads(path.read_text(encoding="utf-8")))
        conv.session_id = session_id          # I1：保证 load(id).session_id == id
        return conv
    
    @classmethod
    def from_dict(cls, d: dict) -> "Conversation":
        conv = cls(
            instructions=d.get("instructions", cfg.instructions),
            summary=d.get("summary", ""),
            items=cls._sanitize(d.get("items", [])),
            skills=d.get("skills", None),
            user=d.get("user", ""),
        )
        conv.session_id = d.get("session_id", conv.session_id)
        return conv

    @staticmethod
    def _sanitize(items: list[dict]) -> list[dict]:
        """丢掉孤儿 function_call_output 和没被回答的 function_call，保证历史合法。"""
        out, open_calls = [], set()
        for it in items:
            if it.get("type") == "function_call":
                open_calls.add(it.get("call_id"))
                out.append(it)
            elif it.get("type") == "function_call_output":
                if it.get("call_id") in open_calls:
                    open_calls.discard(it.get("call_id"))
                    out.append(it)
            else:
                out.append(it)
        if open_calls:
            out = [it for it in out
                   if not (it.get("type") == "function_call"
                           and it.get("call_id") in open_calls)]
        while out and out[0].get("role") != "user":
            out.pop(0)
        return out
    
    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "instructions": self.instructions,
            "summary": self.summary,
            "items": self.items,
            "skills": self.skills,
            "user": self.user,
            "updated_at": time.time(),
        }
