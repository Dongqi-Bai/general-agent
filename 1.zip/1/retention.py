"""保留策略：按天数清理过期数据（第 27 步）。

和"按用户删除"不同，这里是**按时间**的例行清理，防止磁盘无限膨胀：

    RETENTION_DAYS_SESSION=30      # 会话（按文件 mtime）
    RETENTION_DAYS_TRACE=14        # 轨迹（按 meta.created_at，存了全文，所以最短）
    RETENTION_DAYS_RUN=90          # run / 审批
    RETENTION_DAYS_USAGE=365       # 成本账本（要留久一点核对账单）
    RETENTION_DAYS_MEMORY=365      # 记忆（默认一年；它是资产，主要靠容量+去重管）
    RETENTION_EXEMPT_USERS=admin   # 这些用户的数据不做例行清理

值为 0 表示该类不清理。`sweep(dry_run=True)` 只统计不删。
顺带清理过期的导出文件（EXPORT_TTL_S）。
"""
from __future__ import annotations

import os
import time

import audit
import costs
import lifecycle
import memory.store as memory_store
import reliability
import run_store
from config import Config
from trace_utils import Trace, meta_of

_BIG = 1_000_000


def _days(name: str, default: float) -> float:
    try:
        return max(0.0, float(os.getenv(name) or default))
    except ValueError:
        return default


def exempt_users() -> set[str]:
    raw = os.getenv("RETENTION_EXEMPT_USERS") or ""
    return {s.strip() for s in raw.split(",") if s.strip()}


def _known_users(store) -> set[str]:
    users = {r.user for r in store.list(limit=_BIG) if r.user}
    users |= {a.user for a in store.list_approvals(limit=_BIG) if a.user}
    users |= set(costs.users())
    return users


def sweep(dry_run: bool = False, cfg: Config | None = None) -> dict:
    """执行一次保留策略清理；返回每个存储被清掉（或将被清掉）的条数。"""
    cfg = cfg or Config()
    now = time.time()
    report: dict[str, int] = {}
    exempt = exempt_users()
    # 先快照用户清单：run 一旦被清掉，_known_users 就查不到这些人了
    store = run_store.get_store()
    known = _known_users(store)
    known_usage = set(costs.users())

    # ---- 会话 ----
    days = _days("RETENTION_DAYS_SESSION", 30)
    n = 0
    if days > 0:
        cutoff = now - days * 86400
        for p in cfg.session_dir.glob("*.json"):
            try:
                if lifecycle.session_owner(p) in exempt:
                    continue
                if p.stat().st_mtime < cutoff:
                    if not dry_run:
                        p.unlink()
                    n += 1
            except OSError:
                pass
    report["session"] = n

    # ---- 轨迹 ----
    days = _days("RETENTION_DAYS_TRACE", 14)
    n = 0
    if days > 0:
        cutoff = now - days * 86400
        for p in Trace.TRACE_DIR.glob("*.jsonl"):
            try:
                meta = meta_of(p)
                if (meta.get("user") or "") in exempt:
                    continue
                ts = float(meta.get("created_at") or 0.0) or p.stat().st_mtime
                if ts < cutoff:
                    if not dry_run:
                        p.unlink()
                    n += 1
            except OSError:
                pass
    report["trace"] = n

    # ---- run / 审批（有豁免名单时按用户逐个清）----
    days = _days("RETENTION_DAYS_RUN", 90)
    report["run"] = report["approval"] = 0
    if days > 0:
        cutoff = now - days * 86400
        if exempt:
            for u in sorted(known - exempt):
                if dry_run:
                    report["run"] += sum(
                        1 for r in store.list(limit=_BIG, user=u)
                        if r.created_at < cutoff)
                    report["approval"] += sum(
                        1 for a in store.list_approvals(user=u, limit=_BIG)
                        if a.created_at < cutoff)
                else:
                    got = store.purge_user_older_than(u, cutoff)
                    report["run"] += int(got.get("runs", 0))
                    report["approval"] += int(got.get("approvals", 0))
        elif dry_run:
            report["run"] = sum(1 for r in store.list(limit=_BIG)
                                if r.created_at < cutoff)
            report["approval"] = sum(1 for a in store.list_approvals(limit=_BIG)
                                     if a.created_at < cutoff)
        else:
            got = store.purge_older_than(cutoff)
            report["run"] = int(got.get("runs", 0))
            report["approval"] = int(got.get("approvals", 0))

    # ---- 成本账本 ----
    days = _days("RETENTION_DAYS_USAGE", 365)
    report["usage"] = 0
    if days > 0:
        cutoff = now - days * 86400
        if exempt:
            for u in sorted(known_usage - exempt):
                report["usage"] += (costs.count_older_than(cutoff) if dry_run
                                    else costs.purge_user_older_than(u, cutoff))
        else:
            report["usage"] = (costs.count_older_than(cutoff) if dry_run
                               else costs.purge_older_than(cutoff))

    # ---- 记忆 ----
    days = _days("RETENTION_DAYS_MEMORY", 365)
    report["memory"] = 0
    if days > 0:
        cutoff = now - days * 86400
        store = memory_store.get_store(cfg.memory_path)
        report["memory"] = (store.count_older_than(cutoff) if dry_run
                            else store.purge_older_than(cutoff))

    # ---- 过期导出文件 ----
    report["export"] = 0 if dry_run else lifecycle.cleanup_exports(cfg)

    # ---- 可靠性地基（幂等键 / 计划 / 检查点 / 副作用记录）----
    days = _days("RETENTION_DAYS_RUN", 90)
    report["reliability"] = 0
    if days > 0:
        cutoff = now - days * 86400
        rstore = reliability.get_store()
        # 用开头的用户快照逐个清（与 run 的清理口径保持一致）
        for u in sorted(known - exempt):
            got = rstore.purge_user_older_than(u, cutoff, dry_run=dry_run)
            report["reliability"] += sum(int(v) for v in got.values())

    audit.log("retention_sweep", dry_run=dry_run, counts=report,
              exempt=sorted(exempt) or None)
    return report
