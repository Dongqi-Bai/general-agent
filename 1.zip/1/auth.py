"""第 23 步 · 鉴权与多租户：谁是用户、数据归谁。

问题：service 之前没有「用户」这个概念 —— 任何能连上端口的人都能读所有会话、
发消息花你的钱、甚至取消别人的任务（`/runs` 会把所有 run 连同 target 列出来）。

做法：
1) 鉴权：用 API Key 识别用户。请求带 `Authorization: Bearer <key>` 或 `X-API-Key: <key>`。
2) 多租户：会话在磁盘上按用户隔离（`<user>__<sid>.json`）；run 记录带 user 字段，
   列表 / 查询 / 取消 / 订阅事件都只允许本人。
3) 堵住路径穿越：`session_id` 会参与拼文件名，统一限制为 `[A-Za-z0-9_-]{1,64}`。

凭据管理（本步的进阶）：
- **不落明文**：库里只存 `sha256(pepper + key)`；校验用 `hmac.compare_digest`；
  签发时明文 key 只返回一次。API key 是高熵随机串，不需要 bcrypt 那样的慢哈希。
- **可过期、可撤销**：`expires_at` + `revoked`，改完在缓存 TTL 内生效，无需重启。
- **两种来源**：环境变量 `AGENT_USERS="alice:key1,bob:key2"`（静态，权限最全），
  以及 CLI 签发的动态 token（`python auth.py issue/list/revoke`）。
- 两种都没配 → 关闭鉴权（本地开发），所有请求归属用户 local。
"""
from __future__ import annotations

import dataclasses
import hashlib
import hmac
import os
import re
import secrets
import sqlite3
import threading
import time
from pathlib import Path

DEFAULT_USER = "local"                       # 鉴权关闭时的匿名用户
ENV_USERS = "AGENT_USERS"
FULL_SCOPES = ("chat", "plan", "admin")      # 静态 env 用户：权限最全
DEFAULT_SCOPES = ("chat", "plan")            # CLI 签发的 token：默认不含 admin

_NAME_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
_DEFAULT_DB = Path(__file__).resolve().parent / "auth_tokens.db"


class AuthError(ValueError):
    """名字 / 配置非法（会用于拼路径或做隔离键）。"""


@dataclasses.dataclass(frozen=True)
class Principal:
    """一次请求的身份：是谁 + 能干什么。"""

    user: str
    scopes: frozenset[str] = frozenset(DEFAULT_SCOPES)
    token_id: str = ""                       # 便于审计；静态 env 用户为空

    def has(self, scope: str) -> bool:
        return "admin" in self.scopes or scope in self.scopes


# ===================== 名字校验 =====================

def validate_name(value: str, what: str) -> str:
    """校验会参与路径 / 隔离键的名字（user、session_id），同时堵住路径穿越。"""
    if not isinstance(value, str) or not _NAME_RE.match(value):
        raise AuthError(
            f"{what} 只能由字母、数字、下划线、连字符组成（1~64 字），收到：{value!r}"
        )
    return value


# ===================== 凭据库（只存哈希） =====================

def _tokens_path() -> Path:
    raw = os.getenv("AUTH_TOKENS_PATH")
    p = Path(raw) if raw else _DEFAULT_DB
    return p if p.is_absolute() else (Path(__file__).resolve().parent / p)


def _hash_key(key: str) -> str:
    """key -> 存储用哈希。加 pepper 后即使库泄露也难反查（key 本身已是高熵随机串）。"""
    pepper = os.getenv("AUTH_PEPPER", "")
    return hashlib.sha256((pepper + key).encode("utf-8")).hexdigest()


def new_api_key() -> str:
    return "sk-" + secrets.token_urlsafe(32)


class TokenStore:
    """SQLite 凭据库：只存哈希，支持过期与撤销。"""

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = str(path or _tokens_path())
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._exec(
            """CREATE TABLE IF NOT EXISTS tokens (
                token_id     TEXT PRIMARY KEY,
                key_hash     TEXT UNIQUE,
                user         TEXT,
                scopes       TEXT,
                label        TEXT,
                expires_at   REAL,
                revoked      INTEGER DEFAULT 0,
                created_at   REAL,
                last_used_at REAL
            )"""
        )

    def _exec(self, sql: str, params: tuple = ()) -> list[tuple]:
        with self._lock:                     # 每次独立开关连接，天然线程安全
            conn = sqlite3.connect(self.path, timeout=5)
            try:
                cur = conn.execute(sql, params)
                rows = cur.fetchall()
                conn.commit()
                return rows
            finally:
                conn.close()

    def issue(self, user: str, scopes, days: float = 90, label: str = ""):
        """签发一把新 key；返回 (token_id, 明文key)。明文只在这里出现一次。"""
        validate_name(user, "user")
        key = new_api_key()
        token_id = secrets.token_hex(6)
        now = time.time()
        expires = now + float(days) * 86400 if days and float(days) > 0 else 0.0
        self._exec(
            "INSERT INTO tokens VALUES (?,?,?,?,?,?,?,?,?)",
            (token_id, _hash_key(key), user, ",".join(scopes), label,
             expires, 0, now, 0.0),
        )
        return token_id, key

    def lookup(self, key: str) -> Principal | None:
        rows = self._exec(
            "SELECT token_id,user,scopes,expires_at,revoked FROM tokens WHERE key_hash=?",
            (_hash_key(key),),
        )
        if not rows:
            return None
        token_id, user, scopes, expires_at, revoked = rows[0]
        if revoked:
            return None
        if expires_at and expires_at < time.time():
            return None
        self._exec("UPDATE tokens SET last_used_at=? WHERE token_id=?",
                   (time.time(), token_id))
        return Principal(user=user,
                         scopes=frozenset(s for s in (scopes or "").split(",") if s),
                         token_id=token_id)

    def list(self) -> list[dict]:
        rows = self._exec(
            "SELECT token_id,user,scopes,label,expires_at,revoked,created_at,last_used_at"
            " FROM tokens ORDER BY created_at DESC"
        )
        out = []
        now = time.time()
        for (tid, user, scopes, label, exp, revoked, created, used) in rows:
            out.append({
                "token_id": tid, "user": user, "scopes": scopes, "label": label,
                "expires_at": exp, "revoked": bool(revoked),
                "created_at": created, "last_used_at": used,
                "state": ("revoked" if revoked
                          else "expired" if (exp and exp < now) else "active"),
            })
        return out

    def revoke(self, token_id: str) -> bool:
        rows = self._exec("SELECT token_id FROM tokens WHERE token_id=?", (token_id,))
        if not rows:
            return False
        self._exec("UPDATE tokens SET revoked=1 WHERE token_id=?", (token_id,))
        reset_cache()                  # 本进程立即生效（跨实例仍受缓存 TTL 约束）
        return True

    def revoke_user(self, user: str) -> int:
        """撤销某个用户的全部凭据（不物理删除，留审计痕迹）。"""
        rows = self._exec(
            "SELECT COUNT(*) FROM tokens WHERE user=? AND revoked=0", (user,))
        n = int(rows[0][0]) if rows else 0
        if n:
            self._exec("UPDATE tokens SET revoked=1 WHERE user=? AND revoked=0", (user,))
            reset_cache()
        return n

    def users(self) -> list[str]:
        rows = self._exec("SELECT DISTINCT user FROM tokens")
        return sorted({str(r[0]) for r in rows if r[0]})

    def count_active(self) -> int:
        rows = self._exec(
            "SELECT COUNT(*) FROM tokens WHERE revoked=0 AND (expires_at=0 OR expires_at>?)",
            (time.time(),),
        )
        return int(rows[0][0]) if rows else 0

    def count_all(self) -> int:
        """所有 token（含已撤销/过期）—— 用来判断"这套部署是否启用过鉴权"。"""
        rows = self._exec("SELECT COUNT(*) FROM tokens")
        return int(rows[0][0]) if rows else 0


_store_singleton: TokenStore | None = None
_store_lock = threading.Lock()


def _store() -> TokenStore:
    global _store_singleton
    if _store_singleton is None:
        with _store_lock:
            if _store_singleton is None:
                _store_singleton = TokenStore()
    return _store_singleton


def store() -> TokenStore:
    """公开的凭据库句柄（供生命周期管理使用）。"""
    return _store()


# ===================== 鉴权开关与缓存 =====================

_enabled_cache: tuple[float, bool] | None = None
_CACHE: dict[str, tuple[float, Principal | None]] = {}
_CACHE_LOCK = threading.Lock()


def _ttl() -> float:
    try:
        return max(0.0, float(os.getenv("AUTH_CACHE_TTL", "30")))
    except ValueError:
        return 30.0


def enabled() -> bool:
    """是否开启鉴权。

    判定顺序：配了 AGENT_USERS → 开；AUTH_REQUIRED=1 → 开（强制 fail-closed）；
    凭据库里**存在过任何 token**（含已撤销/过期）→ 开。

    注意：这里刻意用 count_all 而不是 count_active —— 若按"还有没有活跃 token"
    判断，把最后一个 token 撤销后鉴权会**自动关闭**，所有人都变成匿名 admin，
    这是典型的 fail-open 漏洞。
    """
    global _enabled_cache
    if (os.getenv(ENV_USERS) or "").strip():
        return True
    if (os.getenv("AUTH_REQUIRED") or "").strip().lower() in ("1", "true", "yes", "on"):
        return True
    now = time.time()
    if _enabled_cache and now - _enabled_cache[0] < _ttl():
        return _enabled_cache[1]
    p = _tokens_path()
    # 文件不存在就不查库（避免"没开鉴权"的部署被动建库）
    val = bool(p.exists() and _store().count_all() > 0)
    _enabled_cache = (now, val)
    return val


def _parse(raw: str) -> dict[str, str]:
    """把 "alice:key1,bob:key2" 解析成 {key: user}。"""
    table: dict[str, str] = {}
    for item in (raw or "").split(","):
        item = item.strip()
        if not item:
            continue
        if ":" not in item:
            raise AuthError(f"{ENV_USERS} 条目应为 user:key 格式，收到：{item!r}")
        user, key = (part.strip() for part in item.split(":", 1))
        if not user or not key:
            raise AuthError(f"{ENV_USERS} 条目的 user / key 不能为空：{item!r}")
        validate_name(user, "user")
        if key in table:
            raise AuthError(f"API key 重复：{key[:6]}…")
        table[key] = user
    return table


def _cache_get(key_hash: str) -> tuple[bool, Principal | None]:
    with _CACHE_LOCK:
        hit = _CACHE.get(key_hash)
    if hit and time.time() - hit[0] < _ttl():
        return True, hit[1]
    return False, None


def _cache_put(key_hash: str, principal: Principal | None) -> None:
    with _CACHE_LOCK:
        _CACHE[key_hash] = (time.time(), principal)


def resolve(api_key: str | None) -> Principal | None:
    """按 API key 找身份；未配置鉴权时返回匿名身份；key 不匹配返回 None。"""
    if not enabled():
        return Principal(DEFAULT_USER, frozenset(FULL_SCOPES))
    if not api_key:
        return None

    # 1) 静态 env 用户（明文在环境变量里，用 compare_digest 防时序侧信道）
    for key, user in _parse(os.getenv(ENV_USERS, "")).items():
        if hmac.compare_digest(key, api_key):
            return Principal(user, frozenset(FULL_SCOPES))

    # 2) 动态 token（带 TTL 缓存，避免每请求一次 scrypt/DB）
    key_hash = _hash_key(api_key)
    hit, cached = _cache_get(key_hash)
    if hit:
        return cached
    principal = None
    if _tokens_path().exists():
        principal = _store().lookup(api_key)
    _cache_put(key_hash, principal)
    return principal


def from_headers(authorization: str | None, x_api_key: str | None) -> Principal | None:
    """支持 `Authorization: Bearer <key>` 与 `X-API-Key: <key>` 两种携带方式。"""
    key = None
    if authorization:
        parts = authorization.split(None, 1)
        if len(parts) == 2 and parts[0].lower() == "bearer":
            key = parts[1].strip()
        else:
            key = authorization.strip()
    if not key and x_api_key:
        key = x_api_key.strip()
    return resolve(key)


def session_key(user: str, sid: str) -> str:
    """把 (用户, 会话名) 映射成磁盘上的会话 ID。

    - 鉴权关闭：原样返回（保持既有 sessions/*.json 不变）；
    - 鉴权开启：加 "user__" 前缀，实现按用户隔离。
    """
    sid = validate_name(sid, "session_id")
    if not enabled():
        return sid
    return f"{validate_name(user, 'user')}__{sid}"


def reset_cache() -> None:
    """清空进程内缓存（测试 / 改配置后用）。"""
    global _enabled_cache
    with _CACHE_LOCK:
        _CACHE.clear()
    _enabled_cache = None


# ===================== CLI：签发 / 列表 / 撤销 =====================

def _cli(argv=None) -> int:
    import argparse
    ap = argparse.ArgumentParser(description="凭据管理（第 23 步）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("issue", help="签发一把新 key（明文只显示一次）")
    pi.add_argument("--user", required=True)
    pi.add_argument("--days", type=float, default=90, help="有效期天数；0 表示不过期")
    pi.add_argument("--scopes", default=",".join(DEFAULT_SCOPES))
    pi.add_argument("--label", default="")

    sub.add_parser("list", help="列出所有 token（不含明文 key）")

    pr = sub.add_parser("revoke", help="按 token_id 撤销")
    pr.add_argument("token_id")

    args = ap.parse_args(argv)
    store = _store()
    if args.cmd == "issue":
        scopes = [s.strip() for s in args.scopes.split(",") if s.strip()]
        token_id, key = store.issue(args.user, scopes, args.days, args.label)
        print(f"token_id = {token_id}")
        print(f"api_key  = {key}")
        print("（明文只显示这一次，请立即保存；库里只存哈希）")
        print(f"库文件   = {_tokens_path()}")
    elif args.cmd == "list":
        rows = store.list()
        if not rows:
            print("（还没有任何 token）")
        for r in rows:
            print(f"{r['token_id']}  {r['user']:<12} {r['state']:<8} "
                  f"scopes={r['scopes']}  label={r['label']}")
    else:
        print("已撤销" if store.revoke(args.token_id) else "未找到该 token_id")
    return 0


if __name__ == "__main__":
    raise SystemExit(_cli())
