import threading
from dataclasses import dataclass,field
from enum import Enum
from typing import Callable

class Status(str, Enum):
    COMPLETED = "completed"
    INCOMPLETED = "incompleted"
    BUDGET_EXCEEDED = "budget_exceeded"
    TIMEOUT = "timeout"
    FAILED = "failed"
    CANCELLED = "cancelled"
    
@dataclass
class ToolCallRecord:
    name: str #工具名
    arguments: str #参数列表
    output: str #执行结果
    error: bool #是否报错
    
@dataclass
class AgentResult:
    final_text: str
    status: Status = Status.COMPLETED
    steps: int = 0
    tool_calls: list[ToolCallRecord] = field(default_factory=list)
    usage: dict = field(default_factory=dict) 
    error: str | None = None


@dataclass
class RunContext:
    """一次运行的显式上下文：用参数传递"角色 + 允许的工具子集"。

    存在的意义：取代此前 orchestrator 里的运行时 monkeypatch
    （改 agent_loop.get_schema / permissions._ask_user）。
    显式传参后，每个运行各带一份，天然并发安全。

    - role_name:   角色名，仅用于日志与拒绝提示；
    - tool_filter: 允许调用的工具名集合；None 表示不限制
                   （单循环 CLI / 服务 / 评测都传 None，行为不变）。
    """
    role_name: str | None = None
    tool_filter: set[str] | None = None
    user: str | None = None          # 第 27 步：归属用户（记忆/轨迹按它隔离）
    run_id: str | None = None        # 第 28 步：用于幂等副作用（键的一部分）
    step_key: str | None = None      # 第 28 步：子任务级步骤标识，如 "r0-t1"


class CancelToken:
    """取消令牌：让"取消"以显式参数的形式进入内核，而不是靠查全局状态。

    - 本地取消：cancel() 直接置位，线程安全；
    - 外部取消：可绑定一个 is_cancelled 判定函数（如查询 run 存储里的
      "取消请求"标记），从而支持"另一个进程/实例发起的取消"——
      因为令牌只有在被检查时才去读外部状态，所以不需要跨进程共享内存。

    注意：取消是"协作式"的，内核在步与步之间检查；正在进行的单次网络请求
    不会被立刻打断，会在该步结束后生效。
    """

    def __init__(self, is_cancelled: Callable[[], bool] | None = None):
        self._event = threading.Event()
        self._external = is_cancelled

    def cancel(self) -> None:
        self._event.set()

    def is_set(self) -> bool:
        if self._event.is_set():
            return True
        if self._external is not None:
            try:
                if self._external():
                    self._event.set()
                    return True
            except Exception:
                pass                       # 外部存储抖动不应影响主流程
        return False
