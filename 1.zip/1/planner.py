"""v3 · Planner：把用户目标拆成结构化计划（含角色分配）。只规划，不执行任何工具。"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

from pydantic import BaseModel, Field

from config import Config
from llm.LLM import llm
from skills.assembler import skill_catalog


# ---------------- 计划的数据结构 ----------------

@dataclass
class SubTask:
    id: str
    goal: str
    role: str = "general"
    depends_on: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"id": self.id, "goal": self.goal, "role": self.role,
                "depends_on": list(self.depends_on)}

    @classmethod
    def from_dict(cls, d: dict) -> "SubTask":
        return cls(id=str(d.get("id", "")), goal=str(d.get("goal", "")),
                   role=str(d.get("role") or "general"),
                   depends_on=[str(x) for x in (d.get("depends_on") or [])])


@dataclass
class Plan:
    subtasks: list[SubTask] = field(default_factory=list)
    goal: str = ""

    def to_dict(self) -> dict:
        """序列化（第 28 步）：续跑要复用**旧计划**，不能重新规划。"""
        return {"goal": self.goal, "subtasks": [s.to_dict() for s in self.subtasks]}

    @classmethod
    def from_dict(cls, d: dict) -> "Plan":
        return cls(goal=str(d.get("goal", "")),
                   subtasks=[SubTask.from_dict(s) for s in (d.get("subtasks") or [])])

    def topo_order(self) -> list[SubTask]:
        """按依赖排序；顺带抓出未知依赖和环。"""
        by_id = {s.id: s for s in self.subtasks}
        for s in self.subtasks:
            for d in s.depends_on:
                if d not in by_id:
                    raise ValueError(f"子任务 {s.id} 依赖了不存在的 {d}")

        order, done, visiting = [], set(), set()

        def visit(node: SubTask):
            if node.id in done:
                return
            if node.id in visiting:
                raise ValueError(f"计划存在环：{node.id}")
            visiting.add(node.id)
            for d in node.depends_on:
                visit(by_id[d])
            visiting.discard(node.id)
            done.add(node.id)
            order.append(node)

        for s in self.subtasks:
            visit(s)
        return order


# ---------------- 强制 Planner 输出结构化计划 ----------------

class _SubTaskArgs(BaseModel):
    id: str = Field(description="短标识，如 t1、t2")
    goal: str = Field(description="可直接交给执行者、能独立交付的子目标")
    role: str = Field(default="general",
                      description="执行该子任务的角色：researcher / operator / general")
    depends_on: list[str] = Field(default_factory=list, description="依赖的子任务 id；无依赖留空")


class _PlanArgs(BaseModel):
    subtasks: list[_SubTaskArgs] = Field(description="2-6 个子任务，按依赖先后排列")


_PLAN_TOOL = {
    "type": "function",
    "name": "submit_plan",
    "description": "提交任务拆解方案（只做规划，不执行任何工具）",
    "parameters": _PlanArgs.model_json_schema(),
}

_PLANNER_INSTRUCTIONS = """你是任务规划器。把用户目标拆解成 2-6 个可独立执行的子任务，只做拆解，绝不执行、绝不调用其它工具。

可用技能（技能=一组工具，执行者会用到；用来判断该怎么拆）：
{tools}

可用角色（给每个子任务选一个，写进 role 字段）：
{roles}

规则：
- 每个子任务必须自包含：执行者只看得到这一个子任务，也要能独立完成。
- 只读的信息获取/核对 → researcher；有副作用的写入动作 → operator；不好归类 → general。
- 能并行的子任务之间不要写依赖；有先后关系的用 depends_on 标出。
- 不要把"汇总/写最终答复"拆成子任务，那由上层负责。
- 只通过 submit_plan 提交结果。{context}"""


def _extract_json(text: str) -> dict:
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        raise ValueError("Planner 输出里没有找到 JSON")
    return json.loads(m.group(0))


def _tool_catalog() -> str:
    return skill_catalog()


def make_plan(goal: str, cfg: Config, *, roles_text: str = "",
              context: str = "") -> Plan:
    """目标 -> Plan。一次 LLM 调用。context 用于把重规划要求拼进提示词。"""
    instructions = _PLANNER_INSTRUCTIONS.format(
        tools=_tool_catalog(),
        roles=roles_text or "（无）",
        context=("\n\n补充要求：\n" + context) if context else "",
    )
    base = dict(
        model=cfg.model,
        instructions=instructions,
        input=[{"role": "user", "content": goal}],
        tools=[_PLAN_TOOL],
    )
    try:
        resp = llm(**base, tool_choice={"type": "function", "name": "submit_plan"})
    except Exception:
        resp = llm(**base)                     # 端点不支持强制 tool_choice 时退回

    plan_args = None
    for it in (getattr(resp, "output", None) or []):
        if getattr(it, "type", None) == "function_call" and getattr(it, "name", None) == "submit_plan":
            plan_args = _PlanArgs.model_validate_json(it.arguments)
            break
    if plan_args is None:                      # 兜底：从文本里抠 JSON
        plan_args = _PlanArgs.model_validate(_extract_json(resp.output_text))

    plan = Plan(goal=goal, subtasks=[
        SubTask(s.id, s.goal, s.role or "general", list(s.depends_on))
        for s in plan_args.subtasks
    ])
    plan.topo_order()                          # 提前校验（未知依赖 / 环）
    return plan
