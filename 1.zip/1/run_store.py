"""run 元数据存储：把 run 的状态从进程内存里挪出来（第 17 步）。

背景：service.py 原来是 `RUNS: dict`，纯进程内存 —— 进程重启即丢、多实例互相看不见，
也没法提供"查询 / 取消某个 run"的能力。

本模块给一个最小抽象：

- InMemoryRunStore：单进程默认，行为与原来一致；
- SqliteRunStore：落盘到 SQLite（标准库，无新依赖）。重启后仍能查到 run 的终态；
  多个实例指向同一个 db 文件时，可共享 run 的**元数据**与**取消请求标记**。

边界（重要）：这里外置的是 run 的元数据 / 状态。**实时事件流**（asyncio.Queue）
天然属于某个进程，跨实例的实时推送需要再引入消息中间件（如 Redis pub/sub），
不在本步范围内。

后端由环境变量选择：
    RUN_STORE=memory             # 默认
    RUN_STORE=sqlite
    RUN_STORE_PATH=1/runs.db     # 默认 1/runs.db
"""
from __future__ import annotations

import copy
import json
import os
import sqlite3
import threading
import time
from dataclasses import asdict, dataclass
from pathlib import Path

RUNNING = "running"
COMPLETED = "completed"
FAILED = "failed"
CANCELLED = "cancelled"

# 审批状态（第 28 步：审批外置，支持跨实例）
PENDING = "pending"
APPROVED = "approved"
DENIED = "denied"
TIMEOUT = "timeout"

# 表的列顺序（显式列名，不依赖物理顺序，便于给老库补列）
_COLS = ("run_id", "kind", "status", "target", "user",
         "created_at", "updated_at", "error", "summary", "cancel_requested")
_SELECT = "SELECT " + ", ".join(_COLS) + " FROM runs"

# 允许被 update() 修改的字段（白名单，避免动态拼 SQL 被注入）
_MUTABLE = {"kind", "status", "target", "error", "summary", "cancel_requested"}


@dataclass
class RunRecord:
    run_id: str
    kind: str = "chat"              # "chat" | "plan"
    status: str = RUNNING
    target: str = ""                # session_id 或 goal
    user: str = ""                  # 归属用户（第 23 步：多租户隔离的依据）
    created_at: float = 0.0
    updated_at: float = 0.0
    error: str | None = None
    summary: dict | None = None
    cancel_requested: bool = False

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ApprovalRecord:
    """一次人工审批（HITL）请求。放在共享存储里，任何实例都能批准。"""

    approval_id: str
    run_id: str = ""
    user: str = ""
    tool: str = ""
    detail: str = ""
    status: str = PENDING
    created_at: float = 0.0
    resolved_at: float = 0.0
    resolved_by: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


class InMemoryRunStore:
    """进程内实现：单实例默认，接口与 SqliteRunStore 一致。"""

    def __init__(self) -> None:
        self._rows: dict[str, RunRecord] = {}
        self._approvals: dict[str, ApprovalRecord] = {}
        self._lock = threading.Lock()

    def create(self, rec: RunRecord) -> None:
        now = time.time()
        rec.created_at = rec.created_at or now
        rec.updated_at = now
        with self._lock:
            self._rows[rec.run_id] = rec

    def update(self, run_id: str, **fields) -> None:
        with self._lock:
            rec = self._rows.get(run_id)
            if rec is None:
                return
            for k, v in fields.items():
                if k in _MUTABLE:
                    setattr(rec, k, v)
            rec.updated_at = time.time()

    def get(self, run_id: str) -> RunRecord | None:
        with self._lock:
            rec = self._rows.get(run_id)
            return copy.deepcopy(rec) if rec else None

    def list(self, limit: int = 50, user: str | None = None) -> list[RunRecord]:
        with self._lock:
            rows = list(self._rows.values())
            if user is not None:                     # 只列本人的 run
                rows = [r for r in rows if r.user == user]
            rows = sorted(rows, key=lambda r: r.created_at, reverse=True)
            return copy.deepcopy(rows[:limit])

    def request_cancel(self, run_id: str) -> None:
        with self._lock:
            rec = self._rows.get(run_id)
            if rec is not None:
                rec.cancel_requested = True
                rec.updated_at = time.time()

    def is_cancel_requested(self, run_id: str) -> bool:
        with self._lock:
            rec = self._rows.get(run_id)
            return bool(rec and rec.cancel_requested)

    # ---- 审批 ----
    def create_approval(self, a: ApprovalRecord) -> None:
        a.created_at = a.created_at or time.time()
        with self._lock:
            self._approvals[a.approval_id] = a

    def get_approval(self, approval_id: str) -> ApprovalRecord | None:
        with self._lock:
            a = self._approvals.get(approval_id)
            return copy.deepcopy(a) if a else None

    def resolve_approval(self, approval_id: str, status: str,
                         by: str = "") -> bool:
        """只有处于 pending 的审批能被决议；返回是否真的改动了。"""
        with self._lock:
            a = self._approvals.get(approval_id)
            if a is None or a.status != PENDING:
                return False
            a.status = status
            a.resolved_at = time.time()
            a.resolved_by = by
            return True

    # ---- 生命周期（第 27 步）----
    def list_approvals(self, user: str | None = None, limit: int = 1000) -> list[ApprovalRecord]:
        with self._lock:
            rows = [a for a in self._approvals.values()
                    if user is None or a.user == user]
            rows.sort(key=lambda a: a.created_at, reverse=True)
            return copy.deepcopy(rows[:limit])

    def purge_user(self, user: str) -> dict:
        with self._lock:
            runs = [k for k, r in self._rows.items() if r.user == user]
            for k in runs:
                del self._rows[k]
            aps = [k for k, a in self._approvals.items() if a.user == user]
            for k in aps:
                del self._approvals[k]
        return {"runs": len(runs), "approvals": len(aps)}

    def purge_older_than(self, cutoff: float) -> dict:
        with self._lock:
            runs = [k for k, r in self._rows.items()
                    if r.created_at < cutoff]
            for k in runs:
                del self._rows[k]
            aps = [k for k, a in self._approvals.items()
                   if a.created_at < cutoff]
            for k in aps:
                del self._approvals[k]
        return {"runs": len(runs), "approvals": len(aps)}

    def purge_user_older_than(self, user: str, cutoff: float) -> dict:
        """只清某个用户的过期数据（保留策略做用户豁免时用）。"""
        with self._lock:
            runs = [k for k, r in self._rows.items()
                    if r.user == user and r.created_at < cutoff]
            for k in runs:
                del self._rows[k]
            aps = [k for k, a in self._approvals.items()
                   if a.user == user and a.created_at < cutoff]
            for k in aps:
                del self._approvals[k]
        return {"runs": len(runs), "approvals": len(aps)}


class SqliteRunStore:
    """SQLite 落盘实现：重启不丢、多实例可共享元数据与取消标记。

    每次操作独立开关连接，天然线程安全；写入用参数化 SQL。
    """

    def __init__(self, path: str | Path) -> None:
        self.path = str(path)
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._execute(
            """CREATE TABLE IF NOT EXISTS runs (
                run_id           TEXT PRIMARY KEY,
                kind             TEXT,
                status           TEXT,
                target           TEXT,
                user             TEXT,
                created_at       REAL,
                updated_at       REAL,
                error            TEXT,
                summary          TEXT,
                cancel_requested INTEGER DEFAULT 0
            )"""
        )
        self._migrate()
        self._execute(
            """CREATE TABLE IF NOT EXISTS approvals (
                approval_id TEXT PRIMARY KEY,
                run_id      TEXT,
                user        TEXT,
                tool        TEXT,
                detail      TEXT,
                status      TEXT,
                created_at  REAL,
                resolved_at REAL,
                resolved_by TEXT
            )"""
        )

    def _migrate(self) -> None:
        """老库（第 17 步建的，没有 user 列）补上该列，保证向后兼容。"""
        cols = {row[1] for row in self._execute("PRAGMA table_info(runs)")}
        if "user" not in cols:
            self._execute("ALTER TABLE runs ADD COLUMN user TEXT")

    # ---- 底层 ----
    def _execute(self, sql: str, params: tuple = ()) -> list[tuple]:
        with self._lock:
            conn = sqlite3.connect(self.path, timeout=5)
            try:
                cur = conn.execute(sql, params)
                rows = cur.fetchall()
                conn.commit()
                return rows
            finally:
                conn.close()

    @staticmethod
    def _row(rec: RunRecord) -> tuple:
        return (
            rec.run_id, rec.kind, rec.status, rec.target, rec.user, rec.created_at,
            rec.updated_at, rec.error,
            json.dumps(rec.summary, ensure_ascii=False) if rec.summary is not None else None,
            1 if rec.cancel_requested else 0,
        )

    @staticmethod
    def _to_record(row: tuple) -> RunRecord:
        (run_id, kind, status, target, user, created_at, updated_at,
         error, summary, cancel) = row
        return RunRecord(
            run_id=run_id, kind=kind, status=status, target=target or "",
            user=user or "", created_at=created_at or 0.0, updated_at=updated_at or 0.0,
            error=error,
            summary=json.loads(summary) if summary else None,
            cancel_requested=bool(cancel),
        )

    # ---- 接口 ----
    def create(self, rec: RunRecord) -> None:
        now = time.time()
        rec.created_at = rec.created_at or now
        rec.updated_at = now
        holders = ",".join("?" * len(_COLS))
        self._execute(
            f"INSERT OR REPLACE INTO runs ({','.join(_COLS)}) VALUES ({holders})",
            self._row(rec),
        )

    def update(self, run_id: str, **fields) -> None:
        fields = {k: v for k, v in fields.items() if k in _MUTABLE}
        fields["updated_at"] = time.time()
        if "summary" in fields and fields["summary"] is not None:
            fields["summary"] = json.dumps(fields["summary"], ensure_ascii=False)
        cols = ", ".join(f"{k}=?" for k in fields)
        self._execute(f"UPDATE runs SET {cols} WHERE run_id=?",
                      (*fields.values(), run_id))

    def get(self, run_id: str) -> RunRecord | None:
        rows = self._execute(f"{_SELECT} WHERE run_id=?", (run_id,))
        return self._to_record(rows[0]) if rows else None

    def list(self, limit: int = 50, user: str | None = None) -> list[RunRecord]:
        if user is None:
            rows = self._execute(
                f"{_SELECT} ORDER BY created_at DESC LIMIT ?", (int(limit),)
            )
        else:
            rows = self._execute(
                f"{_SELECT} WHERE user=? ORDER BY created_at DESC LIMIT ?",
                (user, int(limit)),
            )
        return [self._to_record(r) for r in rows]

    def request_cancel(self, run_id: str) -> None:
        self._execute(
            "UPDATE runs SET cancel_requested=1, updated_at=? WHERE run_id=?",
            (time.time(), run_id),
        )

    def is_cancel_requested(self, run_id: str) -> bool:
        rows = self._execute(
            "SELECT cancel_requested FROM runs WHERE run_id=?", (run_id,)
        )
        return bool(rows and rows[0][0])

    # ---- 审批 ----
    _AP_COLS = ("approval_id", "run_id", "user", "tool", "detail",
                "status", "created_at", "resolved_at", "resolved_by")

    @staticmethod
    def _ap_row(a: ApprovalRecord) -> tuple:
        return (a.approval_id, a.run_id, a.user, a.tool, a.detail,
                a.status, a.created_at, a.resolved_at, a.resolved_by)

    @staticmethod
    def _to_approval(row: tuple) -> ApprovalRecord:
        aid, run_id, user, tool, detail, status, created, resolved, by = row
        return ApprovalRecord(approval_id=aid, run_id=run_id or "", user=user or "",
                              tool=tool or "", detail=detail or "", status=status,
                              created_at=created or 0.0, resolved_at=resolved or 0.0,
                              resolved_by=by or "")

    def create_approval(self, a: ApprovalRecord) -> None:
        a.created_at = a.created_at or time.time()
        cols = ",".join(self._AP_COLS)
        holders = ",".join("?" * len(self._AP_COLS))
        self._execute(
            f"INSERT OR REPLACE INTO approvals ({cols}) VALUES ({holders})",
            self._ap_row(a),
        )

    def get_approval(self, approval_id: str) -> ApprovalRecord | None:
        rows = self._execute(
            f"SELECT {','.join(self._AP_COLS)} FROM approvals WHERE approval_id=?",
            (approval_id,),
        )
        return self._to_approval(rows[0]) if rows else None

    def resolve_approval(self, approval_id: str, status: str,
                         by: str = "") -> bool:
        """原子决议：只有仍为 pending 的行会被更新（多实例竞争下只有一个成功）。"""
        with self._lock:
            conn = sqlite3.connect(self.path, timeout=5)
            try:
                cur = conn.execute(
                    "UPDATE approvals SET status=?, resolved_at=?, resolved_by=?"
                    " WHERE approval_id=? AND status=?",
                    (status, time.time(), by, approval_id, PENDING),
                )
                conn.commit()
                return cur.rowcount > 0
            finally:
                conn.close()

    # ---- 生命周期（第 27 步）----
    def _count(self, table: str, where: str = "", params: tuple = ()) -> int:
        sql = f"SELECT COUNT(*) FROM {table}" + (f" WHERE {where}" if where else "")
        rows = self._execute(sql, params)
        return int(rows[0][0]) if rows else 0

    def list_approvals(self, user: str | None = None,
                       limit: int = 1000) -> list[ApprovalRecord]:
        cols = ",".join(self._AP_COLS)
        if user is None:
            rows = self._execute(
                f"SELECT {cols} FROM approvals ORDER BY created_at DESC LIMIT ?",
                (int(limit),))
        else:
            rows = self._execute(
                f"SELECT {cols} FROM approvals WHERE user=?"
                " ORDER BY created_at DESC LIMIT ?", (user, int(limit)))
        return [self._to_approval(r) for r in rows]

    def purge_user(self, user: str) -> dict:
        """在一个事务里删 runs + approvals，避免「删一半」。"""
        return self._purge_tx("user=?", (user,))

    def purge_older_than(self, cutoff: float) -> dict:
        # 不再附加 created_at>0 —— 时间戳缺失(0)的行也按"最旧"处理
        return self._purge_tx("created_at<?", (cutoff,))

    def purge_user_older_than(self, user: str, cutoff: float) -> dict:
        return self._purge_tx("user=? AND created_at<?", (user, cutoff))

    def _purge_tx(self, where: str, params: tuple) -> dict:
        with self._lock:
            conn = sqlite3.connect(self.path, timeout=5)
            try:
                cur = conn.cursor()
                runs = cur.execute(
                    f"SELECT COUNT(*) FROM runs WHERE {where}", params).fetchone()[0]
                aps = cur.execute(
                    f"SELECT COUNT(*) FROM approvals WHERE {where}", params).fetchone()[0]
                cur.execute(f"DELETE FROM runs WHERE {where}", params)
                cur.execute(f"DELETE FROM approvals WHERE {where}", params)
                conn.commit()
                return {"runs": int(runs), "approvals": int(aps)}
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()


_store = None
_store_lock = threading.Lock()


def get_store():
    """按环境变量返回单例 store：RUN_STORE=memory|sqlite。"""
    global _store
    if _store is not None:
        return _store
    with _store_lock:
        if _store is None:
            backend = (os.getenv("RUN_STORE") or "memory").strip().lower()
            if backend == "sqlite":
                path = Path(os.getenv("RUN_STORE_PATH") or "runs.db")
                if not path.is_absolute():
                    path = Path(__file__).resolve().parent / path
                _store = SqliteRunStore(path)
            else:
                _store = InMemoryRunStore()
    return _store
