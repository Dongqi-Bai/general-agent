"""tools 包：注册表(registry) / 权限(permissions) / 沙箱(sandbox) / 工具执行(utils)。

工具不再写死在本包里：工具由 skills 下的技能目录装载并注册。
装载入口是 skills.loader.load_all()，由 get_schema() / assemble() / 角色初始化按需触发。
这里刻意不做任何自动导入，避免 tools 与 skills 之间形成循环导入。
"""
