"""沙箱路径基础设施：所有文件类工具共用同一套越界检查。

注意：SANDBOX_ROOT 在「本模块被导入时」从环境变量读取一次。
评测运行器会在导入 tools.* 之前把 SANDBOX_ROOT 指向临时目录，
所以这里必须保持「导入时读取」，不要改成每次调用都读。
"""
from __future__ import annotations

import os
from pathlib import Path

SANDBOX_ROOT = Path(os.getenv("SANDBOX_ROOT", "D:/agent学习最终版/workspace")).resolve()


def resolve_in_sandbox(v: str) -> str:
    p = Path(v)
    if not p.is_absolute():
        p = SANDBOX_ROOT / p
    p = p.resolve()                          # 解析掉 ../ 和软链接
    if not p.is_relative_to(SANDBOX_ROOT):
        raise ValueError(f"路径越界，只允许访问 {SANDBOX_ROOT} 内部")
    return str(p)
