"""工具执行入口：参数校验 → 权限裁决 → 调用 → 错误回传。

参数校验分两条路：
- 本地工具（有 pydantic 模型）→ model_validate；
- 外部工具（只有 JSON Schema，如第 21 步的 MCP）→ jsonschema 校验。

get_schema(skills) 决定把哪些工具暴露给模型；skills=None 表示全部技能。
load_all() 会顺带装载"已启用"的外部 MCP server，所以 MCP 工具在这里就位。
"""
from __future__ import annotations

import hashlib
import json

import reliability
import tenant
from skills.loader import load_all
from tools.permissions import check_permission
from tools.registry import TOOL_REGISTRY, Risk


def _effect_key(name: str, arguments_json: str) -> str | None:
    """副作用工具的幂等键：run + 步骤 + 工具 + 参数哈希。

    同一个 run 重放同一步的同一个调用 → 命中缓存、不再真执行，
    避免重试 / 续跑时把 write_file(append) 写两遍。READ 类工具不参与。
    """
    run_id, step = tenant.current_run()
    if not run_id:
        return None
    digest = hashlib.sha1((arguments_json or "").encode("utf-8")).hexdigest()[:12]
    return f"{run_id}:{step}:{name}:{digest}"


def _parse_args(entry, arguments_json):
    """返回 (args_dict, error)；error 为 None 表示校验通过。"""
    try:
        raw = json.loads(arguments_json or "{}")
    except Exception as e:
        return None, f"参数不是合法 JSON：{e}"
    if not isinstance(raw, dict):
        return None, f"参数必须是 JSON 对象，收到：{type(raw).__name__}"

    model = entry.get("args_model")
    if model is not None:                              # 本地工具
        try:
            return model.model_validate(raw).model_dump(), None
        except Exception as e:
            return None, f"参数不合法：{e}"

    try:                                               # 外部工具：按 JSON Schema 校验
        import jsonschema
        jsonschema.validate(raw, entry["schema"]["parameters"])
    except Exception as e:
        return None, f"参数不符合 schema：{e}"
    return raw, None


def run_tool(name, arguments_json):
    load_all()                                          # 保证注册表已装载（含 MCP）
    entry = TOOL_REGISTRY.get(name)
    if entry is None:
        return f"未知工具：{name}", True
    args, err = _parse_args(entry, arguments_json)
    if err is not None:
        return err, True
    ok, reason = check_permission(name, args)          # ★ 裁决
    if not ok:
        return f"权限拒绝：{reason}", True              # 拒绝也回给模型，让它改路
    side_effect = entry.get("risk") not in (None, Risk.READ)
    key = _effect_key(name, arguments_json) if side_effect else None
    if key:                                            # ★ 幂等：已执行过就直接返回
        try:
            prev = reliability.get_store().get_effect(key)
        except Exception:
            prev = None
        if prev is not None:
            return prev.get("result") or "", bool(prev.get("error"))
    try:
        result = entry["function"](**args)
    except Exception as e:
        return f"工具执行出错：{e}", True               # 失败不缓存，续跑时可重试
    if key:
        try:
            run_id, _step = tenant.current_run()
            reliability.get_store().save_effect(key, run_id, tenant.current_user(),
                                                name, str(result), False)
        except Exception:
            pass
    return result, False


def get_schema(skills=None):
    """返回工具的 function schema 列表；skills=None → 全部技能。"""
    load_all()
    entries = list(TOOL_REGISTRY.values())
    if skills is not None:
        wanted = set(skills)
        entries = [e for e in entries if e.get("skill") in wanted]
    return [e["schema"] for e in entries]


def tool_owner(name: str):
    """工具归属于哪个技能（未归属返回 None）。"""
    return (TOOL_REGISTRY.get(name) or {}).get("skill")
