# tools/permissions.py
"""权限裁决：READ 放行；WRITE 需人工确认（HITL）；DANGER 默认拒绝。

审批器可注入：服务化时外层用 set_approver(fn) 把 input() 换成异步审批，
内核（run_tool → check_permission → _ask_user）无需任何改动。
"""
from __future__ import annotations

import contextvars
from typing import Callable

from tools.registry import TOOL_REGISTRY, Risk

# 当前上下文里的审批器：fn(name, args) -> (ok, reason)；None 表示走本地终端交互。
_approver: contextvars.ContextVar[Callable | None] = contextvars.ContextVar(
    "tool_approver", default=None
)


def set_approver(fn: Callable | None):
    """安装当前上下文的审批器，返回 token（用完用 reset_approver 还原）。"""
    return _approver.set(fn)


def reset_approver(token) -> None:
    _approver.reset(token)


def _get(args, key, default=None):
    """参数可能是 pydantic 对象（本地工具）或 dict（MCP 等外部工具）。"""
    if isinstance(args, dict):
        return args.get(key, default)
    return getattr(args, key, default)


def describe(name: str, args) -> str:
    """给审批人看的人类可读详情（写文件时带内容预览）。"""
    entry = TOOL_REGISTRY.get(name, {})
    content = _get(args, "content")
    if entry.get("risk") == Risk.WRITE and isinstance(content, str):
        preview = content[:200].replace("\n", "\\n")
        more = "…" if len(content) > 200 else ""
        return (f"path={_get(args, 'path')} mode={_get(args, 'mode')} "
                f"内容预览：{preview}{more}")
    if entry.get("external"):
        return f"外部工具（MCP server={entry.get('server') or '?'}）参数={args}"
    return str(args)


def check_permission(name, args) -> tuple[bool, str]:
    entry = TOOL_REGISTRY.get(name)
    if entry is None:
        return False, f"未知工具：{name}"
    risk = entry["risk"]
    if risk == Risk.READ:
        return True, ""
    if risk == Risk.WRITE:
        return _ask_user(name, args)        # 人工确认（HITL）
    return False, f"高危工具 {name} 已被策略拒绝"


def _ask_user(name, args) -> tuple[bool, str]:
    approver = _approver.get()
    if approver is not None:                # ★ 服务化：交给外部审批器
        return approver(name, args)
    return _console_ask(name, args)


def _console_ask(name, args) -> tuple[bool, str]:
    detail = describe(name, args)
    ans = input(f"Agent 请求执行 {name}（{detail}），是否允许？[y/N] ")
    ok = ans.strip().lower() in ("y", "yes")
    return ok, "用户同意" if ok else "用户拒绝"      # 修掉“拒绝也写同意”
