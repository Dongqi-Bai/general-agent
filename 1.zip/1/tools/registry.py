"""工具注册表：把「函数 + 参数模型 + 风险等级 + 所属技能」绑定成一个条目。

约定：
- 每个工具都必须声明 args_model（pydantic），schema 由它自动生成；
- skill 由技能清单（skill.yaml）在装载时回填，工具里不需要手写；
- risk 决定权限裁决（READ 自动放行，WRITE 走人工确认，DANGER 默认拒绝）；
- untrusted 声明「输出是否来自不可控的数据」（文件内容 / 检索片段 / 外部 server）。
  agent_loop 会把 untrusted 工具的结果包进信任边界后再交给模型（见 tools/trust.py）。

例外：外部工具（第 21 步的 MCP server）没有 pydantic 模型，只有协议给的
JSON Schema，走 register_external() 注册：args_model=None，改用 jsonschema 校验。
"""
from __future__ import annotations

from enum import Enum


class Risk(str, Enum):
    READ = "read"       # 只读，无副作用 → 自动放行
    WRITE = "write"     # 改状态/花钱/对外发消息 → 需人工确认
    DANGER = "danger"   # Shell、删除、转账 → 默认拒绝（或强确认）


TOOL_REGISTRY: dict[str, dict] = {}


def tool(name, description, args_model, risk=Risk.READ, skill=None, untrusted=False):
    """把函数注册为工具，并自动生成 schema。

    untrusted=True 表示输出来自不可控的数据（如 read_file / search_knowledge）：
    调模型前会被包进信任边界，模型只当数据、不当指令。
    """
    def deco(fn):
        TOOL_REGISTRY[name] = {
            "function": fn,
            "args_model": args_model,
            "risk": risk,
            "skill": skill,          # 由技能清单在装载时回填
            "untrusted": bool(untrusted),
            "schema": {
                "type": "function",
                "name": name,
                "description": description,
                "parameters": args_model.model_json_schema(),
            },
        }
        return fn
    return deco


def _clean_parameters(parameters) -> dict:
    """把外部给的 JSON Schema 规整成 OpenAI function.parameters 能接受的形状。"""
    if not isinstance(parameters, dict) or not parameters:
        return {"type": "object", "properties": {}}
    p = dict(parameters)
    p.pop("$schema", None)                  # 有些 server 会带上，去掉更干净
    if "type" not in p:
        p["type"] = "object"
    if p["type"] == "object" and "properties" not in p:
        p["properties"] = {}
    return p


def register_external(name, description, parameters, caller,
                      risk=Risk.WRITE, skill=None, server=None, untrusted=True):
    """注册一个「外部」工具（如 MCP server 暴露的工具）。

    - caller(**args) -> str：本地没有实现，而是一个转发到远端的代理；
    - args_model=None：参数改用 caller 侧给的 JSON Schema 做校验；
    - risk 默认 WRITE：外部工具默认要人工确认，白名单才放行（见 permissions）。
    - untrusted 默认 True：远端返回的内容一律按不可信数据处理（第 22 步）。
    """
    entry = {
        "function": caller,
        "args_model": None,
        "risk": risk,
        "skill": skill,
        "server": server,
        "external": True,
        "untrusted": bool(untrusted),
        "schema": {
            "type": "function",
            "name": name,
            "description": description or "",
            "parameters": _clean_parameters(parameters),
        },
    }
    TOOL_REGISTRY[name] = entry
    return entry
