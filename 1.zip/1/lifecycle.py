"""数据生命周期：清点 / 导出 / 删除 / 存量归属（第 27 步）。

问题：数据散在 6 个存储里（会话文件、记忆 JSONL、runs.db、cost_ledger.db、
auth_tokens.db、traces/），格式各异，而且有些根本不知道"属于谁"。

做法：
- `session_owner()`：会话归属 —— 优先读**文件内的 user**，退回文件名前缀
  `<user>__`。这样**单租户会话**（`<sid>.json`）也能被归属与删除；
- `iter_user_data(user)`：**一套枚举**，导出与删除共用；
- `build_bundle / export_user`：导出（文件按 0600 落盘）；
- `purge_user(user, dry_run)`：删除（默认只预演），逐存储汇报，**单个存储失败不中断其余**；
- `adopt_orphans(user)`：把 `user==""` 的存量数据（升级前写入的）认领给某个用户；
- `cleanup_exports()`：清理过期的导出文件。

凭据不物理删除，只**撤销**（留审计痕迹）。
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import audit
import auth
import costs
import memory.store as memory_store
import reliability
import run_store
from config import Config
from trace_utils import Trace, meta_of

_BIG = 1_000_000


def _cfg(cfg: Config | None) -> Config:
    return cfg or Config()


def _export_ttl() -> float:
    try:
        return max(0.0, float(os.getenv("EXPORT_TTL_S") or 3600))
    except ValueError:
        return 3600.0


# ===================== 归属 =====================

def session_owner(path: str | Path) -> str:
    """会话归属：优先文件内的 user；其次文件名前缀 `<user>__`。"""
    p = Path(path)
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        u = str(d.get("user") or "")
        if u:
            return u
    except (OSError, ValueError):
        pass
    name = p.stem
    return name.split("__", 1)[0] if "__" in name else ""


def session_files(user: str, cfg: Config | None = None):
    """属于某用户的会话文件（含单租户的 `<sid>.json`）。"""
    cfg = _cfg(cfg)
    for p in sorted(cfg.session_dir.glob("*.json")):
        if session_owner(p) == user:
            yield p


def traces_of(user: str):
    """属于某用户的 trace（靠首行 meta 判定）。"""
    for p in sorted(Trace.TRACE_DIR.glob("*.jsonl")):
        meta = meta_of(p)
        if (meta.get("user") or "") == user:
            yield p, meta


# ===================== 清点 =====================

def iter_user_data(user: str, cfg: Config | None = None):
    """枚举某个用户的数据（导出 / 删除 / 清点 共用）。"""
    cfg = _cfg(cfg)
    for p in session_files(user, cfg):
        yield {"store": "session", "ref": p.name, "path": str(p)}
    for m in memory_store.get_store(cfg.memory_path).all(user):
        yield {"store": "memory", "ref": m.id, "text_len": len(m.text)}
    rs = run_store.get_store()
    for r in rs.list(limit=_BIG, user=user):
        yield {"store": "run", "ref": r.run_id, "kind": r.kind, "status": r.status}
    for a in rs.list_approvals(user=user, limit=_BIG):
        yield {"store": "approval", "ref": a.approval_id, "status": a.status}
    for row in costs.rows_of(user):
        yield {"store": "usage", "ref": row.get("run_id", ""),
               "cost": row.get("cost", 0.0)}
    for p, meta in traces_of(user):
        yield {"store": "trace", "ref": meta.get("trace_id") or p.stem,
               "path": str(p)}


def inventory(user: str, cfg: Config | None = None) -> dict:
    counts: dict[str, int] = {}
    for item in iter_user_data(user, cfg):
        counts[item["store"]] = counts.get(item["store"], 0) + 1
    return counts


# ===================== 导出 =====================

def build_bundle(user: str, cfg: Config | None = None,
                 include_traces: bool = False) -> dict:
    cfg = _cfg(cfg)
    bundle: dict = {"user": user, "exported_at": time.time(),
                    "sessions": [], "memories": [], "runs": [],
                    "approvals": [], "usage": costs.rows_of(user), "traces": []}
    for p in session_files(user, cfg):
        try:
            bundle["sessions"].append(json.loads(p.read_text(encoding="utf-8")))
        except (OSError, ValueError):
            continue
    for m in memory_store.get_store(cfg.memory_path).all(user):
        bundle["memories"].append(m.to_dict())
    rs = run_store.get_store()
    bundle["runs"] = [r.to_dict() for r in rs.list(limit=_BIG, user=user)]
    bundle["approvals"] = [a.to_dict() for a in rs.list_approvals(user=user, limit=_BIG)]
    for p, meta in traces_of(user):
        entry = {"trace_id": meta.get("trace_id") or p.stem, "file": p.name}
        if include_traces:
            try:
                entry["content"] = p.read_text(encoding="utf-8")
            except OSError:
                pass
        bundle["traces"].append(entry)
    return bundle


def export_user(user: str, dest_dir: str | Path, cfg: Config | None = None,
                include_traces: bool = False) -> Path:
    """导成 JSON 文件（权限 0600），并记审计。"""
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    bundle = build_bundle(user, cfg, include_traces)
    out = dest / f"export_{user}_{int(time.time())}.json"
    out.write_text(json.dumps(bundle, ensure_ascii=False, indent=2, default=str),
                   encoding="utf-8")
    try:
        os.chmod(out, 0o600)          # 明文导出：至少别让同机其他用户读
    except OSError:
        pass
    audit.log("export", subject=user,
              counts={k: len(v) for k, v in bundle.items() if isinstance(v, list)},
              path=str(out))
    return out


def cleanup_exports(cfg: Config | None = None) -> int:
    """删除超过 EXPORT_TTL_S 的导出文件（默认 1 小时）。"""
    cfg = _cfg(cfg)
    ttl = _export_ttl()
    if ttl <= 0 or not cfg.export_dir.exists():
        return 0
    cutoff = time.time() - ttl
    n = 0
    for p in cfg.export_dir.glob("export_*.json"):
        try:
            if p.stat().st_mtime < cutoff:
                p.unlink()
                n += 1
        except OSError:
            pass
    if n:
        audit.log("export_cleanup", counts={"files": n})
    return n


# ===================== 删除 =====================

def purge_user(user: str, dry_run: bool = True, cfg: Config | None = None,
               actor: str = "") -> dict:
    """删除某个用户的全部数据。dry_run=True 只清点不删（默认）。

    单个存储失败不会中断其余 —— 结果里用 `errors` 如实汇报，可重跑。
    """
    cfg = _cfg(cfg)
    would = inventory(user, cfg)
    if dry_run:
        audit.log("purge_dry_run", actor=actor, subject=user, counts=would)
        return {"dry_run": True, "user": user, "would_delete": would}

    deleted: dict[str, int] = {}
    errors: list[str] = []

    n = 0
    for p in list(session_files(user, cfg)):
        try:
            p.unlink()
            n += 1
        except OSError as e:
            errors.append(f"session {p.name}: {e}")
    deleted["session"] = n

    try:
        deleted["memory"] = memory_store.get_store(cfg.memory_path).purge_user(user)
    except Exception as e:
        deleted["memory"] = 0
        errors.append(f"memory: {e}")

    try:
        got = run_store.get_store().purge_user(user)
        deleted["run"] = int(got.get("runs", 0))
        deleted["approval"] = int(got.get("approvals", 0))
    except Exception as e:
        deleted["run"] = deleted["approval"] = 0
        errors.append(f"runs/approvals: {e}")

    try:
        deleted["usage"] = costs.purge_user(user)
    except Exception as e:
        deleted["usage"] = 0
        errors.append(f"usage: {e}")

    n = 0
    for p, _meta in list(traces_of(user)):
        try:
            p.unlink()
            n += 1
        except OSError as e:
            errors.append(f"trace {p.name}: {e}")
    deleted["trace"] = n

    try:
        deleted["token_revoked"] = auth.store().revoke_user(user)
        auth.reset_cache()             # 本地立即生效（别的实例仍受缓存 TTL 约束）
    except Exception as e:
        deleted["token_revoked"] = 0
        errors.append(f"tokens: {e}")

    try:                               # 可靠性地基：幂等键 / 计划 / 检查点 / 副作用记录
        got = reliability.get_store().purge_user(user)
        deleted["reliability"] = sum(int(v) for v in got.values())
    except Exception as e:
        deleted["reliability"] = 0
        errors.append(f"reliability: {e}")

    audit.log("purge", actor=actor, subject=user, counts=deleted,
              errors=errors or None)
    return {"dry_run": False, "user": user, "deleted": deleted, "errors": errors}


# ===================== 存量归属（迁移） =====================

def adopt_orphans(user: str, cfg: Config | None = None, actor: str = "") -> dict:
    """把 `user==""` 的存量数据认领给某个用户（一次性迁移）。

    升级前的记忆 / 轨迹 / 会话都没有 user 字段，既不会被召回、也不会被谁删掉。
    跑一次这个把它们归到指定用户（比如 "local"）。
    """
    cfg = _cfg(cfg)
    report = {"memory": 0, "trace": 0, "session": 0}

    try:
        report["memory"] = memory_store.get_store(cfg.memory_path).reassign_user("", user)
    except Exception:
        pass

    for p in sorted(Trace.TRACE_DIR.glob("*.jsonl")):
        meta = meta_of(p)
        if meta and (meta.get("user") or "") == "":
            if _write_trace_user(p, meta, user):
                report["trace"] += 1

    for p in sorted(cfg.session_dir.glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if str(d.get("user") or ""):
            continue
        d["user"] = user
        try:
            p.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
            report["session"] += 1
        except OSError:
            pass

    audit.log("adopt_orphans", actor=actor, subject=user, counts=report)
    return report


def _write_trace_user(path: Path, meta: dict, user: str) -> bool:
    """重写一条 trace 的 meta 行，把归属改成 user。"""
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError:
        return False
    if not lines:
        return False
    meta = dict(meta)
    meta["user"] = user
    lines[0] = json.dumps(meta, ensure_ascii=False, default=str)
    try:
        Path(path).write_text("\n".join(lines), encoding="utf-8")
        return True
    except OSError:
        return False
