"""Trace：结构化运行日志（第 6 步）；第 27 步加了「归属 + 脱敏」。

- **归属**：每条 trace 的**首行**写一条 meta（trace_id / user / created_at）。
  之前只有 trace_id，既无法按用户删除/导出，也说不清数据属于谁。
- **脱敏/截断**：写入前对 input / output / 工具结果做递归截断，
  避免把整份对话原文与超长工具输出永久留在磁盘上。
  设 `TRACE_REDACT=0` 关闭；`TRACE_MAX_CHARS` 控制单字段上限（默认 4000）。

保留策略（多久清）不在这里做，交给 `retention.sweep()`。
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
import json
import os
from pathlib import Path
import re
import time
import uuid

import costs


def redact_enabled() -> bool:
    return (os.getenv("TRACE_REDACT") or "1").strip().lower() not in (
        "0", "off", "false", "no")


def redact_limit() -> int:
    try:
        return max(64, int(os.getenv("TRACE_MAX_CHARS") or 4000))
    except ValueError:
        return 4000


def mask_enabled() -> bool:
    return (os.getenv("TRACE_MASK_PII") or "1").strip().lower() not in (
        "0", "off", "false", "no")


# 常见敏感串：邮箱 / 手机号 / 身份证 / 银行卡 / API Key
_PII = [
    (re.compile(r"sk-[A-Za-z0-9_\-]{8,}"), "[API_KEY]"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "[EMAIL]"),
    (re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)"), "[PHONE]"),
    (re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)"), "[ID_CARD]"),
    (re.compile(r"(?<!\d)(?:\d[ -]?){13,19}(?!\d)"), "[CARD]"),
]


def mask_pii(text: str) -> str:
    """把常见 PII 替换成占位符 —— 这才是"脱敏"，截断只是省空间。"""
    for rx, tag in _PII:
        text = rx.sub(tag, text)
    return text


def redact(obj, limit: int | None = None):
    """递归截断字符串；保留结构，便于事后阅读。"""
    limit = limit or redact_limit()
    if isinstance(obj, str):
        if mask_enabled():
            obj = mask_pii(obj)
        return obj if len(obj) <= limit else f"{obj[:limit]}…（已截断，原长 {len(obj)}）"
    if isinstance(obj, dict):
        return {k: redact(v, limit) for k, v in obj.items()}
    if isinstance(obj, list):
        return [redact(v, limit) for v in obj]
    return obj


@dataclass
class Trace:

    _trace_logs: list[dict] = field(default_factory=list)
    TRACE_DIR = Path(__file__).resolve().parent / "traces"
    trace_id: str = field(default_factory=str)
    user: str = ""                      # 第 27 步：归属用户（"" = 单租户）

    def gen_trace_id(self):
        self.trace_id = uuid.uuid4().hex[:12]
        self._trace_logs.clear()

    def error_logs(self, step, err):
        self._trace_logs.append(
            {
                "type": "error",
                "trace_id": self.trace_id,
                "step": step,
                "error": err,
            }
        )

    def insert_event(self, type_: str, step: int, payload: dict):
        self._trace_logs.append(
            {"type": type_, "trace_id": self.trace_id, "step": step, **payload}
        )

    def insert_llm_call(self, response, conv, step, t0):
        usage = response.usage.model_dump()
        payload = {
            "type": "llm_call",
            "trace_id": self.trace_id,
            "response_id": response.id,
            "step": step,
            "input": deepcopy(conv.items),
            "output": response.model_dump(),
            "usage": usage,
            "cost": round(costs.cost_of(getattr(response, "model", ""), usage), 6),
            "latency_ms": round((time.perf_counter() - t0) * 1000, 1),
        }
        if redact_enabled():
            payload = redact(payload)
        self._trace_logs.append(payload)

    def insert_tool_call(self, item, result, step, err, t1):
        self._trace_logs.append(
            {
                "type": "tool_call",
                "trace_id": self.trace_id,
                "step": step,
                "name": item.name,
                "arguments": redact(item.arguments) if redact_enabled() else item.arguments,
                "result": redact(result) if redact_enabled() else result,
                "err": err,
                "latency_ms": round((time.perf_counter() - t1) * 1000, 1),
            }
        )

    def save(self):
        self.TRACE_DIR.mkdir(exist_ok=True, parents=True)
        meta = {"type": "meta", "trace_id": self.trace_id, "user": self.user,
                "created_at": time.time()}
        body = "\n".join(
            json.dumps(e, ensure_ascii=False, default=str)
            for e in [meta, *self._trace_logs]
        )
        (self.TRACE_DIR / f"{self.trace_id}.jsonl").write_text(body, encoding="utf-8")


def meta_of(path: Path) -> dict:
    """读一条 trace 的 meta（首行）；用于按用户枚举 / 清理。"""
    try:
        with Path(path).open("r", encoding="utf-8") as f:
            for _ in range(3):                    # meta 一定在最前面
                line = f.readline()
                if not line:
                    break
                try:
                    entry = json.loads(line)
                except ValueError:
                    continue
                if entry.get("type") == "meta":
                    return entry
    except OSError:
        return {}
    return {}
