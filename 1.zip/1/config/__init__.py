from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv
import os

PROJECT_ROOT = Path(__file__).resolve().parent.parent   # 指向 1/

load_dotenv()

def _get_int(key: str, default: int) -> int:
    return int(os.getenv(key, default))

def _get_float(key: str, default: float) -> float:
    return float(os.getenv(key, default))

def _get_bool(key: str, default: bool) -> bool:
    raw = (os.getenv(key) or "").strip().lower()
    if not raw:
        return default
    return raw in ("1", "true", "yes", "on")

def _get_path(key: str, default: Path) -> Path:
    """取路径：相对路径一律相对 1/ 解析。"""
    raw = os.getenv(key)
    p = Path(raw) if raw else default
    if not p.is_absolute():
        p = PROJECT_ROOT / p
    return p.resolve()

def _get_skills() -> list[str] | None:
    """SKILLS=files,weather 指定装配哪些技能；留空或 all/* → 全部；none → 一个都不装。"""
    raw = (os.getenv("SKILLS") or "").strip()
    if not raw or raw.lower() in ("all", "*"):
        return None
    if raw.lower() == "none":
        return []
    return [s.strip() for s in raw.split(",") if s.strip()]

@dataclass
class Config:
    api_key: str = field(default_factory=lambda: os.getenv("DEEPSEEK_API_KEY", ""))
    base_url: str = field(default_factory=lambda: os.getenv("DEEPSEEK_BASE_URL", ""))
    model: str = field(default_factory=lambda: os.getenv("DEEPSEEK_MODEL", ""))
    request_timeout: float = field(default_factory=lambda: _get_float("REQUEST_TIMEOUT", 60.0))
    max_retries: int = field(default_factory=lambda: _get_int("MAX_RETRIES", 2))
    token_budget: int = field(default_factory=lambda: _get_int("TOKEN_BUDGET", 200000))
    time_budget_s: float = field(default_factory=lambda: _get_float("TIME_BUDGET_S", 120))
    max_tool_output_chars: int = field(default_factory=lambda: _get_int("MAX_TOOL_OUTPUT_CHARS", 2000))
    max_history_items: int = field(default_factory=lambda: _get_int("MAX_HISTORY_ITEMS", 20))
    max_steps: int = field(default_factory=lambda: _get_int("MAX_STEPS", 3))
    instructions: str = "你是个AI助手，优先使用工具获取数据"
    skills: list[str] | None = field(default_factory=_get_skills)   # None=全部技能
    
    session_dir: Path = field(default_factory=lambda: PROJECT_ROOT / "sessions")
    
    #上下文压缩
    keep_recent_turns: int = field(default_factory=lambda: _get_int("KEEP_RECENT_TURNS", 3))
    summarize_threshold: int = field(default_factory=lambda: _get_int("SUMMARIZE_THRESHOLD", 30))
    summary_input_chars: int = field(default_factory=lambda: _get_int("SUMMARY_INPUT_CHARS", 12000))

    # 服务化：HITL 审批等待上限（秒），超过则按拒绝处理
    approval_timeout_s: float = field(
        default_factory=lambda: _get_float("APPROVAL_TIMEOUT_S", 300.0)
    )

    # 检索与长期记忆（第 20 步）
    knowledge_root: Path = field(
        default_factory=lambda: _get_path("KNOWLEDGE_ROOT", PROJECT_ROOT)
    )
    chunk_chars: int = field(default_factory=lambda: _get_int("CHUNK_CHARS", 800))
    chunk_overlap: int = field(default_factory=lambda: _get_int("CHUNK_OVERLAP", 3))
    memory_path: Path = field(
        default_factory=lambda: _get_path("MEMORY_PATH", PROJECT_ROOT / "memory" / "long_term.jsonl")
    )
    auto_recall: bool = field(default_factory=lambda: _get_bool("AUTO_RECALL", True))
    auto_capture: bool = field(default_factory=lambda: _get_bool("AUTO_CAPTURE", False))
    recall_top_k: int = field(default_factory=lambda: _get_int("RECALL_TOP_K", 3))

    # 语义检索（第 20f 步）：本地 embedding（sentence-transformers + BGE）。
    # retrieval 包自己读同名环境变量以保持"脱离 Agent 也能用"，这里只是给
    # Agent 侧一个类型化视图，两处默认值保持一致。
    embedding_enabled: bool = field(
        default_factory=lambda: _get_bool("EMBEDDING_ENABLED", True)
    )
    embedding_model: str = field(
        default_factory=lambda: os.getenv("EMBEDDING_MODEL", "BAAI/bge-small-zh-v1.5")
    )
    embedding_batch_size: int = field(
        default_factory=lambda: _get_int("EMBEDDING_BATCH_SIZE", 32)
    )
    embedding_min_score: float = field(
        default_factory=lambda: _get_float("EMBEDDING_MIN_SCORE", 0.5)
    )
    hybrid_alpha: float = field(
        default_factory=lambda: _get_float("HYBRID_ALPHA", 0.5)
    )
    hybrid_pool: int = field(default_factory=lambda: _get_int("HYBRID_POOL", 20))

    # 外部工具协议（第 21 步）：MCP。mcp_bridge 自己读同名环境变量以保持
    # "脱离 Agent 也能用"，这里只是给 Agent 侧一个类型化视图。
    mcp_enabled: bool = field(default_factory=lambda: _get_bool("MCP_ENABLED", False))
    mcp_config_path: Path = field(
        default_factory=lambda: _get_path("MCP_CONFIG", PROJECT_ROOT / "mcp_servers.yaml")
    )
    mcp_call_timeout_s: float = field(
        default_factory=lambda: _get_float("MCP_CALL_TIMEOUT", 60.0)
    )
    mcp_connect_timeout_s: float = field(
        default_factory=lambda: _get_float("MCP_CONNECT_TIMEOUT", 30.0)
    )

    # 内容信任边界（第 22 步）：把不可信工具输出包裹进带 nonce 的边界，
    # 并对疑似提示注入话术留痕告警。设 SECURITY_GUARD=0 可关闭。
    security_guard: bool = field(
        default_factory=lambda: _get_bool("SECURITY_GUARD", True)
    )

    # 鉴权与多租户（第 23 步）：AGENT_USERS="alice:key1,bob:key2"。
    # 留空 = 关闭鉴权（本地开发），所有请求归属用户 local。
    # 真正的解析与校验在 auth.py（同读这个环境变量，保持可独立测试）。
    agent_users: str = field(default_factory=lambda: os.getenv("AGENT_USERS", ""))
    # 动态凭据（CLI 签发）：库只存哈希，支持过期/撤销；缓存 TTL 秒级生效。
    auth_tokens_path: Path = field(
        default_factory=lambda: _get_path("AUTH_TOKENS_PATH", PROJECT_ROOT / "auth_tokens.db")
    )
    auth_cache_ttl_s: float = field(
        default_factory=lambda: _get_float("AUTH_CACHE_TTL", 30.0)
    )
    # 成本核算与配额（第 24 步）：MODEL_PRICES="model:输入价:输出价"（USD/1M tokens）；
    # USER_QUOTA_USD=0 表示不限。真正的计算在 costs.py（同读这些环境变量）。
    model_prices: str = field(default_factory=lambda: os.getenv("MODEL_PRICES", ""))
    user_quota_usd: float = field(
        default_factory=lambda: _get_float("USER_QUOTA_USD", 0.0)
    )
    cost_ledger_path: Path = field(
        default_factory=lambda: _get_path("COST_LEDGER_PATH", PROJECT_ROOT / "cost_ledger.db")
    )
    # 跨进程会话锁 + 审批外置（第 28 步）
    session_lock_dir: Path = field(
        default_factory=lambda: _get_path("SESSION_LOCK_DIR", PROJECT_ROOT / ".locks")
    )
    session_lock_timeout_s: float = field(
        default_factory=lambda: _get_float("SESSION_LOCK_TIMEOUT", 30.0)
    )
    approval_poll_s: float = field(
        default_factory=lambda: _get_float("APPROVAL_POLL_S", 0.25)
    )
    # 并发治理（第 25 步）：LLM 调用闸门 + 运行级准入。
    # 真正的闸门在 llm/limiter.py（同读这些环境变量）。
    llm_max_concurrency: int = field(
        default_factory=lambda: _get_int("LLM_MAX_CONCURRENCY", 4)
    )
    llm_queue_timeout_s: float = field(
        default_factory=lambda: _get_float("LLM_QUEUE_TIMEOUT", 30.0)
    )
    llm_rpm: int = field(default_factory=lambda: _get_int("LLM_RPM", 0))
    # 运行级准入：同时运行的 run 数上限；0 = 不限（超出时新请求快速 503）
    max_concurrent_runs: int = field(
        default_factory=lambda: _get_int("MAX_CONCURRENT_RUNS", 8)
    )
    llm_tpm: int = field(default_factory=lambda: _get_int("LLM_TPM", 0))
    # 限流后端：local（进程内）| redis（多实例共享 RPM/TPM）；需要 REDIS_URL
    limiter_backend: str = field(
        default_factory=lambda: (os.getenv("LIMITER_BACKEND") or "local")
    )
    redis_url: str = field(default_factory=lambda: os.getenv("REDIS_URL", ""))
    # 数据生命周期与隐私（第 27 步）
    export_dir: Path = field(
        default_factory=lambda: _get_path("EXPORT_DIR", PROJECT_ROOT / "exports")
    )
    # 定时清理：>0 时在服务启动后按该间隔（秒）跑 retention.sweep；0 = 只手动触发
    retention_sweep_interval_s: float = field(
        default_factory=lambda: _get_float("RETENTION_SWEEP_INTERVAL_S", 0.0)
    )
    trace_redact: bool = field(default_factory=lambda: _get_bool("TRACE_REDACT", True))
    trace_max_chars: int = field(default_factory=lambda: _get_int("TRACE_MAX_CHARS", 4000))
    memory_max_per_user: int = field(
        default_factory=lambda: _get_int("MEMORY_MAX_PER_USER", 500)
    )
    memory_dedup_similarity: float = field(
        default_factory=lambda: _get_float("MEMORY_DEDUP_SIMILARITY", 0.85)
    )
    audit_log_path: Path = field(
        default_factory=lambda: _get_path("AUDIT_LOG_PATH", PROJECT_ROOT / "audit.jsonl")
    )
    export_ttl_s: float = field(default_factory=lambda: _get_float("EXPORT_TTL_S", 3600.0))
    retention_exempt_users: str = field(
        default_factory=lambda: os.getenv("RETENTION_EXEMPT_USERS", "")
    )
    trace_mask_pii: bool = field(default_factory=lambda: _get_bool("TRACE_MASK_PII", True))
    audit_max_bytes: int = field(
        default_factory=lambda: _get_int("AUDIT_MAX_BYTES", 5_000_000)
    )
    audit_keep: int = field(default_factory=lambda: _get_int("AUDIT_KEEP", 3))
    embedding_allow_download: bool = field(
        default_factory=lambda: _get_bool("EMBEDDING_ALLOW_DOWNLOAD", False)
    )

    def __post_init__(self):
        if not self.api_key:
            raise RuntimeError("缺少 api_key，请检查 .env 或环境变量")
