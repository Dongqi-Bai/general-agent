"""审计日志（第 27 步）：记录「谁、什么时候、对谁的数据、做了什么」。

原则：**只记动作与计数，绝不记录被删 / 被导出的内容本身** ——
否则审计日志本身就成了新的隐私泄露面。
"""
from __future__ import annotations

import json
import os
import threading
import time
from pathlib import Path

_DEFAULT = Path(__file__).resolve().parent / "audit.jsonl"
_lock = threading.Lock()


def _path() -> Path:
    raw = os.getenv("AUDIT_LOG_PATH")
    p = Path(raw) if raw else _DEFAULT
    return p if p.is_absolute() else (Path(__file__).resolve().parent / p)


def _max_bytes() -> int:
    try:
        return max(0, int(os.getenv("AUDIT_MAX_BYTES") or 5_000_000))
    except ValueError:
        return 5_000_000


def _keep() -> int:
    try:
        return max(0, int(os.getenv("AUDIT_KEEP") or 3))
    except ValueError:
        return 3


def _rotate(p: Path) -> None:
    """按大小轮转：audit.jsonl → audit.jsonl.1 → .2 …，最多留 keep 个。"""
    limit, keep = _max_bytes(), _keep()
    if limit <= 0 or keep <= 0:
        return
    try:
        if not p.exists() or p.stat().st_size < limit:
            return
    except OSError:
        return
    for i in range(keep, 0, -1):
        src = p if i == 1 else p.with_suffix(p.suffix + f".{i - 1}")
        dst = p.with_suffix(p.suffix + f".{i}")
        try:
            if src.exists():
                os.replace(src, dst)
        except OSError:
            pass


def log(action: str, *, actor: str = "", subject: str = "", **meta) -> None:
    """追加一条审计记录；失败只忽略，绝不影响主流程。"""
    entry = {"ts": time.time(), "action": action, "actor": actor,
             "subject": subject, **meta}
    try:
        with _lock:
            p = _path()
            p.parent.mkdir(parents=True, exist_ok=True)
            _rotate(p)
            with p.open("a", encoding="utf-8", newline="\n") as f:
                f.write(json.dumps(entry, ensure_ascii=False, default=str) + "\n")
    except Exception:
        pass


def tail(n: int = 50) -> list[dict]:
    p = _path()
    if not p.exists():
        return []
    try:
        lines = p.read_text(encoding="utf-8").splitlines()[-max(1, int(n)):]
    except OSError:
        return []
    out = []
    for line in lines:
        try:
            out.append(json.loads(line))
        except ValueError:
            continue
    return out
