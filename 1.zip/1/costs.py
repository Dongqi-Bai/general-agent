"""第 24 步 · 成本核算与配额：定价 → 记账 → 上限。

问题：前面记了 tokens，但 token ≠ 钱。跑了几十条 trace，没人能回答
「这个月花了多少、谁花的、哪个 run 最贵」，也没有「用完就停」的闸门。

做法：
- **定价**：`MODEL_PRICES="model:输入价:输出价,..."`（USD / 1M tokens）。
  没配的模型成本记 0，并在 stderr 提醒一次 —— 宁可显示 0，也不编造价格。
- **记账**：SQLite 账本，一行一次运行：user / run_id / kind / model / tokens / cost。
  多实例指向同一个文件即可共享账目。
- **配额**：`USER_QUOTA_USD`（0 = 不限）。超限后拒绝启动新 run。

边界（如实说明）：只统计主循环的模型调用；摘要压缩、记忆提炼、
planner / critic / aggregate 这些「辅助调用」暂未计入（它们同样烧 token）。
"""
from __future__ import annotations

import os
import sqlite3
import sys
import threading
import time
from pathlib import Path

_DEFAULT_LEDGER = Path(__file__).resolve().parent / "cost_ledger.db"
_MISSING_WARNED: set[str] = set()


def _ledger_path() -> Path:
    raw = os.getenv("COST_LEDGER_PATH")
    p = Path(raw) if raw else _DEFAULT_LEDGER
    return p if p.is_absolute() else (Path(__file__).resolve().parent / p)


def _prices() -> dict[str, tuple[float, float]]:
    """解析 MODEL_PRICES="model:in:out,..."，单位 USD / 1M tokens。"""
    table: dict[str, tuple[float, float]] = {}
    for item in (os.getenv("MODEL_PRICES") or "").split(","):
        item = item.strip()
        if not item:
            continue
        parts = [p.strip() for p in item.split(":")]
        if len(parts) != 3:
            raise ValueError(f"MODEL_PRICES 条目应为 model:输入价:输出价，收到：{item!r}")
        model, pin, pout = parts
        table[model] = (float(pin), float(pout))
    return table


def price_of(model: str) -> tuple[float, float]:
    return _prices().get(model, (0.0, 0.0))


def cost_of(model: str, usage: dict | None) -> float:
    """按 usage 算这次调用的钱（USD）。价格未配置 → 0，并提醒一次。"""
    usage = usage or {}
    inp = int(usage.get("input_tokens") or 0)
    out = int(usage.get("output_tokens") or 0)
    pin, pout = price_of(model)
    if pin == 0.0 and pout == 0.0 and model not in _MISSING_WARNED:
        _MISSING_WARNED.add(model)
        print(f"[warn] 未配置模型价格（{model}），成本记 0；"
              f'设 MODEL_PRICES="{model}:输入价:输出价" 可计价', file=sys.stderr)
    return inp / 1_000_000 * pin + out / 1_000_000 * pout


class Ledger:
    """SQLite 账本：一行一次运行。"""

    def __init__(self, path: str | Path | None = None) -> None:
        self.path = str(path or _ledger_path())
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._exec(
            """CREATE TABLE IF NOT EXISTS usage (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                ts             REAL,
                user           TEXT,
                run_id         TEXT,
                kind           TEXT,
                model          TEXT,
                input_tokens   INTEGER,
                output_tokens  INTEGER,
                total_tokens   INTEGER,
                cost           REAL
            )"""
        )

    def _exec(self, sql: str, params: tuple = ()) -> list[tuple]:
        with self._lock:
            conn = sqlite3.connect(self.path, timeout=5)
            try:
                cur = conn.execute(sql, params)
                rows = cur.fetchall()
                conn.commit()
                return rows
            finally:
                conn.close()

    def record(self, user: str, run_id: str, kind: str, model: str,
               usage: dict | None, cost: float) -> None:
        u = usage or {}
        self._exec(
            "INSERT INTO usage (ts,user,run_id,kind,model,"
            "input_tokens,output_tokens,total_tokens,cost) VALUES (?,?,?,?,?,?,?,?,?)",
            (time.time(), user, run_id, kind, model,
             int(u.get("input_tokens") or 0), int(u.get("output_tokens") or 0),
             int(u.get("total_tokens") or 0), float(cost or 0.0)),
        )

    def spent(self, user: str | None = None, since: float | None = None) -> float:
        sql, params = "SELECT COALESCE(SUM(cost),0) FROM usage WHERE 1=1", []
        if user is not None:
            sql += " AND user=?"
            params.append(user)
        if since is not None:
            sql += " AND ts>=?"
            params.append(since)
        rows = self._exec(sql, tuple(params))
        return float(rows[0][0]) if rows else 0.0

    def summary(self, limit: int = 20) -> list[dict]:
        """按用户汇总：用于「谁花得多」。"""
        rows = self._exec(
            "SELECT user, COUNT(*), COALESCE(SUM(total_tokens),0), COALESCE(SUM(cost),0)"
            " FROM usage GROUP BY user ORDER BY SUM(cost) DESC LIMIT ?", (int(limit),)
        )
        return [{"user": r[0], "runs": r[1], "tokens": r[2], "cost": r[3]} for r in rows]

    # ---- 生命周期（第 27 步）----
    def rows_of(self, user: str, limit: int = 100000) -> list[dict]:
        rows = self._exec(
            "SELECT ts,run_id,kind,model,input_tokens,output_tokens,total_tokens,cost"
            " FROM usage WHERE user=? ORDER BY ts LIMIT ?", (user, int(limit)))
        return [{"ts": r[0], "run_id": r[1], "kind": r[2], "model": r[3],
                 "input_tokens": r[4], "output_tokens": r[5],
                 "total_tokens": r[6], "cost": r[7]} for r in rows]

    def purge_user(self, user: str) -> int:
        rows = self._exec("SELECT COUNT(*) FROM usage WHERE user=?", (user,))
        n = int(rows[0][0]) if rows else 0
        if n:
            self._exec("DELETE FROM usage WHERE user=?", (user,))
        return n

    def purge_older_than(self, cutoff: float) -> int:
        rows = self._exec("SELECT COUNT(*) FROM usage WHERE ts<?", (cutoff,))
        n = int(rows[0][0]) if rows else 0
        if n:
            self._exec("DELETE FROM usage WHERE ts<?", (cutoff,))
        return n

    def count_older_than(self, cutoff: float) -> int:
        rows = self._exec("SELECT COUNT(*) FROM usage WHERE ts<?", (cutoff,))
        return int(rows[0][0]) if rows else 0

    def purge_user_older_than(self, user: str, cutoff: float) -> int:
        rows = self._exec("SELECT COUNT(*) FROM usage WHERE user=? AND ts<?",
                          (user, cutoff))
        n = int(rows[0][0]) if rows else 0
        if n:
            self._exec("DELETE FROM usage WHERE user=? AND ts<?", (user, cutoff))
        return n

    def users(self) -> list[str]:
        rows = self._exec("SELECT DISTINCT user FROM usage")
        return sorted({str(r[0]) for r in rows if r[0] is not None})


_ledger: Ledger | None = None
_ledger_lock = threading.Lock()


def _get_ledger() -> Ledger:
    global _ledger
    if _ledger is None:
        with _ledger_lock:
            if _ledger is None:
                _ledger = Ledger()
    return _ledger


def record(user: str, run_id: str, kind: str, model: str,
           usage: dict | None, cost: float) -> None:
    """记账；失败只告警，绝不影响主流程。"""
    try:
        _get_ledger().record(user, run_id, kind, model, usage, cost)
    except Exception as e:
        print(f"[warn] 成本记账失败：{e}", file=sys.stderr)


def spent(user: str | None = None, since: float | None = None) -> float:
    if not _ledger_path().exists():          # 没账本 = 没花过钱，别被动建库
        return 0.0
    try:
        return _get_ledger().spent(user, since)
    except Exception:
        return 0.0


def quota_usd() -> float:
    try:
        return max(0.0, float(os.getenv("USER_QUOTA_USD", "0") or 0))
    except ValueError:
        return 0.0


def check_quota(user: str) -> tuple[bool, float, float]:
    """返回 (是否未超限, 已花, 上限)；上限 0 表示不限。"""
    quota = quota_usd()
    used = spent(user)
    if quota <= 0:
        return True, used, 0.0
    return used < quota, used, quota


def summary(limit: int = 20) -> list[dict]:
    if not _ledger_path().exists():
        return []
    return _get_ledger().summary(limit)


def rows_of(user: str) -> list[dict]:
    if not _ledger_path().exists():
        return []
    return _get_ledger().rows_of(user)


def purge_user(user: str) -> int:
    if not _ledger_path().exists():
        return 0
    return _get_ledger().purge_user(user)


def purge_older_than(cutoff: float) -> int:
    if not _ledger_path().exists():
        return 0
    return _get_ledger().purge_older_than(cutoff)


def count_older_than(cutoff: float) -> int:
    if not _ledger_path().exists():
        return 0
    return _get_ledger().count_older_than(cutoff)


def purge_user_older_than(user: str, cutoff: float) -> int:
    if not _ledger_path().exists():
        return 0
    return _get_ledger().purge_user_older_than(user, cutoff)


def users() -> list[str]:
    if not _ledger_path().exists():
        return []
    return _get_ledger().users()
