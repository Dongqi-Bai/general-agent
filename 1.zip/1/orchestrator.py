"""v3 · Orchestrator：角色化 worker + Critic 校验 + Supervisor 失败重规划。

在 v2（按拓扑层并行）基础上加了三件事：
  1) 角色化 worker —— 每个子任务按 role 拿到不同的 instructions 与工具子集；
  2) Critic —— 对最终答复做结构化评审（passed / issues / missing）；
  3) Supervisor —— 评审不通过时，只针对"未完成部分"重新规划并再跑，受 MAX_REPLANS 约束。

角色过滤、并发输出、HITL 串行化都在运行时打补丁完成，不改动 agent_loop / tools 等已有源码。
"""
from __future__ import annotations

import io
import json
import os
import re
import sys
import threading
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field

from pydantic import BaseModel, Field

import tools.registry as tool_registry
import auth
from agent_loop import run_agent
from config import Config
from conversation.conversation import Conversation
from data.dataclass import AgentResult, RunContext, Status
from llm.LLM import llm
from planner import Plan, SubTask, make_plan
from skills.loader import load_all
from tools.permissions import _console_ask, reset_approver, set_approver
from tools.registry import Risk
from trace_utils import Trace
import reliability
from reliability import CheckpointRecord, PlanRecord

MAX_SUBTASKS = int(os.getenv("MAX_SUBTASKS", "6"))
MAX_PARALLEL = int(os.getenv("MAX_PARALLEL", "3"))
MAX_REPLANS = int(os.getenv("MAX_REPLANS", "1"))
PLAN_TIME_BUDGET_S = float(os.getenv("PLAN_TIME_BUDGET_S", "0"))   # 0 = 不限


# ===================== 角色 =====================

@dataclass
class Role:
    name: str
    desc: str
    instructions: str
    tools: set[str] | None = None          # 工具级过滤（按 risk 推导）；None = 不限制
    skills: list[str] | None = None        # 技能级过滤；None = 全部技能


_ROLES: dict[str, Role] | None = None


def _tools_with_risk(*risks) -> set[str]:
    """角色工具集由 TOOL_REGISTRY 的 risk 推导，而不是手写名单。"""
    return {n for n, e in tool_registry.TOOL_REGISTRY.items() if e.get("risk") in risks}


def _ensure_roles() -> dict[str, Role]:
    global _ROLES
    if _ROLES is None:
        load_all()                        # 先装载技能，risk 推导与技能过滤才有效
        _ROLES = {
            "researcher": Role(
                "researcher", "只读的信息获取与核对，不改任何状态",
                "你是研究员，只做只读的信息获取与核对，不修改任何状态。需要数据时调用工具，"
                "然后给出结论；无法确证就明说，不要编造。",
                _tools_with_risk(Risk.READ),
                ["weather", "math", "files"],
            ),
            "operator": Role(
                "operator", "有副作用的落地动作（写文件等）",
                "你是操作员，负责有副作用的落地动作。只执行子任务要求的那一次动作，"
                "执行前确认路径与内容无误，完成后回报结果。",
                _tools_with_risk(Risk.WRITE, Risk.DANGER),
                ["files"],
            ),
            "general": Role(
                "general", "通用执行者，不限定工具",
                "你是通用执行者。只完成交给你的这一个子任务，必要时调用工具；"
                "完成后用一段话给出结论和关键结果。",
                None,
                None,
            ),
        }
    return _ROLES


def _roles_text() -> str:
    return "\n".join(f"- {r.name}: {r.desc}" for r in _ensure_roles().values())


# ===================== HITL 串行化 =====================
# 角色 / 工具集已改为通过 run_agent(ctx=...) 显式传参，不再 monkeypatch 全局函数；
# 这里只保留"并发子任务同时要人工审批时，终端提示不互相穿插"这一点。

_HITL_LOCK = threading.Lock()


def _serialized_approver(name, args):
    """并发子任务走终端审批时，保证同一时刻只问一个人。"""
    with _HITL_LOCK:
        return _console_ask(name, args)


def _console_emit(event: dict) -> None:
    """默认事件出口：把编排事件渲染到终端，保持原有 CLI 观感。

    只处理"给人看"的事件；subtask_done / finished / error 交给上层决定怎么呈现。
    """
    t = event.get("type")
    if t == "plan":
        subs = event.get("subtasks", [])
        print(f"\n📋 第 {event['round']} 轮计划（{len(subs)} 个子任务，{event.get('layers', '?')} 层）：")
        for s in subs:
            dep = f"   ← 依赖 {s['depends_on']}" if s.get("depends_on") else ""
            print(f"  - [{s.get('role')}] {s.get('id')}: {s.get('goal')}{dep}")
    elif t == "layer_start":
        print(f"\n=== 第 {event['layer']} 层：{len(event.get('subtasks', []))} 个子任务，"
              f"并发 {event.get('concurrency')} ===")
    elif t == "subtask_text":
        sys.stdout.write(event.get("text") or "")
        sys.stdout.flush()
    elif t == "review_start":
        print(f"\n🧪 第 {event['round']} 轮评审…")
    elif t == "review":
        print(f"   评审：{'通过' if event.get('passed') else '未通过'} {event.get('issues') or ''}")
    elif t == "replan":
        print(f"\n🔁 评审未通过，进入第 {event['round']} 轮：针对未完成部分重规划")
    elif t == "notice":
        print(f"   {event.get('message', '')}")


# ===================== 数据结构 / 小工具 =====================

@dataclass
class PlanResult:
    final_text: str
    goal: str = ""
    subtask_results: dict[str, AgentResult] = field(default_factory=dict)
    total_tokens: int = 0
    total_cost: float = 0.0
    plan_trace_id: str = ""
    rounds: int = 0
    review: dict | None = None
    plan: Plan | None = None          # 初始拆解方案（第 0 轮），供评测断言用
    status: str = "completed"         # completed | cancelled
    resumed: bool = False             # 第 28 步：本次是否从检查点续跑


@dataclass
class _LayerOut:
    st: SubTask
    res: AgentResult
    trace_id: str
    tokens: int
    stream_text: str
    role: str


def _tokens(res: AgentResult) -> int:
    return int(res.usage.get("total_tokens", 0) or 0) if isinstance(res.usage, dict) else 0


def _cost(res: AgentResult) -> float:
    """单个子任务的花费（来自 agent_loop 写进 usage 的累计 cost）。"""
    return float(res.usage.get("cost", 0.0) or 0.0) if isinstance(res.usage, dict) else 0.0


def _status_value(s) -> str:
    return s.value if hasattr(s, "value") else str(s)


def _status_of(value: str) -> Status:
    try:
        return Status(value)
    except ValueError:
        return Status.FAILED


def _result_from_ckpt(ck) -> AgentResult:
    """把检查点还原成 AgentResult（续跑时重建已完成子任务）。"""
    return AgentResult(final_text=ck.final_text or "", status=_status_of(ck.status),
                       steps=0, tool_calls=[],
                       usage={"total_tokens": int(ck.tokens or 0),
                              "cost": float(ck.cost or 0.0)},
                       error=ck.error)


def _handoff(st: SubTask, results: dict[str, AgentResult]) -> str:
    parts = []
    for d in st.depends_on:
        r = results.get(d)
        if r is not None:
            parts.append(f"- {d}: {r.final_text[:500]}")
    return "\n".join(parts)


def _done_digest(results: dict[str, AgentResult]) -> str:
    rows = []
    for k, v in results.items():
        row = (v.final_text or v.error or "").strip().replace("\n", " ")
        rows.append(f"- {k}: {row[:300]}")
    return "\n".join(rows) or "（无）"


def _layers(order: list[SubTask]) -> list[list[SubTask]]:
    """按依赖深度分层：第 k 层的依赖全部落在更早的层里。"""
    depth: dict[str, int] = {}
    for st in order:                            # order 已是拓扑序，依赖必先出现
        depth[st.id] = 0 if not st.depends_on else max(depth[d] for d in st.depends_on) + 1
    groups: dict[int, list[SubTask]] = defaultdict(list)
    for st in order:
        groups[depth[st.id]].append(st)
    return [groups[k] for k in sorted(groups)]


def _trim(plan: Plan) -> None:
    if len(plan.subtasks) > MAX_SUBTASKS:
        keep = {s.id for s in plan.subtasks[:MAX_SUBTASKS]}
        plan.subtasks = plan.subtasks[:MAX_SUBTASKS]
        for s in plan.subtasks:
            s.depends_on = [d for d in s.depends_on if d in keep]


# ===================== 执行一个子任务 =====================

def _worker_sid(user: str | None, raw: str) -> str:
    """子任务会话也按用户隔离；CLI（不传 user）保持原样，向后兼容。"""
    if not user:
        return raw
    try:
        return auth.session_key(user, raw)
    except auth.AuthError:
        return raw


def _run_one(st: SubTask, goal: str, carry: str, extra: str,
             cfg: Config, tag: str, approver=None, cancel=None,
             user: str | None = None, run_id: str | None = None,
             step_key: str | None = None) -> _LayerOut:
    roles = _ensure_roles()
    role = roles.get(st.role) or roles["general"]

    buf = io.StringIO()

    def _emit(event: dict) -> None:
        # 每个子任务的流式文本进各自缓冲，回主线程再按序输出，避免互相穿插
        if event.get("type") == "text_delta":
            buf.write(event["text"])

    worker = Conversation(
        instructions=role.instructions,
        session_id=f"{tag}-{st.id}",          # 独立会话，上下文隔离
        skills=role.skills,                   # 角色装载哪些技能
        user=user or "",                      # 第 27 步：子任务会话也归属用户
    )
    brief = (f"总目标：{goal}\n\n你的子任务（角色：{role.name}）：{st.goal}\n\n"
             f"前置结果：\n{carry or '（无）'}")
    if extra:
        brief += f"\n\n全部已完成工作：\n{extra}"
    worker.add_user(brief)

    worker.session_id = _worker_sid(user, worker.session_id)   # ★ 子任务会话按用户隔离

    sub_trace = Trace(user=user or "")
    token = set_approver(approver or _serialized_approver)   # 线程内注入审批器
    try:
        res = run_agent(                           # ★ 角色 / 工具集显式传入
            worker, sub_trace, cfg, emit=_emit,
            ctx=RunContext(role_name=role.name, tool_filter=role.tools, user=user,
                           run_id=run_id, step_key=step_key),
            cancel=cancel,
        )
    finally:
        reset_approver(token)
    return _LayerOut(st, res, sub_trace.trace_id, _tokens(res), buf.getvalue(), role.name)


# ===================== 按层并行执行整个计划 =====================

def _execute_layers(plan: Plan, goal: str, cfg: Config, plan_trace: Trace,
                    results: dict[str, AgentResult], spent: int,
                    tag: str, round_no: int, t_start: float,
                    extra: str = "", emit=None, approver=None, cancel=None,
                    user: str | None = None, run_id: str | None = None) -> int:
    emit = emit or _console_emit
    order = plan.topo_order()
    layers = _layers(order)

    emit({"type": "plan", "round": round_no + 1, "goal": goal, "layers": len(layers),
          "subtasks": [{"id": s.id, "role": s.role, "goal": s.goal,
                        "depends_on": list(s.depends_on)} for s in order]})

    for li, layer in enumerate(layers):
        if cancel is not None and cancel.is_set():       # ★ 逐层检查取消
            for st in layer:
                if st.id not in results:
                    results[st.id] = AgentResult(
                        final_text="", status=Status.CANCELLED, steps=0,
                        tool_calls=[], usage={}, error="计划被取消")
                    emit({"type": "subtask_done", "round": round_no + 1, "id": st.id,
                          "role": st.role, "status": Status.CANCELLED.value,
                          "tokens": 0, "error": "计划被取消"})
            continue

        runnable: list[SubTask] = []
        for st in layer:
            failed = [d for d in st.depends_on
                      if results.get(d) is None or results[d].status != Status.COMPLETED]
            if failed:
                results[st.id] = AgentResult(
                    final_text="", status=Status.FAILED, steps=0, tool_calls=[],
                    usage={}, error=f"依赖未完成，已跳过：{failed}")
                plan_trace.insert_event("subtask_skip", li,
                                        {"id": st.id, "deps": failed, "round": round_no})
                emit({"type": "subtask_done", "round": round_no + 1, "id": st.id,
                      "role": st.role, "status": Status.FAILED.value, "tokens": 0,
                      "error": results[st.id].error})
                continue
            if spent >= cfg.token_budget:
                results[st.id] = AgentResult(
                    final_text="", status=Status.BUDGET_EXCEEDED, steps=0, tool_calls=[],
                    usage={}, error=f"计划级 token 预算耗尽（{spent}）")
                plan_trace.insert_event("subtask_budget", li,
                                        {"id": st.id, "spent": spent, "round": round_no})
                emit({"type": "subtask_done", "round": round_no + 1, "id": st.id,
                      "role": st.role, "status": Status.BUDGET_EXCEEDED.value,
                      "tokens": 0, "error": results[st.id].error})
                continue
            if run_id:                       # ★ 续跑：已完成的子任务直接跳过
                ck = reliability.get_store().get_checkpoint(run_id, round_no, st.id)
                if ck is not None and ck.status == Status.COMPLETED.value:
                    if st.id not in results:    # 续跑重建时已计过，别重复累加
                        spent += int(ck.tokens or 0)
                    results[st.id] = _result_from_ckpt(ck)
                    plan_trace.insert_event("subtask_resumed", li, {
                        "id": st.id, "round": round_no,
                        "tokens": ck.tokens, "trace_id": ck.trace_id})
                    emit({"type": "subtask_resumed", "round": round_no + 1,
                          "id": st.id, "role": st.role,
                          "status": ck.status, "tokens": int(ck.tokens or 0)})
                    continue
            runnable.append(st)

        if not runnable:
            continue

        if PLAN_TIME_BUDGET_S and (time.monotonic() - t_start) > PLAN_TIME_BUDGET_S:
            for st in runnable:
                results[st.id] = AgentResult(
                    final_text="", status=Status.TIMEOUT, steps=0, tool_calls=[],
                    usage={}, error="计划整体超时")
                plan_trace.insert_event("subtask_timeout", li, {"id": st.id, "round": round_no})
                emit({"type": "subtask_done", "round": round_no + 1, "id": st.id,
                      "role": st.role, "status": Status.TIMEOUT.value, "tokens": 0,
                      "error": results[st.id].error})
            continue

        n = min(MAX_PARALLEL, len(runnable))
        emit({"type": "layer_start", "round": round_no + 1, "layer": li + 1,
              "total_layers": len(layers), "concurrency": n,
              "subtasks": [{"id": s.id, "role": s.role, "goal": s.goal} for s in runnable]})

        if n <= 1:
            outs = [_run_one(runnable[0], goal, _handoff(runnable[0], results),
                             extra, cfg, tag, approver, cancel, user,
                             run_id, f"r{round_no}-{runnable[0].id}")]
        else:
            with ThreadPoolExecutor(max_workers=n) as ex:
                futs = {
                    ex.submit(_run_one, st, goal, _handoff(st, results),
                              extra, cfg, tag, approver, cancel, user,
                              run_id, f"r{round_no}-{st.id}"): st
                    for st in runnable
                }
                outs = [f.result() for f in as_completed(futs)]
        by_id = {o.st.id: o for o in outs}

        # 主线程统一回填：按序 emit 每个子任务的文本与状态，输出稳定可读
        for st in runnable:
            out = by_id[st.id]
            results[st.id] = out.res
            spent += out.tokens
            emit({"type": "subtask_text", "round": round_no + 1, "id": st.id,
                  "role": out.role, "text": out.stream_text})
            plan_trace.insert_event("subtask_done", li, {
                "id": st.id, "goal": st.goal, "role": out.role, "round": round_no,
                "trace_id": out.trace_id,
                "status": out.res.status.value if hasattr(out.res.status, "value") else str(out.res.status),
                "tokens": out.tokens, "error": out.res.error,
            })
            if run_id:                   # ★ 子任务一结束就落检查点
                reliability.get_store().save_checkpoint(CheckpointRecord(
                    run_id=run_id, round=round_no, subtask_id=st.id,
                    user=user or "", status=_status_value(out.res.status),
                    final_text=out.res.final_text or "", tokens=int(out.tokens or 0),
                    cost=_cost(out.res), trace_id=out.trace_id,
                    error=out.res.error))
            emit({"type": "subtask_done", "round": round_no + 1, "id": st.id,
                  "role": out.role,
                  "status": out.res.status.value if hasattr(out.res.status, "value") else str(out.res.status),
                  "tokens": out.tokens, "error": out.res.error,
                  "trace_id": out.trace_id})
    return spent


# ===================== Critic（结构化评审） =====================

class _ReviewArgs(BaseModel):
    passed: bool = Field(description="最终答复是否真正、完整地达成了总目标")
    issues: list[str] = Field(default_factory=list, description="存在的问题")
    missing: list[str] = Field(default_factory=list, description="尚未完成的具体内容")


_REVIEW_TOOL = {
    "type": "function",
    "name": "submit_review",
    "description": "提交评审结论",
    "parameters": _ReviewArgs.model_json_schema(),
}

_CRITIC_INSTRUCTIONS = """你是严格的评审员。你会收到：总目标、各子任务的结论、以及据此写出的最终答复。
判断最终答复是否真正、完整地达成了总目标；宁可严格，不要放过含糊、缺失或未完成的部分。
只通过 submit_review 提交结论。"""


def _extract_json(text: str) -> dict:
    m = re.search(r"\{.*\}", text or "", re.S)
    if not m:
        raise ValueError("Critic 输出里没有找到 JSON")
    return json.loads(m.group(0))


def critic(goal: str, final_text: str,
           results: dict[str, AgentResult], cfg: Config) -> _ReviewArgs:
    rows = []
    for sid, r in results.items():
        st = r.status.value if hasattr(r.status, "value") else str(r.status)
        rows.append(f"- {sid}: {st} | {(r.final_text or r.error or '')[:300]}")
    content = (f"总目标：{goal}\n\n子任务结论：\n" + ("\n".join(rows) or "（无）")
               + f"\n\n最终答复：\n{final_text}")
    base = dict(model=cfg.model, instructions=_CRITIC_INSTRUCTIONS,
                input=[{"role": "user", "content": content}], tools=[_REVIEW_TOOL])
    try:
        resp = llm(**base, tool_choice={"type": "function", "name": "submit_review"})
    except Exception:
        resp = llm(**base)
    for it in (getattr(resp, "output", None) or []):
        if getattr(it, "type", None) == "function_call" and getattr(it, "name", None) == "submit_review":
            return _ReviewArgs.model_validate_json(it.arguments)
    return _ReviewArgs.model_validate(_extract_json(resp.output_text))


# ===================== Supervisor（重规划） =====================

def _replan(goal: str, results: dict[str, AgentResult],
            review: _ReviewArgs, cfg: Config, round_no: int) -> Plan:
    context = (f"这是第 {round_no} 次重规划。已完成的工作：\n{_done_digest(results)}\n\n"
               f"评审指出的问题：{review.issues}\n"
               f"仍未完成的内容：{review.missing}\n\n"
               f"请只规划【尚未完成】的工作，不要重复已完成的部分。")
    plan = make_plan(goal, cfg, roles_text=_roles_text(), context=context)

    prefix = f"r{round_no}-"
    mapping = {s.id: prefix + s.id for s in plan.subtasks}
    for s in plan.subtasks:
        s.id = mapping[s.id]
        # 只保留新计划内部的依赖；对已完成工作的依赖改由"已完成工作"摘要承载
        s.depends_on = [mapping[d] for d in s.depends_on if d in mapping]
    plan.topo_order()
    return plan


# ===================== 汇总 =====================

def aggregate(goal: str, results: dict[str, AgentResult], cfg: Config) -> str:
    blocks = []
    for sid, r in results.items():
        if r.status == Status.COMPLETED and r.final_text:
            blocks.append(f"### {sid}\n{r.final_text}")
        else:
            blocks.append(f"### {sid}（未完成：{r.error or r.status}）")
    digest = "\n\n".join(blocks) or "（无子任务结果）"
    resp = llm(
        model=cfg.model,
        instructions=("综合各子任务结论，针对总目标给出简洁、完整、可直接交付的最终答复。"
                      "不要罗列过程，也不要提到子任务这件事。若有未完成的部分，如实说明缺口。"),
        input=[{"role": "user", "content": f"总目标：{goal}\n\n子任务结论：\n{digest}"}],
    )
    return resp.output_text


# ===================== 主流程 =====================

def run_plan(goal: str, cfg: Config, *, max_replans: int | None = None,
             emit=None, approver=None, cancel=None,
             user: str | None = None, run_id: str | None = None,
             resume: bool = False) -> PlanResult:
    """跑一次"规划 → 分层执行 → 评审 → 重规划"。

    emit:     事件出口，默认打终端；服务化时传 SSE 出口即可消费全过程。
    approver: 人工审批器，默认终端 input()；服务化时传 HTTP 审批器。
    cancel:   取消令牌；被取消时停止编排并以 status="cancelled" 结束。
    """
    emit = emit or _console_emit
    _ensure_roles()
    plan_trace = Trace(user=user or "")
    plan_trace.gen_trace_id()
    plan_trace.insert_event("plan", 0, {"goal": goal, "round": 0})

    store = reliability.get_store()
    results: dict[str, AgentResult] = {}
    spent = 0
    start_round = 0
    resumed = False

    if resume and run_id:            # ★ 第 28 步：用「落盘的旧计划 + 检查点」续跑
        rec = store.get_plan(run_id)
        if rec is None:
            raise ValueError(f"没有可续跑的检查点：run_id={run_id}")
        goal = rec.goal or goal
        plan = Plan.from_dict(rec.plan)
        start_round = max(0, int(rec.round_no) + 1)
        for c in store.list_checkpoints(run_id):
            results[c.subtask_id] = _result_from_ckpt(c)
            spent += int(c.tokens or 0)
        resumed = True
        plan_trace.insert_event("resume", 0, {"run_id": run_id,
                                              "from_round": start_round,
                                              "restored": len(results)})
    else:
        try:
            plan = make_plan(goal, cfg, roles_text=_roles_text())
        except Exception as e:
            plan_trace.error_logs(0, f"规划失败：{e}")
            plan_trace.save()
            raise
    _trim(plan)
    initial_plan = plan              # 第 0 轮拆解（重规划不会覆盖它）
    if run_id and not resumed:
        store.save_plan(PlanRecord(run_id=run_id, user=user or "", goal=goal,
                                   plan=plan.to_dict(), round_no=-1))

    limit = MAX_REPLANS if max_replans is None else max_replans
    t_start = time.monotonic()
    final_text = ""
    review: _ReviewArgs | None = None
    rounds = 0

    for round_no in range(start_round, limit + 1):
        rounds = round_no + 1
        tag = f"{plan_trace.trace_id}-r{round_no}"
        extra = _done_digest(results) if round_no > 0 else ""

        spent = _execute_layers(plan, goal, cfg, plan_trace, results,
                                spent, tag, round_no, t_start, extra,
                                emit=emit, approver=approver, cancel=cancel,
                                user=user, run_id=run_id)

        if cancel is not None and cancel.is_set():        # ★ 取消：跳过评审直接收尾
            final_text = final_text or "（已取消，未生成最终答复）"
            emit({"type": "notice", "round": rounds,
                  "message": "已收到取消请求，停止编排。"})
            break

        emit({"type": "review_start", "round": rounds})
        final_text = aggregate(goal, results, cfg)
        review = critic(goal, final_text, results, cfg)
        plan_trace.insert_event("review", round_no, {
            "passed": review.passed, "issues": review.issues,
            "missing": review.missing, "round": round_no,
        })
        emit({"type": "review", "round": rounds, "passed": review.passed,
              "issues": review.issues, "missing": review.missing})

        if run_id:                       # 本轮完整跑完 → 记录进度（续跑从下一轮开始）
            store.set_round(run_id, round_no)

        if review.passed or round_no == limit:
            break

        over_budget = spent >= cfg.token_budget
        over_time = bool(PLAN_TIME_BUDGET_S) and (time.monotonic() - t_start) > PLAN_TIME_BUDGET_S
        if over_budget or over_time:
            emit({"type": "notice", "round": rounds,
                  "message": "预算/时间已耗尽，停止重规划。"})
            break

        emit({"type": "replan", "round": rounds + 1})
        plan = _replan(goal, results, review, cfg, round_no + 1)
        _trim(plan)
        if run_id:
            store.save_plan(PlanRecord(run_id=run_id, user=user or "", goal=goal,
                                       plan=plan.to_dict(), round_no=round_no))

    plan_trace.insert_event("aggregate", 0, {"tokens_total": spent, "rounds": rounds})
    plan_trace.save()

    cancelled = cancel is not None and cancel.is_set()
    result = PlanResult(final_text=final_text, goal=goal, subtask_results=results,
                        total_tokens=spent, plan_trace_id=plan_trace.trace_id,
                        total_cost=sum(_cost(r) for r in results.values()),
                        rounds=rounds, review=review.model_dump() if review else None,
                        plan=initial_plan, resumed=resumed,
                        status="cancelled" if cancelled else "completed")
    emit({"type": "finished",
          "status": result.status, "final_text": final_text,
          "total_tokens": spent, "rounds": rounds,
          "plan_trace_id": plan_trace.trace_id, "review": result.review})
    return result


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

    cfg = Config()
    goal = os.getenv(
        "PLAN_GOAL",
        "帮我查一下天津今天的天气，再算一下 123*456，最后把这两个结果一起写进 1/plan_result.txt",
    )
    result = run_plan(goal, cfg)

    print("\n" + "=" * 50)
    print("最终答复：\n" + result.final_text)
    print(f"\n轮次：{result.rounds} | 总 tokens≈{result.total_tokens} | plan trace：{result.plan_trace_id}")
    if result.review:
        print(f"评审：passed={result.review.get('passed')} | issues={result.review.get('issues')}")
    print("子任务状态：")
    for k, v in result.subtask_results.items():
        st = v.status.value if hasattr(v.status, "value") else str(v.status)
        print(f"  - {k}: {st}（tokens≈{_tokens(v)}）{v.error or ''}")
