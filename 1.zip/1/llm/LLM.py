import random
import time

from openai import (
    OpenAI, APIConnectionError, APITimeoutError,
    RateLimitError, APIStatusError,
)
from dotenv import load_dotenv
import os
from config import Config
from llm import limiter

cfg = Config()

#客户端
client = OpenAI(
    api_key=cfg.api_key,
    base_url=cfg.base_url,
    timeout=cfg.request_timeout,
    max_retries=0
)

RETRYABLE_STATUS = {408, 409, 429, 500, 502, 503, 504}

def is_retryable(e: Exception)->bool:
    if isinstance(e, (APIConnectionError,APITimeoutError, RateLimitError)):
        return True
    if isinstance(e, APIStatusError):
        return e.status_code in RETRYABLE_STATUS
    return False

def _retry_after(e: Exception) -> float | None:
    """读 429/503 响应里的 Retry-After（秒）。"""
    headers = getattr(getattr(e, "response", None), "headers", None)
    if not headers:
        return None
    raw = headers.get("retry-after") or headers.get("Retry-After")
    if not raw:
        return None
    try:
        return max(0.0, float(raw))
    except (TypeError, ValueError):
        return None                       # HTTP-date 形式暂不解析


def _backoff(attempt: int, e: Exception | None = None) -> float:
    """退避：优先遵循服务端的 Retry-After，否则抖动退避（封顶 8 秒）。"""
    if e is not None:
        suggested = _retry_after(e)
        if suggested is not None:
            return min(suggested, 60.0)
    return min(2 ** attempt * 0.5, 8) * (0.5 + random.random() / 2)


def llm(**kwargs):
    """过闸门发一次模型请求（第 25 步 · L1）。

    非流式：调用结束即还票。
    流式：把票绑在返回的流上，**消费完 / 关闭时才还** —— 否则限不住流式并发。
    """
    streaming = bool(kwargs.get("stream"))
    timeout = limiter.queue_timeout()
    estimate = limiter.estimate_tokens(kwargs)
    for attempt in range(cfg.max_retries + 1):
        gate = limiter.get_gate()
        ticket = gate.acquire(timeout, estimate)
        if ticket is None:
            raise limiter.QueueTimeout(f"LLM 闸门排队超时（>{timeout:g}s）")
        try:
            result = client.responses.create(**kwargs)
        except Exception as e:
            ticket.release()                      # 失败先还票，再决定是否重试
            if not is_retryable(e) or attempt == cfg.max_retries:
                raise
            time.sleep(_backoff(attempt, e))
            continue
        if streaming:
            return gate.wrap_stream(result, ticket)   # 票随流一起释放 + 校正 TPM
        ticket.reconcile(getattr(result, "usage", None))
        ticket.release()
        return result
            
def _text_of(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for b in content:
            if isinstance(b, dict):
                parts.append(b.get("text") or b.get("output_text") or "")
            else:
                parts.append(str(b))
        return "".join(p for p in parts if p)
    return str(content)


def _render_transcript(items: list[dict], max_chars: int) -> str:
    """把待压缩的 items 渲染成可读文本，供摘要模型阅读。"""
    lines = []
    for it in items:
        t = it.get("type")
        if t == "function_call":
            lines.append(f"[工具调用] {it.get('name')}({it.get('arguments')})")
        elif t == "function_call_output":
            out = str(it.get("output", ""))
            if len(out) > 500:
                out = out[:500] + "…（截断）"
            lines.append(f"[工具结果] {out}")
        elif it.get("role") == "user":
            lines.append(f"[用户] {_text_of(it.get('content'))}")
        elif it.get("role") == "assistant":
            lines.append(f"[助手] {_text_of(it.get('content'))}")
        else:
            lines.append(f"[{t or it.get('role')}] {_text_of(it)}")
    text = "\n".join(lines)
    if len(text) > max_chars:                              # 兜底，别把摘要调用本身撑爆
        text = "…（更早内容已省略）\n" + text[-max_chars:]
    return text


_SUMMARY_PROMPT = """你是一个对话记忆压缩器。请把【已有摘要】和【新增对话片段】合并成一份更新后的记忆摘要。

要求：
- 只保留事实，不要复述过程，不要加评论。
- 必须保留：用户的原始目标与约束、已确认的结论、关键数据（数字/路径/ID）、已完成事项、未决问题与下一步。
- 用简洁的中文要点输出，尽量控制在 400 字以内。

【已有摘要】
{prev}

【新增对话片段】
{transcript}

【更新后的记忆摘要】"""


def summarize(prev_summary: str, items: list[dict]) -> str:
    """把一批旧历史压成一段摘要；失败时退回上一版摘要，绝不因此中断主流程。"""
    transcript = _render_transcript(items, cfg.summary_input_chars)
    prompt = _SUMMARY_PROMPT.format(prev=prev_summary or "（无）", transcript=transcript)
    try:
        resp = llm(
            model=cfg.model,
            input=[{"role": "user", "content": prompt}],
        )
        text = (resp.output_text or "").strip()
        return text or prev_summary
    except Exception:
        return prev_summary


_MEMORY_PROMPT = """你是长期记忆提炼器。从下面这段对话里，只提炼【值得跨会话长期记住】的事实。

判断标准（满足其一才记）：
- 用户的稳定偏好或习惯（例：偏好用 conda 管理环境）；
- 项目的长期约定（例：沙箱根目录是某个固定路径）；
- 已确认的重要结论或决定。

不要记：一次性的闲聊、试错过程、临时中间结果、没有依据的推测。
没有值得记的内容时，只输出一个字：无

输出格式：每行一条，以 "- " 开头，一句话，不要编号，不要解释。

【对话片段】
{transcript}

【提炼结果】"""


def extract_memories(items: list[dict]) -> list[str]:
    """从对话里提炼值得长期记住的事实。

    失败/无内容一律返回空列表 —— 记忆沉淀是"锦上添花"，
    绝不允许它影响主流程，更不允许它把运行搞崩。
    """
    if not items:
        return []
    transcript = _render_transcript(items, cfg.summary_input_chars)
    prompt = _MEMORY_PROMPT.format(transcript=transcript)
    try:
        resp = llm(model=cfg.model, input=[{"role": "user", "content": prompt}])
        text = (resp.output_text or "").strip()
    except Exception:
        return []
    if not text or text == "无":
        return []

    facts: list[str] = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line == "无":
            continue
        if line[0] in "-•*":
            fact = line.lstrip("-•* ").strip()
            if fact and fact != "无":
                facts.append(fact)
    return facts[:5]                      # 一轮最多沉淀 5 条，防爆
