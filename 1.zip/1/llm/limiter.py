"""LLM 闸门（第 25 步）：所有模型调用先拿票再发，拿不到就排队。

问题：并行层 + 多会话 + 429 重试会相乘，把 provider 的并发/速率打爆。
做法：在唯一的咽喉 `llm()` 上放一把闸门，三个维度一起管：

- **并发**：信号量，限制同时在飞的请求数；
- **RPM**：60 秒滑动窗口，限制每分钟请求数；
- **TPM**：60 秒 token 预算窗。发之前按输入**估算预留**，拿到真实 `usage` 后
  **校正**；`LLM_TPM=0` 时只观测不拦截。

**流式的坑**：`stream=True` 时 `create()` 立刻返回迭代器，真正的请求时长
取决于后面「迭代消费」的过程。若在 `create()` 返回时就还票，等于没限流。
所以票绑在流上，消费完 / 关闭时才归还 —— 见 `_StreamWithRelease`。

配置（全从环境变量读，保持 limiter 可脱离 Agent 独立使用）：
    LLM_MAX_CONCURRENCY=4     # 同时在飞上限；<=0 不限
    LLM_RPM=0                 # 每分钟请求上限；0 不限
    LLM_TPM=0                 # 每分钟 token 上限；0 = 只观测不拦截
    LLM_QUEUE_TIMEOUT=30      # 排队多久拿不到票就放弃（秒）
"""
from __future__ import annotations

import collections
import contextlib
import json
import os
import sys
import threading
import time


class QueueTimeout(TimeoutError):
    """排队等票超时。"""


def _int_env(name: str, default: int) -> int:
    try:
        return int(os.getenv(name) or default)
    except ValueError:
        return default


def _float_env(name: str, default: float) -> float:
    try:
        return float(os.getenv(name) or default)
    except ValueError:
        return default


def max_concurrency() -> int:
    return _int_env("LLM_MAX_CONCURRENCY", 4)


def rpm_limit() -> int:
    return _int_env("LLM_RPM", 0)


def tpm_limit() -> int:
    return _int_env("LLM_TPM", 0)


def queue_timeout() -> float:
    return _float_env("LLM_QUEUE_TIMEOUT", 30.0)


def estimate_tokens(kwargs: dict) -> int:
    """粗略估算这次请求的输入 token（字符数 / 3，中英混排的经验值）。

    只是"预留额度"，拿到真实 usage 后会校正，所以不需要很准。
    """
    try:
        blob = json.dumps(kwargs.get("input"), ensure_ascii=False, default=str)
    except Exception:
        blob = str(kwargs.get("input"))
    blob += str(kwargs.get("instructions") or "")
    try:
        blob += json.dumps(kwargs.get("tools") or [], ensure_ascii=False, default=str)
    except Exception:
        blob += str(kwargs.get("tools") or "")
    return max(0, len(blob) // 3)


class RateWindow:
    """请求数滑动窗口：`period` 秒内最多放行 `limit` 次。limit<=0 表示不限。"""

    def __init__(self, limit: int, period: float = 60.0):
        self.limit = max(0, int(limit))
        self.period = float(period)
        self._times: collections.deque[float] = collections.deque()
        self._lock = threading.Lock()
        self.waits = 0

    def _prune(self, now: float) -> None:
        while self._times and now - self._times[0] > self.period:
            self._times.popleft()

    def wait(self, timeout: float) -> bool:
        if self.limit <= 0:
            return True
        deadline = time.monotonic() + timeout
        waited = False
        while True:
            with self._lock:
                now = time.monotonic()
                self._prune(now)
                if len(self._times) < self.limit:
                    self._times.append(now)
                    if waited:
                        self.waits += 1
                    return True
                sleep_for = self.period - (now - self._times[0])
                waited = True
            if time.monotonic() + sleep_for > deadline:
                return False
            time.sleep(min(max(sleep_for, 0.01), 0.5))

    def stats(self) -> dict:
        with self._lock:
            self._prune(time.monotonic())
            return {"limit": self.limit, "used": len(self._times),
                    "period_s": self.period, "waits": self.waits}


class TokenWindow:
    """token 预算滑动窗。limit<=0 时只观测（记录真实用量），不拦截。"""

    def __init__(self, limit: int, period: float = 60.0):
        self.limit = max(0, int(limit))
        self.period = float(period)
        self._entries: collections.deque[list] = collections.deque()   # [ts, tokens]
        self._lock = threading.Lock()
        self.waits = 0
        self.observed_total = 0     # 累计真实 token（供观测）

    def _prune(self, now: float) -> None:
        while self._entries and now - self._entries[0][0] > self.period:
            self._entries.popleft()

    def _sum(self) -> int:
        return sum(int(e[1]) for e in self._entries)

    def reserve(self, need: int, timeout: float):
        """预留 need 个 token。放不下就等到窗口滑动；超时返回 None。"""
        if self.limit <= 0:
            return [-1.0, 0]        # 不限额：给个占位 entry，校正只累计观测
        need = max(0, int(need))
        deadline = time.monotonic() + timeout
        waited = False
        while True:
            with self._lock:
                now = time.monotonic()
                self._prune(now)
                if self._sum() + need <= self.limit:
                    entry = [now, need]
                    self._entries.append(entry)
                    if waited:
                        self.waits += 1
                    return entry
                sleep_for = self.period - (now - self._entries[0][0])
                waited = True
            if time.monotonic() + sleep_for > deadline:
                return None
            time.sleep(min(max(sleep_for, 0.01), 0.5))

    def reconcile(self, entry, actual: int) -> None:
        """把预留值换成真实用量（流式在 response.completed 校正）。"""
        actual = max(0, int(actual or 0))
        with self._lock:
            self.observed_total += actual
            if entry is not None and entry[0] >= 0:
                entry[1] = actual

    def stats(self) -> dict:
        with self._lock:
            self._prune(time.monotonic())
            return {"limit": self.limit, "used": self._sum(),
                    "period_s": self.period, "waits": self.waits,
                    "observed_total": self.observed_total}


def _usage_tokens(usage) -> int:
    if usage is None:
        return 0
    if hasattr(usage, "model_dump"):
        usage = usage.model_dump()
    total = int(usage.get("input_tokens") or 0) + int(usage.get("output_tokens") or 0)
    return total or int(usage.get("total_tokens") or 0)


class Ticket:
    """一次调用拿到的票：负责归还并发槽位、校正 token 用量。"""

    __slots__ = ("_gate", "_entry", "_released")

    def __init__(self, gate: "Gate", token_entry):
        self._gate = gate
        self._entry = token_entry
        self._released = False

    def reconcile(self, usage) -> None:
        self._gate._tpm.reconcile(self._entry, _usage_tokens(usage))

    def release(self) -> None:
        if not self._released:
            self._released = True
            self._gate._release_slot()


class _StreamWithRelease:
    """包住流式响应：迭代结束 / 关闭 / 被回收时还票，并在 completed 时校正 TPM。"""

    def __init__(self, inner, ticket: Ticket):
        self._inner = inner
        self._ticket = ticket
        self._closed = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            event = next(self._inner)
        except StopIteration:
            self._close()
            raise
        except BaseException:
            self._close()
            raise
        if getattr(event, "type", None) == "response.completed":
            self._ticket.reconcile(getattr(getattr(event, "response", None), "usage", None))
        return event

    def close(self):
        try:
            close = getattr(self._inner, "close", None)
            if callable(close):
                close()
        finally:
            self._close()

    def _close(self):
        if not self._closed:
            self._closed = True
            self._ticket.release()

    def __del__(self):
        self._close()

    def __getattr__(self, item):
        return getattr(self._inner, item)


# ===================== 多实例：把票放到 Redis =====================

_BACKEND_WARNED = False


def backend() -> str:
    return (os.getenv("LIMITER_BACKEND") or "local").strip().lower()


def _redis_client():
    """按 REDIS_URL 建客户端；不可用返回 None（只提醒一次，绝不因此崩服务）。"""
    global _BACKEND_WARNED
    url = os.getenv("REDIS_URL")
    if not url:
        if not _BACKEND_WARNED:
            _BACKEND_WARNED = True
            print("[warn] LIMITER_BACKEND=redis 但未设 REDIS_URL，退回进程内闸门", file=sys.stderr)
        return None
    try:
        import redis
    except Exception as e:
        if not _BACKEND_WARNED:
            _BACKEND_WARNED = True
            print(f"[warn] 未安装 redis 客户端（{e}），退回进程内闸门", file=sys.stderr)
        return None
    try:
        client = redis.Redis.from_url(url, socket_timeout=2, socket_connect_timeout=2)
        client.ping()
        return client
    except Exception as e:
        if not _BACKEND_WARNED:
            _BACKEND_WARNED = True
            print(f"[warn] 连不上 Redis（{e}），退回进程内闸门", file=sys.stderr)
        return None


class RedisRateWindow:
    """多实例共享的「每分钟请求数」固定窗口（INCR + EXPIRE）。"""

    def __init__(self, client, prefix: str, limit: int, period: float = 60.0):
        self._c = client
        self.prefix = prefix
        self.limit = max(0, int(limit))
        self.period = float(period)
        self.waits = 0

    def _key(self, now: float | None = None) -> str:
        return f"{self.prefix}:{int((now if now is not None else time.time()) // self.period)}"

    def wait(self, timeout: float) -> bool:
        if self.limit <= 0:
            return True
        deadline = time.monotonic() + timeout
        waited = False
        while True:
            key = self._key()
            try:
                cur = int(self._c.get(key) or 0)
            except Exception:
                return True                       # Redis 抖动：放行，别把服务卡死
            if cur + 1 <= self.limit:
                try:
                    self._c.incrby(key, 1)
                    self._c.expire(key, int(self.period) + 1)
                except Exception:
                    return True
                if waited:
                    self.waits += 1
                return True
            sleep_for = self.period - (time.time() % self.period)
            waited = True
            if time.monotonic() + sleep_for > deadline:
                return False
            time.sleep(min(max(sleep_for, 0.01), 0.5))

    def stats(self) -> dict:
        try:
            used = int(self._c.get(self._key()) or 0)
        except Exception:
            used = 0
        return {"limit": self.limit, "used": used, "period_s": self.period,
                "waits": self.waits, "backend": "redis"}


class RedisTokenWindow:
    """多实例共享的 token 预算窗：预留（INCRBY）→ 校正（补差额）。"""

    def __init__(self, client, prefix: str, limit: int, period: float = 60.0):
        self._c = client
        self.prefix = prefix
        self.limit = max(0, int(limit))
        self.period = float(period)
        self.waits = 0
        self.observed_total = 0

    def _key(self, now: float | None = None) -> str:
        return f"{self.prefix}:{int((now if now is not None else time.time()) // self.period)}"

    def reserve(self, need: int, timeout: float):
        if self.limit <= 0:
            return ("", 0)                        # 只观测
        need = max(0, int(need))
        deadline = time.monotonic() + timeout
        waited = False
        while True:
            key = self._key()
            try:
                cur = int(self._c.get(key) or 0)
            except Exception:
                return (key, need)
            if cur + need <= self.limit:
                try:
                    self._c.incrby(key, need)
                    self._c.expire(key, int(self.period) + 1)
                except Exception:
                    pass
                if waited:
                    self.waits += 1
                return (key, need)
            sleep_for = self.period - (time.time() % self.period)
            waited = True
            if time.monotonic() + sleep_for > deadline:
                return None
            time.sleep(min(max(sleep_for, 0.01), 0.5))

    def reconcile(self, entry, actual: int) -> None:
        actual = max(0, int(actual or 0))
        self.observed_total += actual
        if not entry:
            return
        key, need = entry
        if not key:
            return
        try:
            self._c.incrby(key, actual - int(need))    # 多退少补
        except Exception:
            pass

    def stats(self) -> dict:
        try:
            used = int(self._c.get(self._key()) or 0)
        except Exception:
            used = 0
        return {"limit": self.limit, "used": used, "period_s": self.period,
                "waits": self.waits, "observed_total": self.observed_total,
                "backend": "redis"}


class Gate:
    """全局闸门：并发 + RPM + TPM。"""

    def __init__(self, max_concurrency: int = 4, rate_window=None, token_window=None,
                 backend_name: str = "local"):
        self.max_concurrency = max(0, int(max_concurrency))
        self._sem = (threading.BoundedSemaphore(self.max_concurrency)
                     if self.max_concurrency > 0 else None)
        self._rpm = rate_window if rate_window is not None else RateWindow(0)
        self._tpm = token_window if token_window is not None else TokenWindow(0)
        self._backend_name = backend_name
        self._lock = threading.Lock()
        self.in_flight = 0
        self.timeouts = 0

    def acquire(self, timeout: float | None = None, estimate: int = 0):
        """拿票。返回 Ticket；返回 None 表示排队超时。"""
        budget = queue_timeout() if timeout is None else timeout
        deadline = time.monotonic() + budget
        if not self._rpm.wait(budget):                       # 先过请求速率
            with self._lock:
                self.timeouts += 1
            return None
        entry = self._tpm.reserve(estimate, max(0.0, deadline - time.monotonic()))
        if entry is None:                                    # 再过 token 预算
            with self._lock:
                self.timeouts += 1
            return None
        if self._sem is None:
            with self._lock:
                self.in_flight += 1
            return Ticket(self, entry)
        ok = self._sem.acquire(timeout=max(0.0, deadline - time.monotonic()))
        if not ok:
            with self._lock:
                self.timeouts += 1
            return None
        with self._lock:
            self.in_flight += 1
        return Ticket(self, entry)

    def _release_slot(self) -> None:
        with self._lock:
            if self.in_flight > 0:
                self.in_flight -= 1
        if self._sem is not None:
            try:
                self._sem.release()
            except ValueError:
                pass

    @contextlib.contextmanager
    def slot(self, timeout: float | None = None, estimate: int = 0):
        """非流式调用的便捷写法；流式请用 acquire + wrap_stream。"""
        ticket = self.acquire(timeout, estimate)
        if ticket is None:
            raise QueueTimeout("LLM 闸门排队超时")
        try:
            yield ticket
        finally:
            ticket.release()

    def wrap_stream(self, stream, ticket: Ticket):
        return _StreamWithRelease(stream, ticket)

    def stats(self) -> dict:
        with self._lock:
            stats = {
                "in_flight": self.in_flight,
                "max_concurrency": self.max_concurrency,
                "queue_timeouts": self.timeouts,
            }
        stats["throttled"] = self._rpm.waits
        stats["backend"] = self._backend_name
        stats["rpm"] = self._rpm.stats()
        stats["tpm"] = self._tpm.stats()
        return stats


_gates: dict[str, Gate] = {}
_gates_lock = threading.Lock()


def _build_gate() -> Gate:
    """按 LIMITER_BACKEND 构造闸门：local=进程内；redis=多实例共享速率/预算窗。

    说明：并发（在飞数）始终是**每个实例**的；跨实例的并发上限需要分布式信号量
    （租约 + 心跳），不在本步范围内 —— Redis 共享的是 RPM / TPM。
    """
    rpm, tpm = rpm_limit(), tpm_limit()
    rate_window, token_window = RateWindow(rpm), TokenWindow(tpm)
    effective = "local"
    if backend() == "redis":
        client = _redis_client()
        if client is not None:
            rate_window = RedisRateWindow(
                client, os.getenv("LIMITER_RPM_KEY", "agent:rpm"), rpm)
            token_window = RedisTokenWindow(
                client, os.getenv("LIMITER_TPM_KEY", "agent:tpm"), tpm)
            effective = "redis"
    return Gate(max_concurrency(), rate_window, token_window, effective)


def get_gate(name: str = "default") -> Gate:
    """按 provider/账号取闸门（现阶段默认一把，全进程共享）。"""
    with _gates_lock:
        gate = _gates.get(name)
        if gate is None:
            gate = _build_gate()
            _gates[name] = gate
        return gate


def reset() -> None:
    """清空闸门（测试 / 改配置后用）。"""
    with _gates_lock:
        _gates.clear()
