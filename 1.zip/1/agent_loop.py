import os
import sys, time
from tools.utils import run_tool, get_schema
from tools.trust import SECURITY_PREAMBLE, frame, is_untrusted, new_nonce, scan
import costs
import tenant
from skills.assembler import skill_instructions
from llm.LLM import llm, summarize, extract_memories
from memory.store import get_store
from data.dataclass import AgentResult, CancelToken, RunContext, ToolCallRecord, Status
from conversation.conversation import Conversation
from trace_utils import Trace
from config import Config

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")



def _instructions_of(conv: Conversation) -> str:
    """基础指令 + 本次装配到的技能指令。"""
    extra = skill_instructions(conv.skills)
    return f"{conv.instructions}\n\n{extra}" if extra else conv.instructions


def _console_emit(event: dict) -> None:
    """默认事件出口：把流式文本打到终端（保持原有 CLI 行为）。"""
    if event.get("type") == "text_delta":
        time.sleep(0.05)
        print(event["text"], end="", flush=True)


def _text_of(content) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(b.get("text", "") if isinstance(b, dict) else str(b)
                       for b in content)
    return str(content)


def _accumulate(prev: dict, raw: dict) -> dict:
    """把一次调用的 usage 累加进总计（跨 step 累计，供成本核算与观测使用）。"""
    out = dict(prev or {})
    for k in ("input_tokens", "output_tokens", "total_tokens"):
        out[k] = int(out.get(k) or 0) + int((raw or {}).get(k) or 0)
    return out


def _last_user_text(conv: Conversation) -> str:
    for it in reversed(conv.items):
        if it.get("role") == "user":
            return _text_of(it.get("content"))
    return ""


def _recall_block(conv: Conversation, cfg: Config, user: str = "") -> str:
    """按当前用户消息，从长期记忆里取相关事实，拼成一段提示。

    单独放"指令"而不是塞进 items：items 是对话历史（会被持久化、被压缩），
    召回内容属于"这次运行的临时参考"，不该污染历史。
    """
    query = _last_user_text(conv)
    if not query:
        return ""
    try:
        hits = get_store(cfg.memory_path).search(query, cfg.recall_top_k, user=user)
    except Exception:
        return ""
    if not hits:
        return ""
    lines = "\n".join(f"- {m.text}" for m, _score in hits)
    return ("【相关长期记忆】\n" + lines +
            "\n（以上是历史沉淀的事实，仅供参考；与当前对话冲突时，以当前对话为准。）")


def _capture(conv: Conversation, cfg: Config, user: str = "") -> None:
    """把本轮值得长期记住的事实沉淀下来。best-effort：出错也不影响主流程。"""
    try:
        facts = extract_memories(conv.items[-8:])
        if not facts:
            return
        store = get_store(cfg.memory_path)
        for fact in facts:
            store.add(fact, tags=["auto"], session_id=conv.session_id, user=user)
    except Exception:
        pass


def run_agent(conv: Conversation, t: Trace, cfg: Config, emit=None,
              ctx: RunContext | None = None, cancel: CancelToken | None = None):
    """跑一次 Agent 循环。

    ctx 是可选运行上下文，携带"角色 + 允许的工具子集"。
    为 None 时行为与改动前完全一致（CLI / 服务 / 评测不受影响）。

    cancel 是可选取消令牌：每一步开始前检查，被取消则返回 CANCELLED。
    """

    emit = emit or _console_emit
    guard = getattr(cfg, "security_guard", True)             # ★ 第 22 步：内容信任边界
    nonce = new_nonce()                                      # 每次运行随机，防伪造边界
    tools = get_schema(conv.skills)
    if ctx is not None and ctx.tool_filter is not None:      # ★ 角色级工具过滤
        tools = [s for s in tools if s.get("name") in ctx.tool_filter]

    instructions = _instructions_of(conv)
    user = (ctx.user if ctx is not None else None) or ""     # ★ 第 27 步：归属用户
    tenant_token = tenant.set_user(user)                     # 工具层经 ContextVar 取到
    run_token = tenant.set_run(ctx.run_id if ctx is not None else None,
                               ctx.step_key if ctx is not None else None)
    if not t.user:
        t.user = user
    if guard:                                                # ★ 常驻安全策略（可信通道）
        instructions = f"{SECURITY_PREAMBLE}\n\n{instructions}"
    if cfg.auto_recall:                                      # ★ 自动召回长期记忆
        recall = _recall_block(conv, cfg, user)
        if recall:
            if guard:       # 召回内容来自长期记忆（可由历史对话写入）→ 按不可信数据包裹
                recall = frame("long_term_memory", recall, nonce)
            instructions = f"{instructions}\n\n{recall}"

    tool_calls: list[ToolCallRecord] = []
    t.gen_trace_id()
    deadline = time.monotonic() + cfg.time_budget_s
    total_tokens = 0
    usage = {}
    usage_total: dict = {}
    total_cost = 0.0
    try:
        for step in range(cfg.max_steps):

            if cancel is not None and cancel.is_set():       # ★ 协作式取消
                t.error_logs(step, "已被取消")
                t.save()
                return AgentResult("", Status.CANCELLED, step, tool_calls, {}, "已被取消")

            if time.monotonic() > deadline:
                error = f"整体超时，{time.monotonic()}"
                t.error_logs(step, error)
                t.save()
                return AgentResult("", Status.TIMEOUT, step, tool_calls, {}, error)
            if total_tokens > cfg.token_budget:
                error = f"token 超预算，{total_tokens}"
                t.error_logs(step, error)
                t.save()
                return AgentResult("", Status.BUDGET_EXCEEDED, step, tool_calls, {}, error)
            
            if conv.compact(summarize):
                t.insert_event("compact", step,
                               {"items_after": len(conv.items), "summary": conv.summary})
            
            t0 = time.perf_counter()
            try:
                stream = llm(
                    model=cfg.model,
                    tools=tools,
                    instructions=instructions,
                    input=conv.build_input(),
                    stream=True
                )
                response = None
                for event in stream:
                    if event.type == "response.output_text.delta":
                        emit({"type": "text_delta", "text": event.delta})
                    elif event.type == "response.completed":
                        response = event.response
                        usage = response.usage.model_dump() if getattr(response, "usage", None) else {}
            except Exception as e:
                t.error_logs(step, str(e))
                t.save()
                return AgentResult(
                    final_text="",
                    status=Status.FAILED,
                    steps=step,
                    tool_calls=tool_calls,
                    usage=usage,
                    error=str(e)
                )

            if response is None:
                t.error_logs(step, "流未正常结束")
                t.save()
                return AgentResult(
                    final_text="",
                    status=Status.FAILED,
                    steps=step,
                    tool_calls=tool_calls,
                    usage=usage,
                    error="流未正常结束"
                )
                
            t.insert_llm_call(response=response, conv=conv, step=step, t0=t0)
            total_tokens += (response.usage.total_tokens
                                if getattr(response, "usage", None) else 0)
            conv.add_response_output(response_output=response.output)
            usage_total = _accumulate(usage_total, usage)     # ★ 运行级累计
            total_cost += costs.cost_of(cfg.model, usage)     # ★ 计成本（USD）
            usage_total["cost"] = round(total_cost, 6)
            usage = usage_total                               # 返回值统一用累计值
            
            if not any(it for it in response.output if it.type == "function_call"):
                
                if cfg.auto_capture:                         # ★ 自动沉淀长期记忆
                    _capture(conv, cfg, user)
                t.save()
                return AgentResult(
                    final_text=response.output_text,
                    status=Status.COMPLETED,
                    steps=step+1,
                    tool_calls=tool_calls,
                    usage=usage                
                )
                
            for item in response.output:
                if item.type == "function_call":
                    t1 = time.perf_counter()
                    emit({"type": "tool_start", "name": item.name,
                          "arguments": item.arguments})
                    if ctx is not None and ctx.tool_filter is not None \
                            and item.name not in ctx.tool_filter:   # ★ 角色外工具直接拒绝
                        result, err = (
                            f"权限拒绝：角色 {ctx.role_name} 无权调用工具 {item.name}",
                            True,
                        )
                    else:
                        result, err = run_tool(item.name, item.arguments)
                    result = str(result)[:cfg.max_tool_output_chars]
                    tool_calls.append(ToolCallRecord(item.name, item.arguments, result, err))
                    model_output = result                          # 默认原样交给模型
                    if guard and is_untrusted(item.name):          # ★ 不可信输出先包边界
                        finds = scan(result)
                        if finds:
                            t.insert_event("injection_suspected", step,
                                           {"tool": item.name, "patterns": finds})
                        model_output = frame(item.name, result, nonce, finds)
                    conv.add_tool_output(item.call_id, model_output)
                    emit({"type": "tool_result", "name": item.name,
                          "ok": not err, "result": result})
                    t.insert_tool_call(item=item, result=result, step=step, err=err, t1=t1)
            conv.save()
            # conv.trim()
        t.save()
        return AgentResult(
            final_text="",
            status=Status.INCOMPLETED,
            steps=cfg.max_steps,
            tool_calls=tool_calls,
            usage=usage,
            error="达到最大调用次数"
        )
    finally:
        tenant.reset_user(tenant_token)
        tenant.reset_run(run_token)
        try:
            conv.save()
        except Exception as e:                       # I5：落盘失败不得掩盖原始异常
            print(f"[warn] 会话落盘失败：{e}", file=sys.stderr)

if __name__ == "__main__":
    
    t = Trace()
    cfg = Config()
    
    session_id = os.getenv("SESSION_ID", "demo2")
    conv = Conversation.load(session_id=session_id)
    if conv is None:
        conv = Conversation(instructions=cfg.instructions, session_id=session_id)

    if not conv.items:                                # 续接已有会话时不再重复追问
        conv.add_user("请回答今天天津的天气如何，顺便帮我计算一下123乘以456等于多少")
    agent_result = run_agent(conv, t, cfg)
    # print("状态：", agent_result.status, "|步数：", agent_result.steps, "|消耗tokens：", agent_result.usage)
    # print("\n最终答案：", agent_result.final_text)
    print("\n")
    conv.add_user("不使用工具，仅凭历史记录判断")
    agent_result1 = run_agent(conv, t, cfg)
    # print(agent_result1.final_text)

    


