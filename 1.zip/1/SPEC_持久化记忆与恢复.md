# 9. 持久化记忆与恢复

> 规格文档 · 项目 `1/`
> 适用目标：把会话记忆从内存落到硬盘，使会话可跨进程重启继续。

## 背景

基于"上下文管理"的改进。"上下文管理"的遗留问题是：记忆只存于内存，程序结束即消失。本步把记忆落到硬盘，使会话可跨进程重启继续。

## 范围

**改动文件限定在**（共 3 个）：

- `1/config/__init__.py`
- `1/conversation/conversation.py`
- `1/agent_loop.py`

**非目标（不得改动）：**

- 不改动 `tools/**` 下任何文件。
- 不改动 `data/dataclass.py` 的字段定义。
- 不改动 `llm/LLM.py` 的既有行为（本步不需要它）。
- 本步**不引入摘要压缩**（属第 10 步）：对 `items` 只做合法性修复，不做内容压缩。
- 不做多进程并发写同一 session 的加锁（本步假设单进程）。

## 契约

**1. `1/conversation/conversation.py` 增加会话ID属性 `session_id: str`**

- 默认值：自动生成，`uuid.uuid4().hex[:12]`。
- 允许构造时传入，用于续接已有会话：`Conversation(instructions, session_id="demo")`。
- 约束：`load(id)` 返回的对象，其 `session_id` 必须等于 `id`（见不变量 I1）。

**2. 增加持久化保存的实例方法 `save()`**

- 签名：`save(self, path: Path | None = None) -> Path`
- 输入：自定义路径（可选）。不传时，在 `conversation.py` 中按 `cfg.session_dir / f"{self.session_id}.json"` 拼出路径。
- 输出：实际写入的文件路径（`Path`）。**调用方可以选择忽略该返回值**。
- 行为：把整个会话（格式见"磁盘格式"）以 JSON 写入该路径；编码 `utf-8`、`ensure_ascii=False`；父目录不存在时自动创建。
- **必须原子**：先写**同目录**临时文件（同目录才能保证同文件系统），再 `os.replace(tmp, path)` 原子替换。

**3. 增加加载会话的类方法 `load()`**

- 签名：`load(cls, session_id: str) -> Conversation | None`（类方法）
- 输入：会话ID。
- 输出：`Conversation` 实例；**文件不存在时返回 `None`**。
- 行为：读 `cfg.session_dir/<session_id>.json` → 反序列化 → 重建对象；`items` 取自文件，且**必须经 `_sanitize()` 清理**（见边界表）。
- 约定：不存在的 id **不抛异常**，返回 `None`，以支持调用方 `Conversation.load(id) or Conversation(...)` 的写法。

**4. 会话文件的父目录在 `1/config/__init__.py` 定义**

- 字段为 `cfg.session_dir: Path`，默认 `1/sessions/`。
- **路径基于 `Path(__file__).resolve()` 解析，绝不使用进程 CWD**（I4）。
- 名称澄清：`session_id` 是"**哪一段**会话"的实例属性；`session_dir` 是"**存到哪**"的全局配置。两者不是一回事。

**5. 在 `run_agent()` 中接入落盘**

- 每个 step 在**工具往返闭合之后**（工具结果已写入 `items`）调用 `conv.save()`。
- 用 `try/finally` 包裹循环体，`finally` 中再调用一次 `conv.save()`，保证提前 `return` / 异常路径也落盘。
- `finally` 中的 `save()` **必须自带 try/except 保护，不得掩盖正在传播的原始异常**（I5）。

## 磁盘格式

```json
{
  "version": 1,
  "session_id": "demo",
  "instructions": "你是个AI助手，优先使用工具获取数据",
  "items": [
    {"role": "user", "content": "今天天津的天气如何"},
    {"type": "function_call", "call_id": "call_1", "name": "get_weather", "arguments": "{\"city\": \"天津\"}"},
    {"type": "function_call_output", "call_id": "call_1", "output": "天津，今天晴，温度26度"},
    {"role": "assistant", "content": [{"type": "output_text", "text": "天津今天晴，26 度。"}]}
  ],
  "updated_at": 1726000000.0
}
```

- `version`：格式版本号，便于将来加入 `summary` 时向后兼容。
- 若文件缺 `instructions`，load 时以 `cfg.instructions` 兜底。

## 不变量

- **I1 往返一致**：`load(id).session_id == id`；且对合法数据，`load(id).items == save 前 items`（清理逻辑不改变合法数据）。
- **I2 起点合法**：`items` 必须以 user 消息开头。
- **I3 配对原子**：`function_call` 与其 `function_call_output` 不得被拆散；因此 `save()` 只能发生在"工具往返闭合之后"。
- **I4 目录解析**：所有路径相对 `config/__init__.py` 的 `__file__` 解析，与 CWD 无关。
- **I5 不掩盖异常**：`finally` 中的 `save()` 失败不得覆盖原始异常。

## 边界与失败行为

| 情况 | 期望行为 |
|---|---|
| 文件不存在 | `load()` 返回 `None` |
| 文件存在但 JSON 非法/结构非法 | **抛 `ValueError`**（fail fast；"坏档"不等于"空档"，不可静默返回 None） |
| items 含孤儿 `function_call_output` | load 时经 `_sanitize()` 清除，不报错 |
| items 含未回填结果的 `function_call` | load 时经 `_sanitize()` 清除，不报错 |
| items 非 user 开头 | `_sanitize()` 去掉开头非 user 的前缀 |
| `save()` 遇磁盘满/无权限 | 向上抛出（不吞）；在 `finally` 场景由保护逻辑记录，但不覆盖原异常 |
| 缺少 api_key | `Config` 构造时报 `RuntimeError`（既有行为，不改） |

## 验收标准

1. 三个文件 `py_compile` 通过。
2. **往返一致**：新建 `Conversation` → `add_user(...)` → `save(id)` → `load(id)`，断言 `session_id`、`items`、`instructions` 三者相等。
3. **不存在 id**：`load("不存在的id")` 返回 `None`。
4. **坏档**：把 `session.json` 写成非法 JSON，`load()` 抛 `ValueError`。
5. **清理**：手工往 `items` 头部插一条孤儿 `function_call_output`，load 后被清除；再插一条未回填的 `function_call`，load 后也被清除。
6. **崩溃安全**：让 `run_agent` 在第 2 步抛异常，断言磁盘文件存在且含第 1 步**完整且闭合**的内容。
7. **续接**：同一 `session_id` 连续 `run_agent()` 两次，第二次 `conv.items` 包含第一次的历史（断言长度增加且内容包含）。
8. **目录无关**：从任意 CWD 运行，session 文件仍落在 `1/sessions/`。

---

## 附录：与原稿的差异对照（非规格正文）

| 位置 | 原稿 | 改动原因 |
|---|---|---|
| 契约 4 | `cfg.session_id` | **硬伤**：那是实例属性，配置里应是 `cfg.session_dir` |
| 契约 2 | "拼出在**当前目录**下的路径" | "当前目录"歧义 → 钉死为基于 `__file__` 解析（I4） |
| 契约 2 | "save() 为原子操作" | 只说了目标没说手段 → 补"同目录临时文件 + `os.replace`" |
| 契约 5 | "每个 step 中加入 save()" | 未指明落点 → 补"工具往返闭合之后"（I3） |
| 契约 5 | "finally 中调用 save()" | 未考虑掩盖异常 → 补 I5 |
| 契约 3 | "items 接收硬盘的 json 内容" | 未定义坏档行为 → 补边界表（坏档抛错 / 缺档返 None） |
| 新增 | —— | 补"磁盘格式"（含 `version`），消除兼容性歧义 |
| 新增 | —— | 补"非目标"，防 agent 扩大改动面 |
| 验收 1 | "可成功编译" | 只是门槛 → 保留，但补齐 7 条可断言检查 |
| 验收 2 | "可利用之前的历史会话" | 不可判定 → 改成可断言的"往返一致 / 长度增加" |

最小、也最关键的三处：**`session_dir` 的命名、磁盘格式的固化、验收从"描述"变成"断言"**。补齐这三处，本文档即达到"换一个 agent 照着实现，结果也能对上"的标准。
