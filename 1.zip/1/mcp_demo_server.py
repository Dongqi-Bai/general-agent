"""本地演示 MCP server（第 21 步）。

不是给生产用的，只用来验证"外部 MCP server → 注册成工具 → 被 Agent 调用"
这条链路。用的是官方 SDK 的 MCPServer（mcp 2.x 里 FastMCP 的新名字）。

单独跑（会阻塞在 stdio 上，等客户端来连）：
    python mcp_demo_server.py
"""
from mcp.server.mcpserver import MCPServer

server = MCPServer(
    name="demo",
    version="1.0.0",
    instructions="演示用的最小 MCP server：算数、回显、写便签。",
)


@server.tool()
def add(a: float, b: float) -> str:
    """把两个数相加并返回结果。"""
    return str(a + b)


@server.tool()
def echo(text: str) -> str:
    """原样回显输入文本。"""
    return f"echo: {text}"


@server.tool()
def write_note(text: str) -> str:
    """把一条便签追加进 mcp_demo_notes.txt（有副作用，用来验证 HITL 审批）。"""
    with open("mcp_demo_notes.txt", "a", encoding="utf-8") as f:
        f.write(text + "\n")
    return f"已记录：{text}"


if __name__ == "__main__":
    server.run("stdio")
