"""多 Agent（run_plan）路径的评测运行器：跑用例 → 断言 → 出报告。

与 run_evals.py 共用同一套隔离机制（临时沙箱 / 独立 traces / 独立 sessions /
权限 shim），但断言的是"编排结果"：拆解规模与角色、工具使用、评审结论、最终交付。

用法（在 1/ 目录下）：
    python evals/run_plan_evals.py                 # 跑全部
    python evals/run_plan_evals.py --level 1       # 只跑冒烟
    python evals/run_plan_evals.py --only plan_weather_math_write
    python evals/run_plan_evals.py --repeat 2      # 每条跑2次，全过才算过
退出码：全部通过=0，有失败=1（可直接接 CI）

注意：计划路径 = 规划 + N 个子任务 + 汇总 + 评审，单条用例的调用次数与花费
明显高于单循环用例，请按 level 分层、按需运行。
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

import yaml

EVAL_DIR = Path(__file__).resolve().parent
PROJECT_DIR = EVAL_DIR.parent                      # 指向 1/
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

# 评测沙箱隔离：必须在导入 tools.* 之前设置（tools/sandbox.py 在导入时读取该环境变量）
EVAL_SANDBOX = Path(tempfile.mkdtemp(prefix="agent_plan_eval_sandbox_"))
os.environ["SANDBOX_ROOT"] = str(EVAL_SANDBOX)

# 第 20 步：评测期间关闭自动记忆（避免污染真实长期记忆、也避免行为不确定）
os.environ["AUTO_RECALL"] = "0"
os.environ["AUTO_CAPTURE"] = "0"
os.environ["MEMORY_PATH"] = str(EVAL_DIR / "memory" / "eval_long_term.jsonl")

import tools.utils as tools_utils                   # noqa: E402
from tools.registry import TOOL_REGISTRY, Risk      # noqa: E402
import conversation.conversation as conv_mod        # noqa: E402
from config import Config                           # noqa: E402
from trace_utils import Trace                       # noqa: E402
from orchestrator import run_plan                   # noqa: E402

# 评测产物与业务隔离：不污染 1/sessions/ 和 1/traces/
Trace.TRACE_DIR = EVAL_DIR / "traces"
conv_mod.cfg.session_dir = EVAL_DIR / "sessions"


def _permission_shim(allow_write: bool):
    """READ 一律放行；WRITE/DANGER 按用例设置决定（与单循环评测完全一致）。"""
    def _check(name, args):
        risk = (TOOL_REGISTRY.get(name) or {}).get("risk", Risk.READ)
        if risk == Risk.READ:
            return True, "eval-allow-read"
        return (allow_write, "eval-allow-write" if allow_write else "eval-deny-write")
    return _check


def _silent(_event: dict) -> None:
    """跑评测时不把编排过程打到终端。"""
    return None


def check_plan(expect: dict, result) -> list[dict]:
    """把"期望"逐条变成可判定的断言。返回 [(断言名, 是否通过, 详情)]。"""
    checks: list[dict] = []

    def add(name, ok, detail=""):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    specs = list(getattr(result.plan, "subtasks", []) or [])
    roles = [s.role for s in specs]
    subs = result.subtask_results
    called = [c.name for r in subs.values() for c in r.tool_calls]
    text = result.final_text or ""

    if "status" in expect:
        add("status", result.status == expect["status"], f"实际={result.status}")

    if "min_subtasks" in expect:
        add("min_subtasks", len(specs) >= expect["min_subtasks"], f"实际={len(specs)}")
    if "max_subtasks" in expect:
        add("max_subtasks", len(specs) <= expect["max_subtasks"], f"实际={len(specs)}")

    for role in expect.get("roles_include", []):
        add(f"role:{role}", role in roles, f"实际角色={roles}")

    for t in expect.get("must_call_any", []):
        add(f"must_call_any:{t}", t in called, f"实际调用={sorted(set(called))}")
    for t in expect.get("forbidden_call", []):
        add(f"forbidden_call:{t}", t not in called, f"实际调用={sorted(set(called))}")

    if "review_passed" in expect:
        got = (result.review or {}).get("passed")
        add("review_passed", got == expect["review_passed"], f"实际={got}")
    if "max_rounds" in expect:
        add("max_rounds", result.rounds <= expect["max_rounds"], f"实际={result.rounds}")
    if "max_tokens" in expect:
        add("max_tokens", result.total_tokens <= expect["max_tokens"],
            f"实际={result.total_tokens}")

    for kw in expect.get("answer_contains", []):
        add(f"answer_contains:{kw}", kw in text)
    for pat in expect.get("answer_regex", []):
        add(f"answer_regex:{pat}", re.search(pat, text) is not None)

    if "subtask_status_all" in expect:
        got = {r.status.value if hasattr(r.status, "value") else str(r.status)
               for r in subs.values()}
        add("subtask_status_all", got == {expect["subtask_status_all"]}, f"实际={got}")

    return checks


def run_once(case: dict, cfg: Config):
    """跑一个计划用例一次，返回 PlanResult。"""
    allow = case.get("permission", "deny") == "allow"
    tools_utils.check_permission = _permission_shim(allow)
    return run_plan(
        case["goal"], cfg,
        emit=_silent,
        approver=lambda name, args: (allow, "eval-approver"),  # 不阻塞终端
        max_replans=case.get("max_replans"),
    )


def _fail_run(exc: Exception, latency: float) -> dict:
    return {
        "plan_trace_id": "",
        "passed": False,
        "checks": [{"name": "exception", "ok": False, "detail": str(exc)}],
        "latency_s": round(latency, 2),
        "rounds": 0, "subtasks": 0, "roles": [], "total_tokens": 0,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default=str(EVAL_DIR / "plan_cases.yaml"))
    ap.add_argument("--level", type=int, default=None)
    ap.add_argument("--only", default=None)
    ap.add_argument("--repeat", type=int, default=1)
    ap.add_argument("--keep-sandbox", action="store_true",
                    help="保留本次评测用的临时沙箱目录")
    args = ap.parse_args()

    cfg = Config()
    spec = yaml.safe_load(Path(args.cases).read_text(encoding="utf-8"))
    cases = spec["cases"]
    if args.level is not None:
        cases = [c for c in cases if c.get("level") == args.level]
    if args.only:
        cases = [c for c in cases if c["id"] == args.only]

    print(f"[plan] 模型={cfg.model}  用例={len(cases)}  重复={args.repeat}")
    print(f"[plan] 评测沙箱={EVAL_SANDBOX}\n")

    report_cases = []
    t_start = time.perf_counter()

    for case in cases:
        runs = []
        for _ in range(args.repeat):
            t0 = time.perf_counter()
            try:                                    # 单个用例崩了不该拖垮整轮
                result = run_once(case, cfg)
                checks = check_plan(case.get("expect", {}), result)
                runs.append({
                    "plan_trace_id": result.plan_trace_id,
                    "passed": all(c["ok"] for c in checks),
                    "checks": checks,
                    "latency_s": round(time.perf_counter() - t0, 2),
                    "rounds": result.rounds,
                    "subtasks": len(getattr(result.plan, "subtasks", []) or []),
                    "roles": [s.role for s in getattr(result.plan, "subtasks", []) or []],
                    "total_tokens": result.total_tokens,
                })
            except Exception as e:
                runs.append(_fail_run(e, time.perf_counter() - t0))

        passed = all(r["passed"] for r in runs)
        report_cases.append({"id": case["id"], "level": case.get("level"),
                             "passed": passed, "runs": runs})

        n_ok = sum(1 for r in runs if r["passed"])
        print(f"[{'PASS' if passed else 'FAIL'}] {case['id']}  ({n_ok}/{len(runs)})")
        if not passed:
            for r in runs:
                for c in r["checks"]:
                    if not c["ok"]:
                        print(f"          x {c['name']}  {c.get('detail', '')}")
            print(f"          plan_trace={runs[0]['plan_trace_id']}  ← 拿它去 traces/ 复盘")

    total = len(report_cases)
    n_pass = sum(1 for c in report_cases if c["passed"])
    elapsed = round(time.perf_counter() - t_start, 1)
    print(f"\n通过率 {n_pass}/{total}   用时 {elapsed}s")

    results_dir = EVAL_DIR / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = results_dir / f"plan_{stamp}.json"
    out.write_text(json.dumps({
        "timestamp": stamp, "kind": "plan", "model": cfg.model,
        "repeat": args.repeat, "elapsed_s": elapsed,
        "passed": n_pass, "total": total, "cases": report_cases,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"报告：{out}")

    if args.keep_sandbox:
        print(f"沙箱保留：{EVAL_SANDBOX}")
    else:
        shutil.rmtree(EVAL_SANDBOX, ignore_errors=True)

    return 0 if n_pass == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
