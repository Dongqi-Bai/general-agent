"""检索与长期记忆的离线评测（第 20e 步）。

不调用任何 LLM：只验证
    1) 切块 → 建索引 → 召回
    2) 写入记忆 → 检索记忆
因此它秒级完成、零花费、结果确定，适合每次改动都跑，也适合接 CI。

用法（在 1/ 目录下）：
    python evals/run_retrieval_evals.py                 # 跑全部
    python evals/run_retrieval_evals.py --level 1       # 只跑冒烟
    python evals/run_retrieval_evals.py --only find_sandbox_root
    python evals/run_retrieval_evals.py --show-hits     # 失败时打印命中的 top 结果
退出码：全部通过=0，有失败=1
"""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

import yaml

EVAL_DIR = Path(__file__).resolve().parent
PROJECT_DIR = EVAL_DIR.parent                      # 指向 1/
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

from retrieval.chunker import build_chunks          # noqa: E402
from retrieval.index import build_index             # noqa: E402
from memory.store import MemoryStore                # noqa: E402


def check_retrieval(expect: dict, hits) -> list[dict]:
    checks: list[dict] = []

    def add(name, ok, detail=""):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    paths = [h.chunk.path for h in hits]

    if "min_hits" in expect:
        add("min_hits", len(hits) >= expect["min_hits"], f"实际={len(hits)}")
    if "expect_max_hits" in expect:
        add("expect_max_hits", len(hits) <= expect["expect_max_hits"], f"实际={len(hits)}")

    want = expect.get("expect_path_any")
    if want:
        within = expect.get("rank_within", len(hits) or 1)
        top = paths[:within]
        hit = next((p for p in top if p in want), None)
        add(f"path_within_top{within}", hit is not None,
            f"期望其一={want} 实际前{within}={top}")

    return checks


def check_memory(expect: dict, hits) -> list[dict]:
    checks: list[dict] = []

    def add(name, ok, detail=""):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    texts = [m.text for m, _ in hits]

    if "min_hits" in expect:
        add("min_hits", len(hits) >= expect["min_hits"], f"实际={len(hits)}")
    if "expect_max_hits" in expect:
        add("expect_max_hits", len(hits) <= expect["expect_max_hits"], f"实际={len(hits)}")
    for kw in expect.get("expect_contains", []):
        add(f"contains:{kw}", any(kw in t for t in texts), f"实际={texts}")

    return checks


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default=str(EVAL_DIR / "retrieval_cases.yaml"))
    ap.add_argument("--root", default=str(PROJECT_DIR), help="要索引的根目录")
    ap.add_argument("--level", type=int, default=None)
    ap.add_argument("--only", default=None)
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--show-hits", action="store_true")
    args = ap.parse_args()

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")

    spec = yaml.safe_load(Path(args.cases).read_text(encoding="utf-8"))
    r_cases = spec.get("retrieval_cases") or []
    m_cases = spec.get("memory_cases") or []
    if args.level is not None:
        r_cases = [c for c in r_cases if c.get("level") == args.level]
        m_cases = [c for c in m_cases if c.get("level") == args.level]
    if args.only:
        r_cases = [c for c in r_cases if c["id"] == args.only]
        m_cases = [c for c in m_cases if c["id"] == args.only]

    t_start = time.perf_counter()
    report: list[dict] = []

    # ---------- 检索用例 ----------
    if r_cases:
        root = Path(args.root).resolve()
        t0 = time.perf_counter()
        files, chunks = build_chunks(root)
        index = build_index(chunks)
        build_ms = (time.perf_counter() - t0) * 1000
        print(f"[检索] 索引 {files} 个文件 / {len(chunks)} 个块 / 词表 {index.vocab} 项"
              f"  （{build_ms:.0f} ms）\n")

        for case in r_cases:
            hits = index.search(case["query"], args.top)
            checks = check_retrieval(case.get("expect", case), hits)
            passed = all(c["ok"] for c in checks)
            report.append({"id": case["id"], "kind": "retrieval",
                           "level": case.get("level"), "passed": passed, "checks": checks})
            print(f"[{'PASS' if passed else 'FAIL'}] {case['id']}")
            if not passed or args.show_hits:
                for c in checks:
                    if not c["ok"]:
                        print(f"          x {c['name']}  {c.get('detail', '')}")
                for h in hits:
                    print(f"          · {h.score:6.2f}  {h.chunk.cite}")

    # ---------- 记忆用例 ----------
    if m_cases:
        print()
        for case in m_cases:
            tmp = Path(tempfile.mkdtemp(prefix="mem_eval_")) / "long_term.jsonl"
            store = MemoryStore(tmp)
            for text in case.get("add", []):
                store.add(text)
            hits = store.search(case["query"], args.top)
            checks = check_memory(case.get("expect", case), hits)
            passed = all(c["ok"] for c in checks)
            report.append({"id": case["id"], "kind": "memory",
                           "level": case.get("level"), "passed": passed, "checks": checks})
            print(f"[{'PASS' if passed else 'FAIL'}] {case['id']}")
            if not passed or args.show_hits:
                for c in checks:
                    if not c["ok"]:
                        print(f"          x {c['name']}  {c.get('detail', '')}")
                for m, s in hits:
                    print(f"          · {s:6.2f}  {m.text}")

    total = len(report)
    n_pass = sum(1 for c in report if c["passed"])
    elapsed = round(time.perf_counter() - t_start, 2)
    print(f"\n通过率 {n_pass}/{total}   用时 {elapsed}s")

    results_dir = EVAL_DIR / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = results_dir / f"retrieval_{stamp}.json"
    out.write_text(json.dumps({
        "timestamp": stamp, "kind": "retrieval", "elapsed_s": elapsed,
        "passed": n_pass, "total": total, "cases": report,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"报告：{out}")

    return 0 if n_pass == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
