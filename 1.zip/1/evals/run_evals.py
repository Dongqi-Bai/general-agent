"""
评测运行器：跑用例 → 断言 → 出报告。不修改任何业务源码。

用法（在 1/ 目录下）：
    python evals/run_evals.py                 # 跑全部
    python evals/run_evals.py --level 1       # 只跑冒烟，秒级
    python evals/run_evals.py --only smoke_weather_and_math
    python evals/run_evals.py --repeat 3      # 每条跑3次，全过才算过
退出码：全部通过=0，有失败=1（可直接接 CI）
"""
from __future__ import annotations

import argparse
import contextlib
import io
import json
import os
import re
import shutil
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

import yaml 

EVAL_DIR = Path(__file__).resolve().parent
PROJECT_DIR = EVAL_DIR.parent                      # 指向 1/
if str(PROJECT_DIR) not in sys.path:
    sys.path.insert(0, str(PROJECT_DIR))

# 评测沙箱隔离：必须在导入 tools.* 之前设置（tools/sandbox.py 在导入时读取该环境变量）
EVAL_SANDBOX = Path(tempfile.mkdtemp(prefix="agent_eval_sandbox_"))
os.environ["SANDBOX_ROOT"] = str(EVAL_SANDBOX)

# 第 20 步：评测期间关闭自动记忆（避免污染真实长期记忆、也避免行为不确定）
os.environ["AUTO_RECALL"] = "0"
os.environ["AUTO_CAPTURE"] = "0"
os.environ["MEMORY_PATH"] = str(EVAL_DIR / "memory" / "eval_long_term.jsonl")

import tools.utils as tools_utils                  # noqa: E402
from tools.registry import TOOL_REGISTRY, Risk
import conversation.conversation as conv_mod        # noqa: E402
from config import Config                           # noqa: E402
from conversation.conversation import Conversation  # noqa: E402
from trace_utils import Trace                       # noqa: E402
from agent_loop import run_agent                    # noqa: E402

# 评测产物与业务隔离：不污染 1/sessions/ 和 1/traces/
Trace.TRACE_DIR = EVAL_DIR / "traces"
conv_mod.cfg.session_dir = EVAL_DIR / "sessions"


def _permission_shim(allow_write: bool):
    """READ 一律放行；WRITE/DANGER 按用例设置决定。"""
    def _check(name, args):
        entry = TOOL_REGISTRY.get(name) or {}
        risk = entry.get("risk", Risk.READ)
        if risk == Risk.READ:
            return True, "eval-allow-read"
        return (allow_write, "eval-allow-write" if allow_write else "eval-deny-write")
    return _check


def check(expect: dict, result) -> list[dict]:
    """把"期望"逐条变成可判定的断言。返回 [(断言名, 是否通过, 详情)]。"""
    checks: list[dict] = []

    def add(name, ok, detail=""):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    called = [c.name for c in result.tool_calls]
    text = result.final_text or ""
    tokens = result.usage.get("total_tokens", 0) if isinstance(result.usage, dict) else 0

    if "status" in expect:
        add("status", result.status.value == expect["status"], f"实际={result.status.value}")

    for t in expect.get("must_call", []):
        add(f"must_call:{t}", t in called, f"实际调用={called}")

    # 严格：根本不该出现在 tool_calls 里
    for t in expect.get("forbidden_call", []):
        add(f"forbidden_call:{t}", t not in called, f"实际调用={called}")

    # 宽松：没调用 或 调用了但被拒绝 —— 只要没真正生效就算过
    for t in expect.get("tool_not_effective", []):
        recs = [c for c in result.tool_calls if c.name == t]
        ok = (not recs) or any(r.error for r in recs)
        add(f"tool_not_effective:{t}", ok,
            f"记录={[(r.name, r.error) for r in recs]}")

    for tool, kws in (expect.get("call_args_contains") or {}).items():
        args = [c.arguments or "" for c in result.tool_calls if c.name == tool]
        add(f"args:{tool}", any(all(k in a for k in kws) for a in args), f"args={args}")

    # 工具"结果"层面：必须真的成功（例如 write_file 返回"写入成功"）
    for tool, kws in (expect.get("tool_result_contains") or {}).items():
        outs = [c.output or "" for c in result.tool_calls if c.name == tool]
        add(f"result:{tool}", any(all(k in o for k in kws) for o in outs), f"outputs={outs}")

    for kw in expect.get("answer_contains", []):
        add(f"answer_contains:{kw}", kw in text)

    for pat in expect.get("answer_regex", []):
        add(f"answer_regex:{pat}", re.search(pat, text) is not None)

    if "max_steps" in expect:
        add("max_steps", result.steps <= expect["max_steps"], f"实际={result.steps}")

    if "max_tokens" in expect:
        add("max_tokens", tokens <= expect["max_tokens"], f"实际={tokens}")

    return checks


def run_once(case: dict, cfg: Config):
    """跑一个用例一次，返回 (AgentResult, trace_id)。"""
    tools_utils.check_permission = _permission_shim(
        case.get("permission", "deny") == "allow"
    )

    conv = Conversation(instructions=cfg.instructions)
    t = Trace()

    turns = case.get("turns") or [case["input"]]
    result = None
    for msg in turns:
        conv.add_user(msg)
        sink = io.StringIO()
        with contextlib.redirect_stdout(sink):     # 静音 run_agent 里的流式 print
            result = run_agent(conv, t, cfg)
    return result, t.trace_id


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", default=str(EVAL_DIR / "cases.yaml"))
    ap.add_argument("--level", type=int, default=None)
    ap.add_argument("--only", default=None)
    ap.add_argument("--repeat", type=int, default=1)
    ap.add_argument("--keep-sandbox", action="store_true",
                    help="保留本次评测用的临时沙箱目录")
    args = ap.parse_args()

    cfg = Config()
    spec = yaml.safe_load(Path(args.cases).read_text(encoding="utf-8"))
    cases = spec["cases"]
    if args.level is not None:
        cases = [c for c in cases if c.get("level") == args.level]
    if args.only:
        cases = [c for c in cases if c["id"] == args.only]

    print(f"模型={cfg.model}  用例={len(cases)}  重复={args.repeat}")
    print(f"评测沙箱={EVAL_SANDBOX}\n")

    report_cases = []
    t_start = time.perf_counter()

    for case in cases:
        runs = []
        for _ in range(args.repeat):
            t0 = time.perf_counter()
            result, trace_id = run_once(case, cfg)
            checks = check(case.get("expect", {}), result)
            runs.append({
                "trace_id": trace_id,
                "passed": all(c["ok"] for c in checks),
                "checks": checks,
                "latency_s": round(time.perf_counter() - t0, 2),
                "steps": result.steps,
                "usage": result.usage if isinstance(result.usage, dict) else {},
            })

        passed = all(r["passed"] for r in runs)
        report_cases.append({
            "id": case["id"], "level": case.get("level"),
            "passed": passed, "runs": runs,
        })

        n_ok = sum(1 for r in runs if r["passed"])
        print(f"[{'PASS' if passed else 'FAIL'}] {case['id']}  ({n_ok}/{len(runs)})")
        if not passed:
            for r in runs:
                for c in r["checks"]:
                    if not c["ok"]:
                        print(f"          x {c['name']}  {c.get('detail', '')}")
            print(f"          trace={runs[0]['trace_id']}  ← 拿它去 traces/ 复盘")

    total = len(report_cases)
    n_pass = sum(1 for c in report_cases if c["passed"])
    elapsed = round(time.perf_counter() - t_start, 1)
    print(f"\n通过率 {n_pass}/{total}   用时 {elapsed}s")

    results_dir = EVAL_DIR / "results"
    results_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out = results_dir / f"{stamp}.json"
    out.write_text(json.dumps({
        "timestamp": stamp, "model": cfg.model, "repeat": args.repeat,
        "elapsed_s": elapsed, "passed": n_pass, "total": total,
        "cases": report_cases,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"报告：{out}")

    if args.keep_sandbox:
        print(f"沙箱保留：{EVAL_SANDBOX}")
    else:
        shutil.rmtree(EVAL_SANDBOX, ignore_errors=True)

    return 0 if n_pass == total else 1


if __name__ == "__main__":
    raise SystemExit(main())
